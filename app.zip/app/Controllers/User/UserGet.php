<?php

namespace App\Controllers\User;

use App\Controllers\User\UserBaseController;

use App\Models\User\UserGetModel;

class UserGet extends UserBaseController{
	protected $model;

	public function __construct() {
		$this->model = new UserGetModel();
	}

	public function notFound($page){
        if(!is_file(APPPATH.'/Views/User/'.$page.'.php')){
            //Whoops, we don't have a page for that!
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }else return true;
	}

	public function index(){
		return view(APPPATH.'/Views/User/404',$this->site);
    }

	public function Profile(){
		if($this->notFound('profile')){ 

			$data = json_decode(json_encode($this->User), true);
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();

			$data['uname'] = $this->User->first_name.' '.$this->User->last_name;
			$data['created'] = date("F j, Y", (int)$data['created_on']);
			$data['dob'] = date("M d, Y", $data['dob']);
			$data['uemail'] = $data['email'];
			$data['uphone'] = $data['phone'];
			$data['uaddress'] = $data['address'];
			$data['ref_code'] = 'ref-'.$this->site['site_prefix'].'-'.$data['referral_id'];
			$data['ref_link'] = base_url('ref/ref-'.$this->site['site_prefix'].'-'.$data['referral_id']);
			
			if($this->User->kyc_status == 0){
				$dTemplate = view('errors/form/single',['error' => 'Awaiting verification']);
			}else if($this->User->kyc_status == 1){
				$dTemplate = view('messages/single',['message' => 'Your account has been verified already']);
			}else if($this->User->kyc_status == 3){
				$dTemplate = view('errors/form/single',['error' => 'Your account verification failed']);
			}else if($this->User->kyc_status == 2){
				$dTemplate = view('errors/form/single',['error' => 'Your account verification is PENDING']);
			}else $dTemplate = null;

			$data['infoKYC'] = $dTemplate;
			
			$data['infoPass'] = session()->getFlashdata("errorPass");
			$data['infoUpload'] = session()->getFlashdata("errorUpload");
			$data['infoSettings'] = session()->getFlashdata("errorSettings");
			$data['infoKYC2'] = session()->getFlashdata("errorKyc");
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'Your Profile';
			$data['page'] = 'profile';
			return $this->view('profile',$data);
		} 
    }

	public function Login(){
		if($this->notFound('login_history')){ 

			$data['login_history'] = $this->model->getLogin($this->User->id);

			for($i = 0; $i < count($data['login_history']); $i++){
				$data['login_history'][$i]['time'] = date("M d, Y g:i A", (int)$data['login_history'][$i]['time']);
			}

			$data['page_title'] = 'Login History';
			$data['page'] = 'login-history';
			return $this->view('login_history',$data);
		} 
    }

	public function Deposits(){
		if($this->notFound('deposit_history')){ 

			$data['deposit_history'] = $this->model->getDeposit($this->User->id);

			for($i = 0; $i < count($data['deposit_history']); $i++){
				$data['deposit_history'][$i]['time'] = date("d/m/y g:i A", (int)$data['deposit_history'][$i]['time']);

				$data['deposit_history'][$i]['amount'] = number_to_currency(floatval($data['deposit_history'][$i]['amount']), $this->site['site_currency'],null,2);

				if($data['deposit_history'][$i]['status'] == 0) $data['deposit_history'][$i]['status'] = '<span class="shadow-none badge">Waiting</span>';
				if($data['deposit_history'][$i]['status'] == 1) $data['deposit_history'][$i]['status'] = '<span class="shadow-none badge badge-success">Processed</span>';
				if($data['deposit_history'][$i]['status'] == 2) $data['deposit_history'][$i]['status'] = '<span class="shadow-none badge badge-warning">Pending</span>';
				if($data['deposit_history'][$i]['status'] == 3) $data['deposit_history'][$i]['status'] = '<span class="shadow-none badge badge-primary">Insufficient</span>';
				if($data['deposit_history'][$i]['status'] == 4) $data['deposit_history'][$i]['status'] = '<span class="shadow-none badge badge-danger">Cancelled</span>';
			}

			$data['page_title'] = 'Deposit History';
			$data['page'] = 'Deposit-history';
			return $this->view('deposit_history',$data);
		} 
    }

	public function Withdrawal(){
		if($this->notFound('withdraw_history')){ 

			$data['withdraw_history'] = $this->model->getWithdrawal($this->User->id);

			$methods = $this->model->getWithdrawMethods();

			$wmethod = array_column($methods,'currency','method');

			for($i = 0; $i < count($data['withdraw_history']); $i++){
				$data['withdraw_history'][$i]['time'] = date("d-m-y g:i A", (int)$data['withdraw_history'][$i]['time']);

				$data['withdraw_history'][$i]['currency'] =  $wmethod[ucfirst($data['withdraw_history'][$i]['reference'])]; 

				if($data['withdraw_history'][$i]['status'] == 0) $data['withdraw_history'][$i]['status'] = '<span class="shadow-none badge">Waiting</span>';
				if($data['withdraw_history'][$i]['status'] == 1) $data['withdraw_history'][$i]['status'] = '<span class="shadow-none badge badge-success">Processed</span>';
				if($data['withdraw_history'][$i]['status'] == 2) $data['withdraw_history'][$i]['status'] = '<span class="shadow-none badge badge-warning">Pending</span>';
				if($data['withdraw_history'][$i]['status'] == 3) $data['withdraw_history'][$i]['status'] = '<span class="shadow-none badge badge-primary">Insufficient</span>';
				if($data['withdraw_history'][$i]['status'] == 4) $data['withdraw_history'][$i]['status'] = '<span class="shadow-none badge badge-danger">Cancelled</span>';
			}

			$data['page_title'] = 'Withdrawal History';
			$data['page'] = 'withdrawal-history';
			return $this->view('withdraw_history',$data);
		} 
    }

	public function Referral(){
		if($this->notFound('referral')){ 

			$data['referral_history'] = $this->model->getReferral($this->User->id);
			$data['ref_code'] = 'ref-'.$this->site['site_prefix'].'-'.$this->User->referral_id;
			$data['ref_link'] = base_url('ref/ref-'.$this->site['site_prefix'].'-'.$this->User->referral_id);

			$Users = $this->ionAuth->users()->result();

			$Users = json_decode(json_encode($Users),true);

			$fnames = array_column($Users,'first_name','id');

			$lnames = array_column($Users,'last_name','id');

			$unames = array_column($Users,'username','id');
        
			//exit('<pre>'.print_r($Users,true).'</pre>');

			for($i = 0; $i < count($data['referral_history']); $i++){
				$data['referral_history'][$i]['time'] = date("d-m-Y", (int)$data['referral_history'][$i]['time_o']);

				$data['referral_history'][$i]['commission'] =  number_to_currency(floatval($data['referral_history'][$i]['commission']), $this->site['site_currency'],null,2);
				
				$data['referral_history'][$i]['uname'] = $unames[$data['referral_history'][$i]['user_id']];
				
				$data['referral_history'][$i]['user_id'] = $lnames[$data['referral_history'][$i]['user_id']].' '.$fnames[$data['referral_history'][$i]['user_id']];
				
				if($data['referral_history'][$i]['status'] == 0) $data['referral_history'][$i]['status'] = '<span class ="badge badge-dot badge-secondary">Waiting</span>';
				if($data['referral_history'][$i]['status'] == 1) $data['referral_history'][$i]['status'] = '<span class ="badge badge-dot badge-success">Paid</span>';
				if($data['referral_history'][$i]['status'] == 2) $data['referral_history'][$i]['status'] = '<span class ="badge badge-dot badge-warning">Pending</span>';
				if($data['referral_history'][$i]['status'] == 3) $data['referral_history'][$i]['status'] = '<span class ="badge badge-dot badge-danger">Cancelled</span>';
				
				if($data['referral_history'][$i]['valid'] == 0) $data['referral_history'][$i]['valid'] = '<span class ="badge badge-dot badge-secondary">Waiting</span>';
				if($data['referral_history'][$i]['valid'] == 1) $data['referral_history'][$i]['valid'] = '<span class ="badge badge-dot badge-success">Invested</span>';
				if($data['referral_history'][$i]['valid'] == 2) $data['referral_history'][$i]['valid'] = '<span class ="badge badge-dot badge-warning">Pending</span>';
				if($data['referral_history'][$i]['valid'] == 3) $data['referral_history'][$i]['valid'] = '<span class ="badge badge-dot badge-danger">Cancelled</span>';
				
				
			}
			$data['ref_code'] = 'ref-'.$this->site['site_prefix'].'-'.$this->User->referral_id;

			$data['page_title'] = 'Referral History';
			$data['page'] = 'referral';
			return $this->view('referral',$data);
		} 
    }

	public function Invoice(){
		if($this->notFound('invoice')){ 

			$data['invoice'] = $this->model->getInvoice($this->User->id);

			$plans = $this->model->getPlans($this->User->id);

			$splan = array_column($plans,'name','id');
			$dplan = array_column($plans,'description','id');

			for($i = 0; $i < count($data['invoice']); $i++){
				$data['invoice'][$i]['time'] = date("j M Y", (int)$data['invoice'][$i]['time']);

				$data['invoice'][$i]['uname'] = $this->User->first_name.' '.$this->User->last_name;

				$data['invoice'][$i]['uaddress'] = $this->User->address;

				$data['invoice'][$i]['uemail'] = $this->User->email;

				$data['invoice'][$i]['inv'] = $this->site['site_prefix'];

				$data['invoice'][$i]['site_name'] = $this->site['site_name'];

				$data['invoice'][$i]['amount'] = number_to_currency(floatval($data['invoice'][$i]['invested']), $this->site['site_currency'],null,2);

				//get plan name
				$data['invoice'][$i]['plan_desc'] = $dplan[$data['invoice'][$i]['plan']];
				$data['invoice'][$i]['plan'] = $splan[$data['invoice'][$i]['plan']];
			}

			$data['page_title'] = 'Your invoices';
			$data['page'] = 'invoice';
			return $this->view('invoice',$data);
		} 
    }

	public function Withdraw(){
	    if(!$this->site['allow_withdrawal'])return redirect()->to(base_url('user/dashboard'));
		if($this->notFound('make_withdrawal')){ 

			$data['withdraw_method'] = $this->model->getWithdrawMethods();

			$data['page_title'] = 'Make Withdrawal';
			$data['page'] = 'withdraw';
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
			$data['info'] = session()->getFlashdata("error");
			return $this->view('make_withdrawal',$data);
		} 
    }

	public function Invested(){
		//if($this->notFound('invested')){ 

			$data['invested'] = $this->model->getinvested($this->User->id);

			$plans = $this->model->getPlans($this->User->id);

			$splan = array_column($plans,'name','id');

			$iplan = array_column($plans,'image','id');

			for($i = 0; $i < count($data['invested']); $i++){
				$data['invested'][$i]['time'] = date("Y/m/d", (int)$data['invested'][$i]['time']);

				$data['invested'][$i]['time_started'] = (int)$data['invested'][$i]['start'] == null ? "" : date("M d, Y", (int)$data['invested'][$i]['start']);

				$data['invested'][$i]['time_ended'] = (int)$data['invested'][$i]['end'] == null ? "" : date("M d, Y", (int)$data['invested'][$i]['end']);

				$data['invested'][$i]['amount'] = number_to_currency(floatval($data['invested'][$i]['invested']), $this->site['site_currency'],null,2);

				$data['invested'][$i]['profit2'] = number_to_currency(floatval($data['invested'][$i]['profit']), $this->site['site_currency'],null,2);

				$data['invested'][$i]['withdrawable'] = number_to_currency(floatval($data['invested'][$i]['withdrawable']), $this->site['site_currency'],null,2);

				//get plan image
				$data['invested'][$i]['plid'] = $data['invested'][$i]['plan'];

				//get plan image
				$data['invested'][$i]['image'] = $iplan[$data['invested'][$i]['plan']];

				//get plan name
				$data['invested'][$i]['plan'] = $splan[$data['invested'][$i]['plan']];
				
				if($data['invested'][$i]['status'] == 0) $data['invested'][$i]['status'] = '<span class="btn btn-outline-primary">Waiting</span>';
				if($data['invested'][$i]['status'] == 1) $data['invested'][$i]['status'] = '<span class="btn btn-outline-success">Active</span>';
				if($data['invested'][$i]['status'] == 2) $data['invested'][$i]['status'] = '<span class="btn btn-outline-warning">Paused</span>';
				if($data['invested'][$i]['status'] == 3) $data['invested'][$i]['status'] = '<span class="btn btn-outline-info">Completed</span>';
				if($data['invested'][$i]['status'] == 4) $data['invested'][$i]['status'] = '<span class="btn btn-outline-danger">Cancelled</span>';
			}

			$data['title'] = 'Your Investments';
			$data['page'] = 'invested';
			return $data;
			//return $this->view('invested',$data);
		//} 
    }
    
    public function Dashboard(){
		if($this->notFound('dashboard')){ 

			$data['table'] = $this->model->getDashboard($this->User->id);
			$data['profit'] = $this->model->getDashboardProfit($this->User->id);
			$data['invested'] = $this->model->getDashboardInvested($this->User->id);
			$data['deposit'] = $this->model->getDashboardDeposit($this->User->id);
			$data['withdraw'] = $this->model->getDashboardWithdraw($this->User->id);
			$data['referral'] = $this->model->getDashboardReferral($this->User->id);
			$data['wallet'] = $this->User->wallet;
			$data['expenses'] = $data['withdraw'] - $data['deposit'];
			
			$data['apex_data'] = intval($data['wallet']).",".intval($data['deposit']).",".intval($data['withdraw']).",".intval($data['profit']).",".intval($data['invested']).",".intval($data['referral']);
			
			$data['profit'] = number_to_currency(floatval($data['profit']), $this->site['site_currency'],null,2);
			$data['invested'] = number_to_currency(floatval($data['invested']), $this->site['site_currency'],null,2);
			$data['deposit'] = number_to_currency(floatval($data['deposit']), $this->site['site_currency'],null,2);
			$data['withdraw'] = number_to_currency(floatval($data['withdraw']), $this->site['site_currency'],null,2);
			$data['referral'] = number_to_currency(floatval($data['referral']), $this->site['site_currency'],null,2);
			$data['wallet'] = number_to_currency(floatval($data['wallet']), $this->site['site_currency'],null,2);
			$data['expenses'] = number_to_currency(floatval($data['expenses']), $this->site['site_currency'],null,2);
			
			

			for($i = 0; $i < count($data['table']); $i++){
				$data['table'][$i]['time'] = date("d-m-y g:i A", (int)$data['table'][$i]['time']);

				$data['table'][$i]['amount'] = number_to_currency(floatval($data['table'][$i]['amount']), $this->site['site_currency'],null,2);
				
				if($data['table'][$i]['action'] == 'deposit') $data['table'][$i]['action'] = '<span><i class="fa fa-arrow-up text-success mr-1"></i></span>';
				if($data['table'][$i]['action'] == 'withdraw') $data['table'][$i]['action'] = '<span><i class="fa fa-arrow-down text-danger mr-1"></i></span>';
				if($data['table'][$i]['action'] == 'invest') $data['table'][$i]['action'] = '<span><i class="fa fa-arrow-left text-warning mr-1"></i></span>';
			}
			
			$data['investments'] = $this->Invested()['invested'];
			$data['page_title'] = 'Dashboard';
			$data['page'] = 'dashboard';
			return $this->view('dashboard',$data);
		} 
        
    }

	public function Terms(){
		if($this->notFound('terms')){
            $data = $this->model->getPage('terms_key','terms_value');
            
            $data['page'] = 'terms';

			return $this->view('terms',$data);
        }

    }

    public function Privacy(){
		if($this->notFound('privacy')){
            $data = $this->model->getPage('privacy_key','privacy_value');
            
            $data['page'] = 'privacy';

			return $this->view('privacy',$data);
        }

    }

    public function Faq(){
		if($this->notFound('faq')){
            $data = $this->model->getPage('faq_key','faq_value');
            $data['faq'] = $this->model->getFaq();
    
            $data['page'] = 'faq';

			return $this->view('faq',$data);
        }

    }

	public function Products(){
		if($this->notFound('plans')){ 

			$data['products'] =  $this->model->getPlansActive();

			for($i = 0; $i < count($data['products']); $i++){
				$data['products'][$i]['minimum'] = number_to_currency(floatval($data['products'][$i]['minimum']), $this->site['site_currency'],null,2);
				$data['products'][$i]['maximum'] = number_to_currency(floatval($data['products'][$i]['maximum']), $this->site['site_currency'],null,2);

			}

			$data['page_title'] = 'Our Plans';
			$data['page'] = 'plans';
			return $this->view('plans',$data);
		} 
    }

	public function Details($pid){
		if($this->notFound('details')){ 

			$data['products'] =  $this->model->getPlansActive();

			for($i = 0; $i < count($data['products']); $i++){
				$data['products'][$i]['price'] = number_to_currency(floatval($data['products'][$i]['minimum']), $this->site['site_currency'],null,2);

			}
			
			$data['item'] =  $this->model->getPlansActiveSpecific($pid);

			for($i = 0; $i < count($data['item']); $i++){
				$data['item'][$i]['price'] = number_to_currency(floatval($data['item'][$i]['minimum']), $this->site['site_currency'],null,2);

			}

			$data['page_title'] = $data['item'][0]['name'];
			$data['page'] = 'details';
			return $this->view('details',$data);
		} 
    }

	public function Cart($pid){
		if($this->notFound('cart')){ 

			$data['item'] =  $this->model->getPlansActiveSpecific($pid);

			for($i = 0; $i < count($data['item']); $i++){
				$data['item'][$i]['pminimum'] = $data['item'][$i]['minimum'];
				$data['item'][$i]['minimum'] = number_to_currency(floatval($data['item'][$i]['minimum']), $this->site['site_currency'],null,2);
				$data['item'][$i]['maximum'] = number_to_currency(floatval($data['item'][$i]['maximum']), $this->site['site_currency'],null,2);

			}

			$data['page_title'] = $data['item'][0]['name'];
			$data['page'] = 'cart';
			$data['info'] = session()->getFlashdata("error");
			return $this->view('cart',$data);
		} 
    }

	public function MailInbox(){
		if($this->notFound('mail_inbox')){ 

			$data['mail'] = $this->model->getMailInbox($this->User->id);

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("M/j/y G:i", (int)$data['mail'][$i]['time']);
			    
				$data['mail'][$i]['short_subject'] = rtrim(mb_strimwidth($data['mail'][$i]['subject'],0,20,"..."));
			    
				$data['mail'][$i]['short_body'] = rtrim(mb_strimwidth($data['mail'][$i]['body'],0,30,"..."));
				
				if($data['mail'][$i]['read'] == 0) $data['mail'][$i]['read'] =  'unread';
				else $data['mail'][$i]['read'] =  '';
			}

			$data['page_title'] = 'Mail Inbox';
			$data['page'] = 'mail_inbox';
			return $this->view('mail_inbox',$data);
		} 
    }

	public function MailSent(){
		if($this->notFound('mail_sent')){ 

			$data['mail'] = $this->model->getMailSent($this->User->id);

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("M/j/y G:i", (int)$data['mail'][$i]['time']);
			    
				$data['mail'][$i]['short_subject'] = rtrim(mb_strimwidth($data['mail'][$i]['subject'],0,20,"..."));
			    
				$data['mail'][$i]['short_body'] = rtrim(mb_strimwidth($data['mail'][$i]['body'],0,30,"..."));
				
				if($data['mail'][$i]['read'] == 1) $data['mail'][$i]['read'] =  'unread';
				else $data['mail'][$i]['read'] =  '';
			}

			$data['page_title'] = 'Sent Mail';
			$data['info'] = session()->getFlashdata("error");
			$data['page'] = 'mail_sent';
			return $this->view('mail_sent',$data);
		} 
    }

	public function MailCompose(){
		if($this->notFound('mail_compose')){ 

			$data['page_title'] = 'Compose Mail';
			$data['info'] = session()->getFlashdata("error");
			$data['page'] = 'mail_compose';
			return $this->view('mail_compose',$data);
		} 
    }

	public function MailView($mid){
		if($this->notFound('mail_view')){ 
		    
		    if(session()->getFlashdata("mail_token") == null || session()->getFlashdata("mail_token") < now()) return redirect()->to(base_url("user/mail/update/".$mid));

			$data['mail'] = $this->model->getMail($mid);

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("F j Y g:i a", (int)$data['mail'][$i]['time']);
			    
				if($data['mail'][$i]['_to'] == $this->User->id) $data['mail'][$i]['inbox_owner'] =  'active';
				else  $data['mail'][$i]['inbox_owner'] =  '';
			    
				if($data['mail'][$i]['_from'] == $this->User->id) $data['mail'][$i]['sent_owner'] =  'active';
				else  $data['mail'][$i]['sent_owner'] =  '';
			}

			$data['page_title'] = 'View Mail';
			$data['page'] = 'mail_view';
			return $this->view('mail_view',$data);
		} 
    }

	public function Gallery(){
		if($this->notFound('gallery')){ 
            $data = $this->model->getPage('media_key','media_value');
            
            $data['media'] = $this->model->getGallery();;

			$data['page_title'] = 'Gallery';
			$data['page'] = 'gallery';
			return $this->view('gallery',$data);
		} 
    }
    
    
    
    public function view($page,$data){

        $data = array_merge($data,$this->contact);
		$data = array_merge($data,$this->site);
        $data['datez'] = now();
        $data['base_url'] = base_url();
		$data['username'] = $this->User->username;
		$data['payEmail'] = $this->User->email;
		$data['payRef'] = $this->site['site_prefix'].'-'.now();
		$data['userID'] = $this->User->id;
		$data['infoPayment'] = session()->getFlashdata("errorPayment");
		$data['fullname'] = $this->User->first_name.' '.$this->User->last_name;
		$data['mail_inbox_count'] = $this->model->getInboxCount($this->User->id);
        $data['loggedA'] = $this->ionAuth->isAdmin();
        
		//exit('<pre>'.print_r($about,true).'</pre>');

		echo $this->parser->setData($data)->render('/User/templates/header');
		echo $this->parser->setData($data)->render('/User/templates/switch');
		echo $this->parser->setData($data)->render('/User/templates/loader');
		echo $this->parser->setData($data)->render('/User/templates/sidebar');
		echo $this->parser->setData($data)->render('/User/templates/navbar');
		echo $this->parser->setData($data)->render('/User/templates/bread');
		echo $this->parser->setData($data)->render('/User/'.$page);
		echo $this->parser->setData($data)->render('/User/templates/footer');

    }
    
}