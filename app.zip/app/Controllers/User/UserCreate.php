<?php

namespace App\Controllers\User;

use App\Controllers\User\UserBaseController;

use App\Models\User\UserUpdateInsertModel;

class UserCreate extends UserBaseController{
	protected $model;

	public function __construct() {
		$this->model = new UserUpdateInsertModel();
	}

	public function index(){
		return view('welcome_message');
    }

	public function Mail(){
	    
		$this->validation->setRule('subject', 'Mail Subject', 'trim|required');
		$this->validation->setRule('body', 'Mail Body', 'trim|required');

        if ($this->request->getPost()) {
		    
    		if($this->validation->withRequest($this->request)->run()){

                $subject = $this->request->getVar("subject");
                $body = $this->request->getVar("body");

                $id = $this->User->id;
    
                    $data = array('_to' => 1, '_from' => $id, 'subject' => $subject, 'body' => $body, 'time' => now(), 'read' => 0, 'admin_delete' => 0, 'inbox' => 1);
                    
                    if ($this->model->inserter('mail', $data, true)) {
                        session()->setFlashdata("error", view('messages/single',['message' => "Mail Sent Successfully"]) );
                        return redirect()->to(base_url('user/mail/sent'));
                    }else {
                        session()->setFlashdata("error", view('errors/form/list',['errors' => ["There was an error while sending the mail"]]) );
        				return redirect()->back();
                    }
                
            }else{
        				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
        				return redirect()->back();
        	}
 
        }return redirect()->back();
    }

	public function Withdraw(){
	    
		$this->validation->setRule('amount', 'Amount', 'trim|required');
		$this->validation->setRule('method', 'Method', 'trim|required');
		$this->validation->setRule('info', 'Payment Info', 'trim|required');

        if ($this->request->getPost()) {
		    
    		if($this->validation->withRequest($this->request)->run()){

                $amount = $this->request->getVar("amount");
                $method = $this->request->getVar("method");
                $info = $this->request->getVar("info");

                $id = $this->User->id;
                $ref_id = 'Witdr-'.now();
    
                $data = array('user_id' => $id, 'status' => 0, 'time' => now(), 'amount' => $amount, 'ref_id' => $ref_id, 'reference' => $method, 'description' => $info);
                    
                    if ($this->model->inserter('withdrawal', $data, true)) {
                        return redirect()->to(base_url('user/withdraw/history'));
                    }else {
                        session()->setFlashdata("errorUpload", view('errors/form/list',['errors' => ["There was an error while processing your request"]]) );
        				return redirect()->back();
                    }
                
            }else{
        				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
        				return redirect()->back();
        	}
 
        }return redirect()->back();
    }

	public function Checkout(){

        if ($this->request->getPost()) {
	    
    	    $plan =   $this->model->getPlansActiveSpecific($this->request->getVar("id"));
    	    
    		if(count($plan) == 1){
    		    
    		        $dplan = $plan[0];
    
                    $min = $dplan['minimum'];
                    $max = $dplan['maximum'];
                    $amount =  $this->request->getVar("price");
                    $plan_id = $dplan['id'];
                    $status = $dplan['active'];
                    
                    if(!$status){
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'Product is no longer active']) );
        				return redirect()->back();
        	        }
    
                    $id = $this->User->id;
                    $wallet = $this->User->wallet;
                    $ref_id = $this->site['site_prefix'].'-inv-'.now();
                    
                    if($wallet < $min){
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'Not enough balance in your wallet']) );
        				return redirect()->back();
        	        }
        	        
                    if($amount < $min){
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'The amount you have set is below allowed minimum']) );
        				return redirect()->back();
        	        }
        	        
                    if($amount > $max){
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'The amount you have set is above allowed maximum']) );
        				return redirect()->back();
        	        }
                    
                    if($wallet < $amount){
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'Not enough balance in your wallet']) );
        				return redirect()->back();
        	        }
        
                    $data = array('user_id' => $id, 'status' => 0, 'time' => now(), 'withdrawable' => '', 'ref_id' => $ref_id, 'start' => '', 'end' => '', 'plan' => $plan_id, 'invested' => $amount, 'profit' => '');
                        
                        $bal = $wallet - $amount;
                        if($this->ionAuth->update($id, ['wallet' => $bal])){
                            if ($this->model->inserter('my_investments', $data, true)) {
                                //subtract it from users wallet
                                return redirect()->to(base_url('user/invested'));
                            }else {
                                session()->setFlashdata("error", view('errors/form/single',['error' => ["There was a update error while processing your order"]]) );
                				return redirect()->back();
                            }
                        }else {
                                session()->setFlashdata("error", view('errors/form/single',['error' => ["There was a payment error while processing your order"]]) );
                				return redirect()->back();
                        }
                    
            }else{
        				session()->setFlashdata("error", view('errors/form/single', ['error' => 'Invalid Product']) );
        				return redirect()->back();
        	}
 
        }return redirect()->back();
    }

	public function MailViewed($mid){
	    
	    $mail =   $this->model->getMailSpecific($this->User->id,$mid);
	    
		if(count($mail) == 1){
		    
		        $dmail = $mail[0];

                $status = $dmail['inbox'];
                
                if($status != 1) return redirect()->back();

                $data = array('read' => 1);
                $where = array('id' => $mid);
                
                        if($this->model->updater('mail', $data, $where,true)){
                            session()->setFlashdata("mail_token", now()+600);
                            return redirect()->to(base_url('user/mail/view/'.$mid));
                        }else return redirect()->back();
                
        }return redirect()->back();
    }

	public function MailDelete($mid){
	    
	    $mail =   $this->model->getMailSpecific($this->User->id,$mid);
	    
		if(count($mail) == 1){
		    
		        $dmail = $mail[0];

                $status = $dmail['inbox'];
                
                if($status != 1) return redirect()->back();

                $data = array('inbox' => 0);
                $where = array('id' => $mid);
                
                        if($this->model->updater('mail', $data, $where,true)){
                            return redirect()->to(base_url('user/mail/inbox'));
                        }else return redirect()->back();
                
        }return redirect()->back();
    }
}