<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\AdminBaseController;

use App\Models\Admin\AdminGetModel;

class AdminGet extends AdminBaseController{
	protected $model;

	public function __construct() {
		$this->model = new AdminGetModel();
	}

	public function notFound($page){
        if(!is_file(APPPATH.'/Views/Admin/'.$page.'.php')){
            //Whoops, we don't have a page for that!
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }else return true;
	}

	public function index(){
		return view(APPPATH.'/Views/Admin/404',$this->site);
    }

	public function Login(){
		if($this->notFound('login_history')){ 

			$data['login_history'] = $this->model->getAllLogin();
			$keys = array_keys($data['login_history']);

			for($j = 0; $j < count($data['login_history']); $j++){
    			for($i = 0; $i < count($data['login_history'][$keys[$j]]); $i++){
    				$data['login_history'][$keys[$j]][$i]['time'] = date("M d, Y g:i A", (int)$data['login_history'][$keys[$j]][$i]['time']);
    				$data['login_history'][$keys[$j]][$i]['username'] = @($this->ionAuth->user($data['login_history'][$keys[$j]][$i]['user_id'])->row()->username) ?? "";
    			}
			}

          $data['hour'] = $data['login_history']['hour'];
          $data['today'] = $data['login_history']['today'];
          $data['yesterday'] = $data['login_history']['yesterday'];
          $data['week'] = $data['login_history']['week'];
          $data['month'] = $data['login_history']['month'];
          $data['year'] = $data['login_history']['year'];
          $data['all'] = $data['login_history']['all'];

			$data['page_title'] = 'Login History';
			$data['page'] = 'login-history';
			return $this->view('login_history',$data);
		} 
    }

	public function Deposits(){
		if($this->notFound('deposit_history')){ 

			$data['deposit_history'] = $this->model->getAllDeposit();
			$keys = array_keys($data['deposit_history']);

			for($j = 0; $j < count($data['deposit_history']); $j++){
    			for($i = 0; $i < count($data['deposit_history'][$keys[$j]]); $i++){
    				
    				$data['deposit_history'][$keys[$j]][$i]['index'] = $i+1;
    				
    				$data['deposit_history'][$keys[$j]][$i]['time'] = date("d/m/y g:i A", (int)$data['deposit_history'][$keys[$j]][$i]['time']);
    				
    				$data['deposit_history'][$keys[$j]][$i]['amount'] = number_format(floatval($data['deposit_history'][$keys[$j]][$i]['amount']),2);
    				
    				$data['deposit_history'][$keys[$j]][$i]['init_amount'] = number_format(floatval($data['deposit_history'][$keys[$j]][$i]['init_amount']),2);
    				
    				$data['deposit_history'][$keys[$j]][$i]['username'] = @($this->ionAuth->user($data['deposit_history'][$keys[$j]][$i]['user_id'])->row()->username) ?? "";
    
    				if($data['deposit_history'][$keys[$j]][$i]['status'] == 0) $data['deposit_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge">Waiting</span>';
    				if($data['deposit_history'][$keys[$j]][$i]['status'] == 1) $data['deposit_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-success">Processed</span>';
    				if($data['deposit_history'][$keys[$j]][$i]['status'] == 2) $data['deposit_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-warning">Pending</span>';
    				if($data['deposit_history'][$keys[$j]][$i]['status'] == 3) $data['deposit_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-primary">Insufficient</span>';
    				if($data['deposit_history'][$keys[$j]][$i]['status'] == 4) $data['deposit_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-danger">Cancelled</span>';
    			}
			}

              $data['waiting'] = $data['deposit_history']['waiting'];
              $data['processed'] = $data['deposit_history']['processed'];
              $data['pending'] = $data['deposit_history']['pending'];
              $data['insufficient'] = $data['deposit_history']['insufficient'];
              $data['cancelled'] = $data['deposit_history']['cancelled'];
              $data['all'] = $data['deposit_history']['all'];

			$data['page_title'] = 'Deposit History';
			$data['page'] = 'Deposit-history';
			return $this->view('deposit_history',$data);
		} 
    }

	public function Withdrawal(){
		if($this->notFound('withdraw_history')){ 

			$data['withdraw_history'] = $this->model->getAllwithdrawal();
			$keys = array_keys($data['withdraw_history']);

			for($j = 0; $j < count($data['withdraw_history']); $j++){
    			for($i = 0; $i < count($data['withdraw_history'][$keys[$j]]); $i++){
    				
    				$data['withdraw_history'][$keys[$j]][$i]['index'] = $i+1;
    				
    				$data['withdraw_history'][$keys[$j]][$i]['time'] = date("d/m/y g:i A", (int)$data['withdraw_history'][$keys[$j]][$i]['time']);
    				
    				$data['withdraw_history'][$keys[$j]][$i]['amount'] = number_format(floatval($data['withdraw_history'][$keys[$j]][$i]['amount']),2);
    				
    				$data['withdraw_history'][$keys[$j]][$i]['username'] = @($this->ionAuth->user($data['withdraw_history'][$keys[$j]][$i]['user_id'])->row()->username) ?? "";
    
    				if($data['withdraw_history'][$keys[$j]][$i]['status'] == 0) $data['withdraw_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge">Waiting</span>';
    				if($data['withdraw_history'][$keys[$j]][$i]['status'] == 1) $data['withdraw_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-success">Processed</span>';
    				if($data['withdraw_history'][$keys[$j]][$i]['status'] == 2) $data['withdraw_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-warning">Pending</span>';
    				if($data['withdraw_history'][$keys[$j]][$i]['status'] == 3) $data['withdraw_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-primary">Insufficient</span>';
    				if($data['withdraw_history'][$keys[$j]][$i]['status'] == 4) $data['withdraw_history'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-danger">Cancelled</span>';
    			}
			}

              $data['waiting'] = $data['withdraw_history']['waiting'];
              $data['processed'] = $data['withdraw_history']['processed'];
              $data['pending'] = $data['withdraw_history']['pending'];
              $data['insufficient'] = $data['withdraw_history']['insufficient'];
              $data['cancelled'] = $data['withdraw_history']['cancelled'];
              $data['all'] = $data['withdraw_history']['all'];

			$data['page_title'] = 'Withdrawal History';
			$data['page'] = 'withdrawal-history';
			return $this->view('withdraw_history',$data);
		} 
    }

	public function Referral(){
		if($this->notFound('referral')){ 

			$data['referral_history'] = $this->model->getAllReferral();
			$keys = array_keys($data['referral_history']);

			for($j = 0; $j < count($data['referral_history']); $j++){
			    for($i = 0; $i < count($data['referral_history'][$keys[$j]]); $i++){
    				
    				$data['referral_history'][$keys[$j]][$i]['index'] = $i+1;
			        
    				$data['referral_history'][$keys[$j]][$i]['time_invested'] = date("d-m-Y", (int)$data['referral_history'][$keys[$j]][$i]['time_i']);
			        
    				$data['referral_history'][$keys[$j]][$i]['time'] = date("d-m-Y", (int)$data['referral_history'][$keys[$j]][$i]['time_o']);
    
    				$data['referral_history'][$keys[$j]][$i]['commission'] =  number_format(floatval($data['referral_history'][$keys[$j]][$i]['commission']),2);
    				
    				$data['referral_history'][$keys[$j]][$i]['referred'] = @($this->ionAuth->user($data['referral_history'][$keys[$j]][$i]['user_id'])->row()->username) ?? "";
    				
    				$data['referral_history'][$keys[$j]][$i]['referer'] = @($this->ionAuth->user($data['referral_history'][$keys[$j]][$i]['referer'])->row()->username) ?? "";
    				
    				if($data['referral_history'][$keys[$j]][$i]['status'] == 0) $data['referral_history'][$keys[$j]][$i]['status'] = '<span class ="badge badge-dot badge-secondary">Waiting</span>';
    				if($data['referral_history'][$keys[$j]][$i]['status'] == 1) $data['referral_history'][$keys[$j]][$i]['status'] = '<span class ="badge badge-dot badge-success">Paid</span>';
    				if($data['referral_history'][$keys[$j]][$i]['status'] == 2) $data['referral_history'][$keys[$j]][$i]['status'] = '<span class ="badge badge-dot badge-warning">Pending</span>';
    				if($data['referral_history'][$keys[$j]][$i]['status'] == 3) $data['referral_history'][$keys[$j]][$i]['status'] = '<span class ="badge badge-dot badge-danger">Cancelled</span>';
    				
    				if($data['referral_history'][$keys[$j]][$i]['valid'] == 0) $data['referral_history'][$keys[$j]][$i]['valid'] = '<span class ="badge badge-dot badge-secondary">Waiting</span>';
    				if($data['referral_history'][$keys[$j]][$i]['valid'] == 1) $data['referral_history'][$keys[$j]][$i]['valid'] = '<span class ="badge badge-dot badge-success">Invested</span>';
    				if($data['referral_history'][$keys[$j]][$i]['valid'] == 2) $data['referral_history'][$keys[$j]][$i]['valid'] = '<span class ="badge badge-dot badge-warning">Pending</span>';
    				if($data['referral_history'][$keys[$j]][$i]['valid'] == 3) $data['referral_history'][$keys[$j]][$i]['valid'] = '<span class ="badge badge-dot badge-danger">Cancelled</span>';
				}
			}

              $data['waiting'] = $data['referral_history']['waiting'];
              $data['paid'] = $data['referral_history']['paid'];
              $data['pending'] = $data['referral_history']['pending'];
              $data['cancelled'] = $data['referral_history']['cancelled'];

              $data['vwaiting'] = $data['referral_history']['vwaiting'];
              $data['vinvested'] = $data['referral_history']['vinvested'];
              $data['vpending'] = $data['referral_history']['vpending'];
              $data['vcancelled'] = $data['referral_history']['vcancelled'];
              
              $data['all'] = $data['referral_history']['all'];
			
			$data['page_title'] = 'Referral History';
			$data['page'] = 'referral';
			return $this->view('referral',$data);
		} 
    }

	public function Settings(){
		if($this->notFound('settings')){ 
		
    		$data['info'] = session()->getFlashdata("error");
    		$data['withdraw_method'] = $this->model->getAllWithdrawMethods();

			for($i = 0; $i < count($data['withdraw_method']); $i++){
			    if($data['withdraw_method'][$i]['status'] == 1) $data['withdraw_method'][$i]['istatus'] = "<span class ='badge badge-dot badge-success'>active</span>";
			    else $data['withdraw_method'][$i]['istatus'] = "<span class ='badge badge-dot badge-danger'>inactive</span>";
			}
			$data['plans'] = $this->model->getAllPlansActive();
    		$data['page_title'] = 'Site Settings';
    		$data['page'] = 'site-settings';
    		return $this->view('settings',$data); 
		
		}
    }

	public function Pages(){
		if($this->notFound('pages')){ 
		    $data = array();
    		$data['info'] = session()->getFlashdata("error");
    		
            $data['home'] = $this->model->getAllPages('home_key','home_value');
            
            $data['home'][0]['section2a'] = json_decode($data['home'][0]['section2a']);
            $data['home'][0]['section2b'] = json_decode($data['home'][0]['section2b']);
            $data['home'][0]['section2c'] = json_decode($data['home'][0]['section2c']);
            $data['home'][0]['section4a'] = json_decode($data['home'][0]['section4a']);
            $data['home'][0]['section4b'] = json_decode($data['home'][0]['section4b']);
            $data['home'][0]['section4c'] = json_decode($data['home'][0]['section4c']);
            $data['home'][0]['about_points'] = json_decode($data['home'][0]['about_points']);
            
            $data['about'] = $this->model->getAllPages('about_key','about_value');
            $data['about'][0]['stats'] = json_decode($data['about'][0]['stats']);
            $data['about'][0]['why'] = json_decode($data['about'][0]['why']);
            
            $data['services'] = $this->model->getAllPages('inv_key','inv_value');
            $data['services'][0]['packages'] = json_decode($data['services'][0]['packages']);
            
            $data['history'] = $this->model->getAllPages('history_key','history_value');
            $data['history'][0]['history2'] = json_decode($data['history'][0]['history']);
            
            $data['faq'] = $this->model->getAllPages('faq_key','faq_value');
            $data['zfaq'] = $this->model->getAllFaqs();
            
            $data['testimonial'] = $this->model->getAllPages('review_key','review_value');
            $data['ztestimonial'] = $this->model->getAllTestimonials();
            
            $data['media'] = $this->model->getAllPages('media_key','media_value');
            $data['gallery'] = $this->model->getAllGallery();
            
            $data['privacy'] = $this->model->getAllPages('privacy_key','privacy_value');
            
            $data['terms'] = $this->model->getAllPages('terms_key','terms_value');
            
            $data['covid'] = $this->model->getAllPages('covid_key','covid_value');
            
            $data['affiliate'] = $this->model->getAllPages('aff_key','aff_value');

			$data['page_title'] = 'Front Pages Settings';
    		$data['page'] = 'front-pages-settings';
    		return $this->view('pages',$data); 
		
		}
    }

	public function Newsletter(){
		if($this->notFound('newsletter')){ 

			$data['newsletter'] = $this->model->getAllNewsletter();
			$keys = array_keys($data['newsletter']);

			for($j = 0; $j < count($data['newsletter']); $j++){
    			for($i = 0; $i < count($data['newsletter'][$keys[$j]]); $i++){
    				
    				$data['newsletter'][$keys[$j]][$i]['index'] = $i+1;
    				
    				$data['newsletter'][$keys[$j]][$i]['time'] = date("d-m-Y", (int)$data['newsletter'][$keys[$j]][$i]['date']);
    
    				if($data['newsletter'][$keys[$j]][$i]['status'] == 1) $data['newsletter'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-success">Active</span>';
    				elseif($data['newsletter'][$keys[$j]][$i]['status'] == 0) $data['newsletter'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-danger">Inactive</span>';
    			}
			}

              $data['active'] = $data['newsletter']['active'];
              $data['inactive'] = $data['newsletter']['inactive'];
              $data['all'] = $data['newsletter']['all'];

			$data['page_title'] = 'Newsletter Subscribers';
			$data['page'] = 'newsletter';
			return $this->view('newsletter',$data);
		} 
    }

	public function MailInbox(){
		if($this->notFound('mail_inbox')){ 

			$data['mail'] = $this->model->getAllMailInbox();

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("M/j/y G:i", $data['mail'][$i]['time']);
			    
				$data['mail'][$i]['username'] = @($this->ionAuth->user($data['mail'][$i]['_from'])->row()->username) ?? "";
			    
				$data['mail'][$i]['fullname'] = @($this->ionAuth->user($data['mail'][$i]['_from'])->row()->first_name.' '.$this->ionAuth->user($data['mail'][$i]['_from'])->row()->last_name) ?? "";
			    
				$data['mail'][$i]['short_subject'] = rtrim(mb_strimwidth($data['mail'][$i]['subject'],0,20,"..."));
			    
				$data['mail'][$i]['short_body'] = rtrim(mb_strimwidth($data['mail'][$i]['body'],0,30,"..."));
				
				if($data['mail'][$i]['read'] == 0) $data['mail'][$i]['read2'] =  'active';
				else $data['mail'][$i]['read2'] =  '';
				
				if($data['mail'][$i]['read'] == 0) $data['mail'][$i]['read'] =  'is-unread';
				else $data['mail'][$i]['read'] =  '';
			}
			
			$data['recipients'] = json_decode(json_encode($this->ionAuth->users()->result()), true);
			
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'Mail Inbox';
			$data['page'] = 'mail_inbox';
			return $this->view('mail_inbox',$data);
		} 
    }

	public function MailView($mid){
		if($this->notFound('mail_view')){ 
		    
		    if(session()->getFlashdata("mail_token") == null || session()->getFlashdata("mail_token") < now()) return redirect()->to(base_url("admin/mail/update/".$mid));

			$data['mail'] = $this->model->getAllMail($mid);

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("F j Y g:i a", (int)$data['mail'][$i]['time']);
			    
				$data['mail'][$i]['username'] = @($this->ionAuth->user($data['mail'][$i]['_from'])->row()->username) ?? "";
			    
				$data['mail'][$i]['fullname'] = @($this->ionAuth->user($data['mail'][$i]['_from'])->row()->first_name.' '.$this->ionAuth->user($data['mail'][$i]['_from'])->row()->last_name) ?? "";
			    
				$data['mail'][$i]['username2'] = @($this->ionAuth->user($data['mail'][$i]['_to'])->row()->username) ?? "";
			    
				$data['mail'][$i]['fullname2'] = @($this->ionAuth->user($data['mail'][$i]['_to'])->row()->first_name.' '.$this->ionAuth->user($data['mail'][$i]['_to'])->row()->last_name) ?? "";
			    
				if($data['mail'][$i]['_to'] == 1) $data['mail'][$i]['inbox_owner'] = $data['inbox_owner'] =  'active';
				else  $data['mail'][$i]['inbox_owner'] = $data['inbox_owner'] =  '';
			    
				if($data['mail'][$i]['_from'] == 1) $data['mail'][$i]['sent_owner'] = $data['sent_owner']  =  'active';
				else  $data['mail'][$i]['sent_owner'] = $data['sent_owner'] =  '';
			}
			
			$data['recipients'] = json_decode(json_encode($this->ionAuth->users()->result()), true);
			
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'View Mail';
			$data['page'] = 'mail_view';
			return $this->view('mail_view',$data);
		} 
    }

	public function MailSent(){
		if($this->notFound('mail_sent')){ 

			$data['mail'] = $this->model->getAllMailSent();

			for($i = 0; $i < count($data['mail']); $i++){
			    
				$data['mail'][$i]['time'] = date("M/j/y G:i", $data['mail'][$i]['time']);
			    
				$data['mail'][$i]['username'] = @($this->ionAuth->user($data['mail'][$i]['_to'])->row()->username) ?? "";
			    
				$data['mail'][$i]['fullname'] = @($this->ionAuth->user($data['mail'][$i]['_to'])->row()->first_name.' '.$this->ionAuth->user($data['mail'][$i]['_to'])->row()->last_name) ?? "";
			    
				$data['mail'][$i]['short_subject'] = rtrim(mb_strimwidth($data['mail'][$i]['subject'],0,20,"..."));
			    
				$data['mail'][$i]['short_body'] = rtrim(mb_strimwidth($data['mail'][$i]['body'],0,30,"..."));
				
				$data['mail'][$i]['read2'] =  '';
				
				$data['mail'][$i]['read'] =  '';
			}
			
			$data['recipients'] = json_decode(json_encode($this->ionAuth->users()->result()), true);
			
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'Sent Mail';
			$data['info'] = session()->getFlashdata("error");
			$data['page'] = 'mail_sent';
			return $this->view('mail_sent',$data);
		} 
    }

	public function Users(){
		if($this->notFound('users')){

			$data['users'] =  json_decode(json_encode($this->ionAuth->users()->result()), true);
			
			$bckgs = array("bg-dark","bg-primary","bg-warning","bg-success","bg-info","bg-secondary","bg-danger");

    			for($i = 0; $i < count($data['users']); $i++){
    			    
    				$data['users'][$i]['joined'] = date("jS M Y", (int)$data['users'][$i]['created_on']);
    				
    				$data['users'][$i]['last_login'] = date("jS M Y", (int)$data['users'][$i]['last_login']);
    				
    				$data['users'][$i]['initials'] = $data['users'][$i]['first_name'][0].$data['users'][$i]['last_name'][0];
    				
    				$data['users'][$i]['bg_clr'] = $bckgs[array_rand($bckgs,1)];
    				
    				if($data['users'][$i]['active'] == 1) $data['users'][$i]['active'] = '<span class="tb-status text-success">Active</span>';
    				elseif($data['users'][$i]['active'] == 0) $data['users'][$i]['active'] = '<span class="tb-status text-warning">InActive</span>';
    				
    				if($data['users'][$i]['kyc_status'] == 0) $data['users'][$i]['kyc_status'] = '<em class="icon ni ni-alert-circle"></em><span>KYC</span>'; //waiting
    				elseif($data['users'][$i]['kyc_status'] == 1) $data['users'][$i]['kyc_status'] = '<em class="icon text-success ni ni-check-circle"></em><span>KYC</span>';//verified
    				elseif($data['users'][$i]['kyc_status'] == 2) $data['users'][$i]['kyc_status'] = '<em class="icon text-warning ni ni-alarm-alt"></em><span>KYC</span>';//pending
    				elseif($data['users'][$i]['kyc_status'] == 3) $data['users'][$i]['kyc_status'] = '<em class="icon text-danger ni ni-cross-circle"></em><span>KYC</span>';//rejected
    				
    				if($data['users'][$i]['activation_selector'] != null) $data['users'][$i]['verified'] = '<em class="icon text-info ni ni-alert-circle"></em><span>Email</span>';//unverified
    				elseif($data['users'][$i]['activation_selector'] == null) $data['users'][$i]['verified'] = '<em class="icon text-success ni ni-check-circle"></em><span>Email</span>';//verified
			
        			$data['users'][$i]['profit'] = number_format(floatval($this->model->getAllUserProfit($data['users'][$i]['id'])),2);
        			$data['users'][$i]['invested'] = number_format(floatval($this->model->getAllUserInvested($data['users'][$i]['id'])),2);
        			$data['users'][$i]['deposit'] = number_format(floatval($this->model->getAllUserDeposit($data['users'][$i]['id'])),2);
        			$data['users'][$i]['withdraw'] = number_format(floatval($this->model->getAllUserWithdraw($data['users'][$i]['id'])),2);
        			$data['users'][$i]['referral'] = number_format(floatval($this->model->getAllUserReferral($data['users'][$i]['id'])),2);
        			$data['users'][$i]['wallet'] = number_format(floatval($data['users'][$i]['wallet']),2);
        			$data['users'][$i]['expenses'] = $this->model->getAllUserWithdraw($data['users'][$i]['id']) - $this->model->getAllUserDeposit($data['users'][$i]['id']);
        			$data['users'][$i]['expenses'] = number_format(floatval($data['users'][$i]['expenses']),2);
    			}
    			
			$data['info'] = session()->getFlashdata("error");
            
            $data['total'] = count($data['users']);
			$data['page_title'] = 'Users';
			$data['page'] = 'users';
			return $this->view('users',$data);
		} 
    }
    
    private function FileFinder($path){
        $files = glob($path.'.{jpg,jpeg,png,gif}');
          if(is_array($files)){
             foreach($files as $filename){
               return $filename[0];
             }
          }
          return null;
    }

	public function UserDetails($id){
		if($this->notFound('user_detail')){ 

			$data = json_decode(json_encode($this->ionAuth->user($id)->row()), true);
			
			$bckgs = array("bg-blue-dim","bg-orange-dim","bg-teal-dim","bg-purple-dim","bg-azure-dim","bg-indigo-dim","bg-purple-dim","bg-pink-dim");
    				
    		$data['bg_clr'] = $bckgs[array_rand($bckgs,1)];
    				
    		$data['initials'] = $data['first_name'][0].$data['last_name'][0];
			
    		if($data['kyc_status'] == 0) $data['kyc_status'] = '<span class="badge badge-dim badge-sm badge-outline-dark">Waiting</span>'; //waiting
			elseif($data['kyc_status'] == 1) $data['kyc_status'] = '<span class="badge badge-dim badge-sm badge-outline-success">Approved</span>';//verified
			elseif($data['kyc_status'] == 2) $data['kyc_status'] = '<span class="badge badge-dim badge-sm badge-outline-warning">Pending</span>';//pending
			elseif($data['kyc_status'] == 3) $data['kyc_status'] = '<span class="badge badge-dim badge-sm badge-outline-danger">Failed</span>';//rejected
			
    		if($data['kyc_doc'] == 0) $data['kyc_doc'] = '~~none~~'; //national id
			elseif($data['kyc_doc'] == 1) $data['kyc_doc'] = 'National ID';//national id
			elseif($data['kyc_doc'] == 2) $data['kyc_doc'] = 'Drivers License';//drivers license
			elseif($data['kyc_doc'] == 3) $data['kyc_doc'] = 'National Passport';//passport
			elseif($data['kyc_doc'] == 4) $data['kyc_doc'] = 'Utility Bill';//utility bill
            
			$data['uname'] = $data['first_name'].' '.$data['last_name'];
			$data['created'] = date("d M, Y i:h A", $data['created_on']);
			$data['last_login'] = date("j/n/y i:h A", $data['last_login']);
			$data['dob'] = date("M d, Y", $data['dob']);
			$data['uemail'] = $data['email'];
			$data['uphone'] = $data['phone'];
			$data['uaddress'] = $data['address'];
			$data['ref_code'] = 'ref-'.$this->site['site_prefix'].'-'.$data['referral_id'];
			$data['ref_link'] = base_url('ref/ref-'.$this->site['site_prefix'].'-'.$data['referral_id']);
        	$data['wallet'] = number_format(floatval($data['wallet']),2);
        	
        	$data['kyc_front'] = $this->FileFinder(ROOTPATH.'public/kyc/front/'.strtolower($data['username']));
        	$data['kyc_back'] = $this->FileFinder(ROOTPATH.'public/kyc/back/'.strtolower($data['username']));
        	$data['kyc_selfie'] = $this->FileFinder(ROOTPATH.'public/kyc/selfie/'.strtolower($data['username']));
			
			$data['infoPass'] = session()->getFlashdata("errorPass");
			$data['infoSettings'] = session()->getFlashdata("errorSettings");
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = ucfirst($data['username']).'\'s Profile';
			$data['page'] = 'user-detail';
			return $this->view('user_detail',$data);
		} 
    }
    
    public function Plans(){
		if($this->notFound('plans')){ 

			$data['plans']['all'] = $this->model->getAllPlans();
			$data['plans']['active'] = $this->model->getAllPlansActive();
			$data['plans']['inactive'] = $this->model->getAllPlansInActive();
			$keys = array_keys($data['plans']);

			for($j = 0; $j < count($data['plans']); $j++){
    			for($i = 0; $i < count($data['plans'][$keys[$j]]); $i++){
    				$data['plans'][$keys[$j]][$i]['minimum'] =  number_format(floatval($data['plans'][$keys[$j]][$i]['minimum']),2);
    				$data['plans'][$keys[$j]][$i]['maximum'] =  number_format(floatval($data['plans'][$keys[$j]][$i]['maximum']),2);
    
    				if($data['plans'][$keys[$j]][$i]['active'] == 0) $data['plans'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-danger">Inactive</span>';
    				elseif($data['plans'][$keys[$j]][$i]['active'] == 1) $data['plans'][$keys[$j]][$i]['status'] = '<span class="shadow-none badge badge-success">Active</span>';
    			}
			}

              $data['active'] = $data['plans']['active'];
              $data['inactive'] = $data['plans']['inactive'];
              $data['all'] = $data['plans']['all'];
              
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'Investment Plans';
			$data['page'] = 'plans';
			return $this->view('plans',$data);
		} 
        
    }

	public function Investment(){
		if($this->notFound('invested')){ 

			$data['invested'] = $this->model->getAllInvested();
			$keys = array_keys($data['invested']);

			$plans = $this->model->getAllPlans();
			$splan = array_column($plans,'name','id');

			for($j = 0; $j < count($data['invested']); $j++){

    			for($i = 0; $i < count($data['invested'][$keys[$j]]); $i++){
    				$data['invested'][$keys[$j]][$i]['time'] = date("d/m/Y", (int)$data['invested'][$keys[$j]][$i]['time']);
			    
				    $data['invested'][$keys[$j]][$i]['username'] = @($this->ionAuth->user($data['invested'][$keys[$j]][$i]['user_id'])->row()->username) ?? "";
    
    				$data['invested'][$keys[$j]][$i]['time_started'] = $data['invested'][$keys[$j]][$i]['start'] != null ? date("d/m/Y", (int)$data['invested'][$keys[$j]][$i]['start']) : "";
    
    				$data['invested'][$keys[$j]][$i]['time_ended'] = $data['invested'][$keys[$j]][$i]['end'] != null ?  date("d/m/Y", (int)$data['invested'][$keys[$j]][$i]['end']) : "";
    
    				$data['invested'][$keys[$j]][$i]['amount'] = number_to_currency(floatval($data['invested'][$keys[$j]][$i]['invested']), $this->site['site_currency'],null,2);
    
    				$data['invested'][$keys[$j]][$i]['profit'] = number_to_currency(floatval($data['invested'][$keys[$j]][$i]['profit']), $this->site['site_currency'],null,2);
    
    				$data['invested'][$keys[$j]][$i]['withdraw'] = number_to_currency(floatval($data['invested'][$keys[$j]][$i]['withdrawable']), $this->site['site_currency'],null,2);
    
    				//get plan name
    				$data['invested'][$keys[$j]][$i]['plan'] = $splan[$data['invested'][$keys[$j]][$i]['plan']];
    				
    				if($data['invested'][$keys[$j]][$i]['status'] == 0) $data['invested'][$keys[$j]][$i]['status'] = '<span class="badge badge-outline-dark">Waiting</span>';
    				if($data['invested'][$keys[$j]][$i]['status'] == 1) $data['invested'][$keys[$j]][$i]['status'] = '<span class="badge badge-outline-success">Active</span>';
    				if($data['invested'][$keys[$j]][$i]['status'] == 2) $data['invested'][$keys[$j]][$i]['status'] = '<span class="badge badge-outline-warning">Paused</span>';
    				if($data['invested'][$keys[$j]][$i]['status'] == 3) $data['invested'][$keys[$j]][$i]['status'] = '<span class="badge badge-outline-info">Completed</span>';
    				if($data['invested'][$keys[$j]][$i]['status'] == 4) $data['invested'][$keys[$j]][$i]['status'] = '<span class="badge badge-outline-danger">Cancelled</span>';
    			}
			}

              $data['waiting'] = $data['invested']['waiting'];
              $data['active'] = $data['invested']['active'];
              $data['paused'] = $data['invested']['paused'];
              $data['completed'] = $data['invested']['completed'];
              $data['cancelled'] = $data['invested']['cancelled'];
              $data['all'] = $data['invested']['all'];
              $data['plans'] = $plans;
              $data['users'] = json_decode(json_encode($this->ionAuth->users()->result()), true);
              
			$data['info'] = session()->getFlashdata("error");

			$data['page_title'] = 'Investments';
			$data['page'] = 'invested';
			return $this->view('invested',$data);
		} 
    }
    
    ///=================================================================================================================
    
    public function Dashboard(){
		if($this->notFound('dashboard')){ 

			$data['DepositT'] = number_format(floatval($this->model->getDashboardDepositTotal()),2);
			$data['DepositW'] = number_format(floatval($this->model->getDashboardDepositMonth()),2);
			$data['DepositM'] = number_format(floatval($this->model->getDashboardDepositWeek()),2);

			$data['WithdrawalT'] = number_format(floatval($this->model->getDashboardWithdrawalTotal()),2);
			$data['WithdrawalW'] = number_format(floatval($this->model->getDashboardWithdrawalMonth()),2);
			$data['WithdrawalM'] = number_format(floatval($this->model->getDashboardWithdrawalWeek()),2);

			$data['ReferralT'] = number_format(floatval($this->model->getDashboardReferralTotal()),2);
			$data['ReferralW'] = number_format(floatval($this->model->getDashboardReferralMonth()),2);
			$data['ReferralM'] = number_format(floatval($this->model->getDashboardReferralWeek()),2);

			$data['InvestedT'] = number_format(floatval($this->model->getDashboardInvestedTotal()),2);
			$data['InvestedW'] = number_format(floatval($this->model->getDashboardInvestedMonth()),2);
			$data['InvestedM'] = number_format(floatval($this->model->getDashboardInvestedWeek()),2);

			$data['WithdrawableT'] = number_format(floatval($this->model->getDashboardWithdrawableTotal()),2);
			$data['WithdrawableW'] = number_format(floatval($this->model->getDashboardWithdrawableMonth()),2);
			$data['WithdrawableM'] = number_format(floatval($this->model->getDashboardWithdrawableWeek()),2);

			$data['ProfitT'] = number_format(floatval($this->model->getDashboardProfitTotal()),2);
			$data['ProfitW'] = number_format(floatval($this->model->getDashboardProfitMonth()),2);
			$data['ProfitM'] = number_format(floatval($this->model->getDashboardProfitWeek()),2);

			$data['UsersT'] = $this->model->getDashboardUsersTotal();
			$data['UsersW'] = $this->model->getDashboardUsersMonth();
			$data['UsersM'] = $this->model->getDashboardUsersWeek();

			$data['WalletT'] = number_format(floatval($this->model->getDashboardWalletTotal()),2);
			$data['WalletW'] = number_format(floatval($this->model->getDashboardWalletMonth()),2);
			$data['WalletM'] = number_format(floatval($this->model->getDashboardWalletWeek()),2);

			$data['MailT'] = $this->model->getDashboardMailTotal();
			$data['MailW'] = $this->model->getDashboardMailMonth();
			$data['MailM'] = $this->model->getDashboardMailWeek();

			$data['plans'] = $this->model->getAllPlans();

			
			$bckgs = array("bg-blue-dim","bg-orange-dim","bg-teal-dim","bg-purple-dim","bg-azure-dim","bg-indigo-dim","bg-purple-dim","bg-pink-dim");
    			for($i = 0; $i < count($data['plans']); $i++){
    			    $data['plans'][$i]['bg_clr'] = $bckgs[array_rand($bckgs,1)];
    			    
    				if($data['plans'][$i]['active'] == 0) $data['plans'][$i]['status'] = '<span class="tb-sub text-danger">Inactive</span>';
    				elseif($data['plans'][$i]['active'] == 1) $data['plans'][$i]['status'] = '<span class="tb-sub text-success">Active</span>';
    				
    			    $data['plans'][$i]['subscribers'] = $this->model->getDashboardCount($data['plans'][$i]['id']);
    			    
    			    $data['plans'][$i]['invested'] = $this->model->getDashboardSum($data['plans'][$i]['id']) ?? "";
    			    
    			    $data['plans'][$i]['initials'] = strtoupper($data['plans'][$i]['name'])[0].strtoupper($data['plans'][$i]['name'])[1];
    			    
    			}

			$data['page_title'] = 'Dashboard';
			$data['page'] = 'dashboard';
			return $this->view('dashboard',$data);
		} 
        
    }
    
    ///=================================================================================================================
    
    public function view($page,$data){

        $data = array_merge($data,$this->contact);
		$data = array_merge($data,$this->site);
        $data['datez'] = now();
        $data['base_url'] = base_url();
		$data['username'] = $this->User->username;
		$data['payEmail'] = $this->User->email;
		$data['userID'] = $this->User->id;
		$data['fullname'] = $this->User->first_name.' '.$this->User->last_name;
		$data['fname_init'] = $this->User->first_name[0].' '.$this->User->last_name[0];
		$data['mail_inbox_count'] = $this->model->getAllInboxCount();
		$data['toast'] = session()->getFlashdata("toast");
        
		//exit('<pre>'.print_r($about,true).'</pre>');

		echo $this->parser->setData($data)->render('/Admin/templates/header');
		echo $this->parser->setData($data)->render('/Admin/'.$page);
		echo $this->parser->setData($data)->render('/Admin/templates/footer');

    }
    
}