<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\AdminBaseController;

use App\Models\Admin\AdminDeleteModel;
use CodeIgniter\Controller;

class AdminDelete extends AdminBaseController{
	protected $model;

	public function __construct() {
		$this->model = new AdminDeleteModel();
	}

	public function index(){
		return view('welcome_message');
    }

	public function Deposits($id){
	   if($this->model->Deposits($id))session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Withdrawals($id){
	   if($this->model->Withdrawals($id))session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Referrals($id){
	   if($this->model->Referrals($id))session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Settings($id){
	   if($this->model->Settings($id))session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Newsletter($id){
	   if($this->model->Newsletter($id))session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function UserDelete($id){

		if (!$this->ionAuth->loggedIn()){
			return redirect()->to('login');

		};
        		    
		    if(true){
		            // check to see if we are updating the user
    				if ($this->ionAuth->deleteUser($id)){
    					session()->setFlashdata("error", $this->ionAuth->messages() );
    					$this->model->wiper($id);
        				return redirect()->back();
    				}else{
    					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
            			return redirect()->back();
    				}
    				// redirect them back to the admin page if admin, or to the base url if non admin
    				return  redirect()->to(base_url('admin/users'));
		    }
		
		
		redirect()->back();
	}

	public function Plan($id){
	   if($this->model->Plan($id)) session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Investment($id){
	   if($this->model->Investment($id)) session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Faq($id){
	   if($this->model->Faq($id)) session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Testimonials($id){
	   if($this->model-Testimonials($id)) session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }

	public function Gallery($id){
	   if($this->model->Gallery($id)) session()->setFlashdata("toast", true); 
	   else session()->setFlashdata("toast", false); 
	   return redirect()->back();
    }
    
}