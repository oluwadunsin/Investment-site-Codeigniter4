<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\AdminBaseController;

use App\Models\Admin\AdminUpdateInsertModel;

class AdminCreate extends AdminBaseController{
	protected $model;
	
    protected $validation;

	public function __construct() {
		$this->model = new AdminUpdateInsertModel();
		
		//validation
        $this->validation = \Config\Services::validation();

		$this->configIonAuth = config('IonAuth');
	}

	public function index(){
		return view('welcome_message');
    }

	public function Deposits(){
		if ($this->request->getPost()){

                $id = $this->request->getVar("id");
                $status = $this->request->getVar("status");
                $description = $this->request->getVar("description");
    
                    $data = array('status' => $status, 'description' => $description);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('deposit', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
 
        }
        return redirect()->back();
    }

	public function Withdrawals(){
		if ($this->request->getPost()){

                $id = $this->request->getVar("id");
                $status = $this->request->getVar("status");
                $description = $this->request->getVar("description");
    
                    $data = array('status' => $status, 'description' => $description);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('withdrawal', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
 
        }
        return redirect()->back();
    }

	public function Referrals(){
		if ($this->request->getPost()){

                $id = $this->request->getVar("id");
                $status = $this->request->getVar("status");
                $validity = $this->request->getVar("validity");
                $commission = $this->request->getVar("commission");
    
                    $data = array('status' => $status, 'valid' => $validity, 'commission' => $commission);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('referral', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
 
        }
        return redirect()->back();
    }

	public function Settings(){
		if ($this->request->getPost()){
		    
		    if($this->request->getVar("section") == "logo"){
		         
		        $file = $this->request->getFile("logo");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('logo', 'Logo', 'uploaded[logo]|max_size[logo,5024]|is_image[logo]|mime_in[logo,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
                        $to = ROOTPATH.'public/common/assets/images/logo/logo.png';
                        if(file_exists($to))unlink($to);
            			$change = $this->imageUpload('logo','logo',ROOTPATH.'public/common/assets/images/logo',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    /**$profileImg = $this->request->getFile("logo");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/logo.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/logo/logo.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,400,75)){
                                        unlink($from);**/
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Logo Uploaded Successfully"]) );
                                    /**}else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Logo Image Conversion Failed"]]) );
                        			}**/
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Logo Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		
		            
		        }
		         
		        $file = $this->request->getFile("favicon");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('favicon', 'Favicon', 'uploaded[favicon]|max_size[favicon,5024]|is_image[favicon]|mime_in[favicon,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('favicon','favicon',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("favicon");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/favicon.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/x-icon/favicon.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,100,100)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Favicon Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Favicon Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Favicon Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		
		            
		        }
		    }
		    
		    if($this->request->getVar("section") == "core"){
		        $data = array();
		        $data['site_prefix'] = $this->request->getVar("site_prefix");
		        $data['site_name'] = $this->request->getVar("site_name");
		        $data['site_currency'] = $this->request->getVar("site_currency");
		        $data['site_description'] = $this->request->getVar("site_description");
		        $data['time_zone'] = $this->request->getVar("time_zone");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "seo"){
		        $data = array();
		        $data['seo_keywords'] = $this->request->getVar("seo_keywords");
		        $data['seo_description'] = $this->request->getVar("seo_description");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "contact"){
		        $data = array();
		        $data['contact_heading'] = $this->request->getVar("contact_heading");
		        $data['newsletter_heading'] = $this->request->getVar("newsletter_heading");
		        $data['week_begin'] = $this->request->getVar("week_begin");
		        $data['week_end'] = $this->request->getVar("week_end");
		        $data['time_begin'] = $this->request->getVar("time_begin");
		        $data['time_end'] = $this->request->getVar("time_end");
		        $data['email'] = $this->request->getVar("email");
		        $data['phone'] = $this->request->getVar("phone");
		        $data['address'] = $this->request->getVar("address");
		        $data['map'] = $this->request->getVar("map");
		        $data['facebook'] = $this->request->getVar("facebook");
		        $data['instagram'] = $this->request->getVar("instagram");
		        $data['twitter'] = $this->request->getVar("twitter");
		        $data['whatsapp'] = $this->request->getVar("whatsapp");
		        $data['linkedin'] = $this->request->getVar("linkedin");
		        $data['google'] = $this->request->getVar("google");
		        $data['youtube'] = $this->request->getVar("youtube");
		        $data['telegram'] = $this->request->getVar("telegram");
		        $data['contact_sub_heading'] = $this->request->getVar("contact_sub_heading");
		        $data['nsub_heading_1'] = $this->request->getVar("nsub_heading_1");
		        $data['nsub_heading_2'] = $this->request->getVar("nsub_heading_2");
		        $data['nsub_heading_3'] = $this->request->getVar("nsub_heading_3");
		        
		        $where = 'contact_key';
		        $column = 'contact_value';
		        
		        if($this->model->replacer('contact', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "smtp"){
		        $data = array();
		        $data['from_email'] = $this->request->getVar("from_email");
		        $data['from_sender'] = $this->request->getVar("from_sender");
		        $data['reply_email'] = $this->request->getVar("reply_email");
		        $data['reply_to'] = $this->request->getVar("reply_to");
		        $data['smtp_host'] = $this->request->getVar("smtp_host");
		        $data['smtp_username'] = $this->request->getVar("smtp_username");
		        $data['smtp_password'] = $this->request->getVar("smtp_password");
		        $data['smtp_port'] = $this->request->getVar("smtp_port");
		        $data['smtp_timeout'] = $this->request->getVar("smtp_timeout");
		        $data['smtp_keepAlive'] = $this->request->getVar("smtp_keepAlive");
		        $data['smtp_encryption'] = $this->request->getVar("smtp_encryption");
		        
		        $where = 'contact_key';
		        $column = 'contact_value';
		        
		        if($this->model->replacer('contact', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "captcha"){
		        $data = array();
		        $data['captcha_enabled'] = $this->request->getVar("captcha_enabled");
		        $data['captcha_public_key'] = $this->request->getVar("captcha_public_key");
		        $data['captcha_private_key'] = $this->request->getVar("captcha_private_key");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "scripts"){
		        $data = array();
		        $data['head_tag'] = $this->request->getVar("head_tag");
		        $data['body_tag'] = $this->request->getVar("body_tag");
		        $data['close_body_tag'] = $this->request->getVar("close_body_tag");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "announcement"){
		        $data = array();
		        $data['site_notif_in'] = $this->request->getVar("site_notif_in");
		        $data['site_notif_out'] = $this->request->getVar("site_notif_out");
		        $data['enable_jumbotron'] = $this->request->getVar("enable_jumbotron");
		        $data['jumbotron_heading'] = $this->request->getVar("jumbotron_heading");
		        $data['jumbotron_body_1'] = $this->request->getVar("jumbotron_body_1");
		        $data['jumbotron_body_2'] = $this->request->getVar("jumbotron_body_2");
		        $data['jumbotron_sub-heading1'] = $this->request->getVar("jumbotron_sub-heading1");
		        $data['jumbotron_sub-heading2'] = $this->request->getVar("jumbotron_sub-heading2");
		        $data['jumbotron_btn1'] = $this->request->getVar("jumbotron_btn1");
		        $data['jumbotron_btn1-link'] = $this->request->getVar("jumbotron_btn1-link");
		        $data['jumbotron_img'] = $this->request->getVar("jumbotron_img");
		        $data['jumbotron_btn2'] = $this->request->getVar("jumbotron_btn2");
		        $data['jumbotron_btn2-link'] = $this->request->getVar("jumbotron_btn2-link");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "authentication"){
		        $data = array();
		        $data['allow_signup'] = $this->request->getVar("allow_signup");
		        $data['allow_login'] = $this->request->getVar("allow_login");
		        $data['auto_activate'] = $this->request->getVar("auto_activate");
		        $data['is_kyc'] = $this->request->getVar("is_kyc");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "rates"){
		        $data = array();
		        $data['referral_rate'] = $this->request->getVar("referral_rate");
		        $data['referral_plan'] = $this->request->getVar("referral_plan");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "payment"){
		        $data = array();
		        $data['allow_deposit'] = $this->request->getVar("allow_deposit");
		        $data['enable_paystack'] = $this->request->getVar("enable_paystack");
		        $data['paystack_public'] = $this->request->getVar("paystack_public");
		        $data['paystack_secret'] = $this->request->getVar("paystack_secret");
		        $data['paystack_description'] = $this->request->getVar("paystack_description");
		        
		        $data['enable_coinpayment'] = $this->request->getVar("enable_coinpayment");
		        $data['coinpayments_merchant'] = $this->request->getVar("coinpayments_merchant");
		        $data['coinpayments_ipn'] = $this->request->getVar("coinpayments_ipn");
		        $data['coinpayments_description'] = $this->request->getVar("coinpayments_description");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "withdrawal"){
		        $data = array();
		        $data['allow_withdrawal'] = $this->request->getVar("allow_withdrawal");
		        
		        $where = 'site_key';
		        $column = 'site_value';
		        
		        if($this->model->replacer('site', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "method-edit"){
		        $data = array();
		        $data['method'] = ucfirst($this->request->getVar("method"));
		        $data['currency'] = $this->request->getVar("currency");
		        $data['charge'] = $this->request->getVar("charge");
		        $data['minimum'] = $this->request->getVar("minimum");
		        $data['maximum'] = $this->request->getVar("maximum");
		        $data['delay'] = $this->request->getVar("delay");
		        $data['status'] = $this->request->getVar("status");
                
                $where = array('id' => $this->request->getVar("id"));
		        
		        if($this->model->updater('withdrawal_method', $data, $where,true)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "method-create"){
		        $data = array();
		        $data['method'] = $this->request->getVar("method");
		        $data['currency'] = $this->request->getVar("currency");
		        $data['charge'] = $this->request->getVar("charge");
		        $data['minimum'] = $this->request->getVar("minimum");
		        $data['maximum'] = $this->request->getVar("maximum");
		        $data['delay'] = $this->request->getVar("delay");
		        $data['status'] = $this->request->getVar("status");
		        
		        if($this->model->inserter('withdrawal_method', $data, true)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
                    
                    
 
        }
        return redirect()->to('settings');
    }

	public function Newsletter(){
		if ($this->request->getPost()){

                $id = $this->request->getVar("id");
                $status = $this->request->getVar("status");
                $email = $this->request->getVar("email");
    
                    $data = array('status' => $status, 'email' => $email);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('newsletter', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
 
        }
        return redirect()->back();
    }

	public function Mail(){
	    
		$this->validation->setRule('subject', 'Mail Subject', 'trim|required');
		$this->validation->setRule('body', 'Mail Body', 'trim|required');

        if ($this->request->getPost()) {
		    
    		if($this->validation->withRequest($this->request)->run()){

                $subject = $this->request->getVar("subject");
                $body = $this->request->getVar("body");
                $id = $this->request->getVar("recipient");
    
                    $data = array('_to' => $id, '_from' => 1, 'subject' => $subject, 'body' => $body, 'time' => now(), 'read' => 0, 'admin_delete' => 0, 'inbox' => 1);
                    
                    if ($this->model->inserter('mail', $data, true)) {
                        session()->setFlashdata("error", view('messages/single',['message' => "Mail Sent Successfully"]) );
                        return redirect()->back();
                    }else {
                        session()->setFlashdata("error", view('errors/form/list',['errors' => ["There was an error while sending the mail"]]) );
        				return redirect()->back();
                    }
                
            }else{
        				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
        				return redirect()->back();
        	}
 
        }return redirect()->back();
    }

	public function MailDelete($mid){
	    
	    $mail =   $this->model->getMailSpecific(1,$mid);
	    
		if(count($mail) == 1){
		    
		        $dmail = $mail[0];

                $status = $dmail['inbox'];
                
                if($status != 1) return redirect()->back();

                $data = array('inbox' => 0);
                $where = array('id' => $mid);
                
                        if($this->model->updater('mail', $data, $where,true)){
                            session()->setFlashdata("toast", true);
                            return redirect()->to(base_url('admin/mail'));
                        }else{
                            session()->setFlashdata("toast", false); 
                            return redirect()->back();
                        }
                
        }return redirect()->back();
    }

	public function MailViewed($mid){
	    
	    $mail =   $this->model->getMailSpecific(1,$mid);
	    
		if(count($mail) == 1){
		    
		        $dmail = $mail[0];

                $status = $dmail['inbox'];
                
                if($status != 1) return redirect()->back();

                $data = array('read' => 1);
                $where = array('id' => $mid);
                
                        if($this->model->updater('mail', $data, $where,true)){
                            session()->setFlashdata("mail_token", now()+600);
                            return redirect()->to(base_url('admin/mail/view/'.$mid));
                        }else return redirect()->back();
                
        }return redirect()->back();
    }

	public function UserSettings(){

		if (!$this->ionAuth->loggedIn()){
			return redirect()->to('login');

		};
		
		if ($this->request->getPost()){

            $id = $this->request->getVar('id');
            $section = $this->request->getVar('section');
    		$user = $this->ionAuth->user($id)->row();
		    $email = $user->email;
    		$groups        = $this->ionAuth->groups()->resultArray();
    		$currentGroups = $this->ionAuth->getUsersGroups($id)->getResult();
    		$tables       = $this->configIonAuth->tables;
    		$data = Array();
    		
    		if(!empty($_POST) && $section == "wallet") $data['wallet'] = $this->request->getVar('wallet');
    		
    		if (!empty($_POST) && $section == "profile"){
    			// validate form input
    			$this->validation->setRule('uname', 'Username', 'trim|required');
    			$this->validation->setRule('fname', lang('Auth.edit_user_validation_fname_label'), 'trim|required');
    			$this->validation->setRule('lname', lang('Auth.edit_user_validation_lname_label'), 'trim|required');
    			$this->validation->setRule('phone', lang('Auth.edit_user_validation_phone_label'), 'trim|required');
    			$this->validation->setRule('address', 'Your Address', 'trim|required');
    			$this->validation->setRule('bio', 'Your bio', 'trim|required');
    			$this->validation->setRule('dobY', 'Your Birth Year', 'trim|integer|required');
    			$this->validation->setRule('dobM', 'Your Birth Month', 'trim|integer|required');
    			$this->validation->setRule('dobD', 'Your Birth Day', 'trim|integer|required');
    			$this->validation->setRule('email', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email|is_unique[' . $tables['users'] . '.email,'.$tables['users'] . '.email,'.$email.']');
    			//$this->validation->setRule('company', lang('Auth.edit_user_validation_company_label'), 'trim|required');
    
    		    
        		    if($this->validation->withRequest($this->request)->run()){
        		            
                            $dob = strtotime($this->request->getVar('dobY')."-".$this->request->getVar('dobM')."-".$this->request->getVar('dobD'));
            				$data = [
            					'first_name' => $this->request->getVar('fname'),
            					'last_name'  => $this->request->getVar('lname'),
            					//'company'    => $this->request->getPost('company'),
            					'phone'      => $this->request->getVar('phone'),
            					'bio'      => $this->request->getVar('bio'),
            					'email'      => $this->request->getVar('email'),
            					'address'      => $this->request->getVar('address'),
            					'dob' => $dob
            				];
            				
            		}else{
        				session()->setFlashdata("errorSettings", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
        				return redirect()->back();
        		    }
        		    
			}
        		    
		    if(!empty($data)){
		            // check to see if we are updating the user
    				if ($this->ionAuth->update($user->id, $data)){
    					session()->setFlashdata("error", $this->ionAuth->messages() );
        				return redirect()->back();
    				}else{
    					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
            			return redirect()->back();
    				}
    				// redirect them back to the admin page if admin, or to the base url if non admin
    				return  redirect()->to(base_url('admin/users'));
		    }
			
		} redirect()->back();
	}

	public function UserActivate($id){

		if (!$this->ionAuth->loggedIn()){
			return redirect()->to('login');

		};
        		    
		    if(true){
		            // check to see if we are updating the user
    				if ($this->ionAuth->activate($id)){
    					session()->setFlashdata("error", $this->ionAuth->messages() );
        				return redirect()->back();
    				}else{
    					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
            			return redirect()->back();
    				}
    				// redirect them back to the admin page if admin, or to the base url if non admin
    				return  redirect()->to(base_url('admin/users'));
		    }
		
		
		redirect()->back();
	}

	public function UserDeactivate($id){

		if (!$this->ionAuth->loggedIn()){
			return redirect()->to('login');

		};
        		    
		    if(true){
		            // check to see if we are updating the user
    				if ($this->ionAuth->deactivate($id)){
    					session()->setFlashdata("error", $this->ionAuth->messages() );
        				return redirect()->back();
    				}else{
    					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
            			return redirect()->back();
    				}
    				// redirect them back to the admin page if admin, or to the base url if non admin
    				return  redirect()->to(base_url('admin/users'));
		    }
		
		
		redirect()->back();
	}
	
	public function UserKyc($id,$status){
	            $data = array('kyc_status'=>$status);
	            
	            // check to see if we are updating the user
				if ($this->ionAuth->update($id, $data)){
					session()->setFlashdata("error", $this->ionAuth->messages() );
    				return redirect()->back();
				}else{
					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
        			return redirect()->back();
				}
				// redirect them back to the admin page if admin, or to the base url if non admin
				return  redirect()->to(base_url('admin/users'));
	}

	public function UserPassword(){
	    
		if (! $this->ionAuth->loggedIn()) return redirect()->to(base_url('login'));
		
		$this->validation->setRule('old', lang('Auth.change_password_validation_old_password_label'), 'required');
		$this->validation->setRule('password', lang('Auth.change_password_validation_new_password_label'), 'required|min_length[' . $this->configIonAuth->minPasswordLength . ']|matches[cpassword]');
		$this->validation->setRule('cpassword', lang('Auth.change_password_validation_new_password_confirm_label'), 'required');


		if ($this->request->getPost()){
			
			if ($this->validation->withRequest($this->request)->run()){
		        
		        $user = $this->request->getVar('id');
			    
    			$identity = $this->session->get('identity');
    
    			$change = $this->ionAuth->changePassword($this->request->getVar('email'), $this->request->getVar('old'), $this->request->getVar('password'));
    
    			if ($change){
    				//if the password was successfully changed
            		session()->setFlashdata("error", $this->ionAuth->messages() );
    				return redirect()->to(base_url('admin/users'));
    			}else{
    				session()->setFlashdata("errorPass", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
    				return redirect()->back();
    			}
    			
			}else{
    				session()->setFlashdata("errorPass", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}
	
	public function PlanImageDelete($id){
	    $plan = $this->model->getAllPlansActive($id);
	    $zplan = array_column($plan,'image','id');
    
        $data = array('image' => '');
        $where = array('id' => $id);
	    
	    if($this->model->updater('plans', $data, $where,true)){
    	    if(file_exists(ROOTPATH.'public/products/'.$zplan[$id])) if(unlink(ROOTPATH.'public/products/'.$zplan[$id])) session()->setFlashdata("toast", true);
    	    else  session()->setFlashdata("toast", false);
	    }else  session()->setFlashdata("toast", false);
	    return redirect()->back();
	}

	public function Plan(){
		if ($this->request->getPost()){
		        
		        $data = array();
		        $data['name'] = $this->request->getVar("name");
		        $data['active'] = $this->request->getVar("active");
		        $data['description'] = $this->request->getVar("description");
		        $data['description_long'] = $this->request->getVar("description_long");
		        $data['feature1'] = $this->request->getVar("feature1");
		        $data['feature2'] = $this->request->getVar("feature2");
		        $data['feature3'] = $this->request->getVar("feature3");
		        $data['feature4'] = $this->request->getVar("feature4");
		        $data['feature5'] = $this->request->getVar("feature5");
		        $data['percent'] = $this->request->getVar("percent");
		        $data['minimum'] = $this->request->getVar("minimum");
		        $data['maximum'] = $this->request->getVar("maximum");
		        $data['period'] = $this->request->getVar("period");
		        $data['period_name'] = $this->request->getVar("period_name");
		    
		    if($this->request->getVar("section") == "plan-edit"){
		        $file = $this->request->getFile("image");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('image', 'image', 'uploaded[image]|max_size[image,5024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
                        $Img = $this->request->getFile("image");
                        $imgName = $this->request->getVar("id");
                        $ext = $Img->getClientExtension();
		                $data['image'] = $imgName.'.'.$ext;
                        $to = ROOTPATH.'public/products/';
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change = $this->imageUpload('image',$imgName,$to,false);
                        
            			if ($change) session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                        else session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			
        			}else session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    		
		        }
		        
            
                $where = array('id' => $this->request->getVar("id"));
                
		        if($this->model->updater('plans', $data, $where,true)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "plan-create"){
		        $id = (int)$this->model->inserter('plans', $data, true);
		        if($id) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		         
		        $file = $this->request->getFile("image");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('image', 'image', 'uploaded[image]|max_size[image,5024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
                        $Img = $this->request->getFile("image");
                        $imgName = $id;
                        $to = ROOTPATH.'public/products/';
                        $ext = $Img->getClientExtension();
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change = $this->imageUpload('image',$imgName,$to,false);
                        
            			if ($change) session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                        else session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
		        
            
                        $where = array('id' => $id);
                        
        		        if($this->model->updater('plans', array('image' => $imgName.'.'.$ext), $where,true)) session()->setFlashdata("toast", true);
                        else session()->setFlashdata("toast", false);
            			
        			}else session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    		
		            
		        }
		    }
            
            return redirect()->to('plans');
        }
        return redirect()->to('plans');
    }

	public function Investment(){
		if ($this->request->getPost()){
		        
		        $data = array();
		        $data['plan'] = $this->request->getVar("plan");
		        $data['withdrawable'] = $this->request->getVar("withdrawable");
		        $data['start'] = strtotime(str_replace('/','-',$this->request->getVar("start")));
		        $data['end'] = strtotime(str_replace('/','-',$this->request->getVar("end")));
		        $data['invested'] = $this->request->getVar("invested");
		        $data['profit'] = $this->request->getVar("profit");
		        $data['status'] = $this->request->getVar("status");
		    
		    if($this->request->getVar("section") == "edit"){
		        
		        $where = array('id' => $this->request->getVar("id"));
		        $rid = $this->request->getVar("id");
                
		        if($this->model->updater('my_investments', $data, $where,true)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "create"){
		        $data['time'] = now();
		        $data['user_id'] = $this->request->getVar("uid");
		        $data['ref_id'] = $this->site['site_prefix'].'-inv-'.now();
		        $rid = $this->request->getVar("uid");
		        
		        $id = $this->model->inserter('my_investments', $data, true);
		        if($id) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    } 
		    //calculate_referral
		    $ref_plan = $this->site['referral_plan'];
		    $ref_comm = $this->site['referral_rate'];
		    
		    if($ref_plan == $this->request->getVar("plan")){
		        $ref =  getReferralSpecific($rid);
		        if($ref['time_o'] == null && $ref['user_id'] != null){
		            $data = array();
		            $data['time_o'] = now();
		            $data['commission'] = $ref_comm;
		            $data['valid'] = 1;
		            
		            $where = array('user_id' => $rid);
		            $this->model->updater('referral', $data, $where,true);
		        }
		    }
            
            return redirect()->to('investments');
        }
        return redirect()->to('investments');
    }
    
    ///=================================================================================================================

	public function Pages(){
		if ($this->request->getPost()){
		    
		    if($this->request->getVar("section") == "contact"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','contact_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/contact_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/contact_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "privacy"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','privacy_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/privacy_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/privacy_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "privacy"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['privacy_title'] = $this->request->getVar("privacy_title");
		        $data['privacy_heading'] = $this->request->getVar("privacy_heading");
		        $data['privacy_desc'] = $this->request->getVar("privacy_desc");
		        $data['privacy_sub_heading'] = $this->request->getVar("privacy_sub_heading");
		        
		        $where = 'privacy_key';
		        $column = 'privacy_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "terms"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','terms_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/terms_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/terms_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("bannerImg2");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg2', 'Banner Image', 'uploaded[bannerImg2]|max_size[bannerImg2,5024]|is_image[bannerImg2]|mime_in[bannerImg2,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg2','legal_banner',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg2");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/legal_banner.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/News/legal_banner.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1170,384)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "terms"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['terms_title'] = $this->request->getVar("terms_title");
		        $data['terms_heading'] = $this->request->getVar("terms_heading");
		        $data['terms_desc'] = $this->request->getVar("terms_desc");
		        $data['terms_sub_heading'] = $this->request->getVar("terms_sub_heading");
		        
		        $where = 'terms_key';
		        $column = 'terms_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "covid"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','covid_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/covid_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/covid_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("bannerImg2");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg2', 'Banner Image', 'uploaded[bannerImg2]|max_size[bannerImg2,5024]|is_image[bannerImg2]|mime_in[bannerImg2,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg2','covid_banner',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg2");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/covid_banner.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/News/covid_banner.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1170,384)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "covid"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['covid_title'] = $this->request->getVar("covid_title");
		        $data['covid_heading'] = $this->request->getVar("covid_heading");
		        $data['covid_desc'] = $this->request->getVar("covid_desc");
		        $data['covid_sub_heading'] = $this->request->getVar("covid_sub_heading");
		        
		        $where = 'covid_key';
		        $column = 'covid_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "affiliate"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','affiliate_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/affiliate_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/affiliate_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "affiliate"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['aff_title'] = $this->request->getVar("aff_title");
		        $data['aff_heading'] = $this->request->getVar("aff_heading");
		        $data['aff_desc'] = $this->request->getVar("aff_desc");
		        $data['aff_sub_heading'] = $this->request->getVar("aff_sub_heading");
		        
		        $where = 'aff_key';
		        $column = 'aff_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "faq"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','faq_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/faq_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/faq_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "faq"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['faq_heading'] = $this->request->getVar("faq_heading");
		        $data['faq_sub_heading'] = $this->request->getVar("faq_sub_heading");
		        
		        $where = 'faq_key';
		        $column = 'faq_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "faq-edit"){

                $id = $this->request->getVar("id");
                $question = $this->request->getVar("question");
                $answer = $this->request->getVar("answer");
    
                    $data = array('question' => $question, 'answer' => $answer);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('faq', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "faq-create"){

                $question = $this->request->getVar("question");
                $answer = $this->request->getVar("answer");
    
                    $data = array('question' => $question, 'answer' => $answer);
                    
                    if($this->model->inserter('faq', $data, true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "testimonial"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','testimonial_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/testimonial_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/testimonial_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "testimonial"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['review_heading'] = $this->request->getVar("review_heading");
		        $data['review_sub_heading'] = $this->request->getVar("review_sub_heading");
		        
		        $where = 'review_key';
		        $column = 'review_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "review-edit"){

                $id = $this->request->getVar("id");
                $name = $this->request->getVar("name");
                $review = $this->request->getVar("review");
                $image = $this->request->getVar("img");
    
                    $data = array('name' => $name, 'review' => $review, 'image' => $image);
                    $where = array('id' => $id);
                    
                    if($this->model->updater('testimonials', $data, $where,true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "review-create"){

                $name = $this->request->getVar("name");
                $review = $this->request->getVar("review");
                $image = $this->request->getVar("img");
    
                    $data = array('name' => $name, 'review' => $review, 'image' => $image);
                    
                    if($this->model->inserter('testimonials', $data, true)) session()->setFlashdata("toast", true);
                    else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "media"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','media_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/media_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/media_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "media"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['media_heading'] = $this->request->getVar("media_heading");
		        $data['media_sub_heading'] = $this->request->getVar("media_sub_heading");
		        
		        $where = 'media_key';
		        $column = 'media_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "media-edit"){
		        
		        $data = array();
		        $data['name'] = $this->request->getVar("name");
		         
		        $file = $this->request->getFile("image");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('image', 'image', 'uploaded[image]|max_size[image,5024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
                        $Img = $this->request->getFile("image");
                        $imgName = $this->request->getVar("id");
                        $ext = $Img->getClientExtension();
		                $data['img'] = $imgName.'.'.$ext;
                        $to = ROOTPATH.'public/common/assets/images/gallery/';
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change = $this->imageUpload('image',$imgName,$to,false);
                        
            			if ($change) session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                        else session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			
        			}else session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    		
		        }
		        
                $where = array('id' => $this->request->getVar("id"));
                
		        if($this->model->updater('gallery', $data, $where,true)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "media-create"){
		        $data = array();
		        $data['name'] = $this->request->getVar("name");
		        
		        $id = (int)$this->model->inserter('gallery', $data, true);
		        if($id) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		         
		        $file = $this->request->getFile("image");
		        if($file != null && $file->isValid()){
		            $this->validation->setRule('image', 'image', 'uploaded[image]|max_size[image,5024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
                        $Img = $this->request->getFile("image");
                        $imgName = $id;
                        $to = ROOTPATH.'public/common/assets/images/gallery/';
                        $ext = $Img->getClientExtension();
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change = $this->imageUpload('image',$imgName,$to,false);
                        
            			if ($change) session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                        else session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
		        
            
                        $where = array('id' => $id);
                        
        		        if($this->model->updater('gallery', array('img' => $imgName.'.'.$ext), $where,true)) session()->setFlashdata("toast", true);
                        else session()->setFlashdata("toast", false);
            			
        			}else session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    		
		            
		        }
		    }
		    
		    if($this->request->getVar("section") == "services"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Services Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','investment_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/investment_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/investment_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "services"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['investment_heading'] = $this->request->getVar("investment_heading");
		        $data['investment_sub-heading'] = $this->request->getVar("investment_sub-heading");
		        
		        $items = $this->request->getVar("packages");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["packagesA"], "b" => $items[$i]["packagesB"], "c" => $items[$i]["packagesC"]);
                }
		        $data['packages'] = json_encode($itemz);
		        
		        $where = 'inv_key';
		        $column = 'inv_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "history"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'History Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','privacy_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/privacy_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/history_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		    }
		    
		    if($this->request->getVar("section") == "history"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['history_heading'] = $this->request->getVar("history_heading");
		        $data['history_sub-heading'] = $this->request->getVar("history_sub-heading");
		        
		        $items = $this->request->getVar("history");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["historyA"], "b" => $items[$i]["historyB"], "c" => $items[$i]["historyC"]);
                }
		        $data['history'] = json_encode($itemz);
		        
		        $where = 'history_key';
		        $column = 'history_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "about"){
		         
		        $file = $this->request->getFile("bannerImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('bannerImg', 'Banner Image', 'uploaded[bannerImg]|max_size[bannerImg,5024]|is_image[bannerImg]|mime_in[bannerImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('bannerImg','about_slider',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    $profileImg = $this->request->getFile("bannerImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/about_slider.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/about_slider.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("descriptionImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('descriptionImg', 'Description Image', 'uploaded[descriptionImg]|max_size[descriptionImg,5024]|is_image[descriptionImg]|mime_in[descriptionImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('descriptionImg','about_description',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    $profileImg = $this->request->getFile("descriptionImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/about_description.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Content/about_description.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,470,680)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("whyImg");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('whyImg', 'About Why Image', 'uploaded[whyImg]|max_size[whyImg,5024]|is_image[whyImg]|mime_in[whyImg,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('whyImg','about_why',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    $profileImg = $this->request->getFile("whyImg");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/about_why.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/about_why.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1350,304)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
    		    
    		    
		    }
		    
		    if($this->request->getVar("section") == "about"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['about_heading'] = $this->request->getVar("about_heading");
		        $data['about_sub-heading'] = $this->request->getVar("about_sub-heading");
		        $data['topica'] = $this->request->getVar("topica");
		        $data['topicb'] = $this->request->getVar("topicb");
		        $data['topicc'] = $this->request->getVar("topicc");
		        $data['topicd'] = $this->request->getVar("topicd");
		        $data['body'] = $this->request->getVar("body");
		        $data['sub_topica'] = $this->request->getVar("sub_topica");
		        $data['sub_topica_body'] = $this->request->getVar("sub_topica_body");
		        $data['sub_topicb'] = $this->request->getVar("sub_topicb");
		        $data['sub_topicb_body'] = $this->request->getVar("sub_topicb_body");
		        $data['sub_topicc'] = $this->request->getVar("sub_topicc");
		        $data['sub_topicc_body'] = $this->request->getVar("sub_topicc_body");
		        
		        $items = $this->request->getVar("stats");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["statsA"], "b" => $items[$i]["statsB"], "c" => $items[$i]["statsC"]);
                }
		        $data['stats'] = json_encode($itemz);
		        
		        $data['pointa'] = $this->request->getVar("pointa");
		        $data['pointb'] = $this->request->getVar("pointb");
		        $data['pointc'] = $this->request->getVar("pointc");
		        $data['why_topic'] = $this->request->getVar("why_topic");
		        $data['why_sub_topic'] = $this->request->getVar("why_sub_topic");
		        
		        $items = $this->request->getVar("why");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["whyA"], "b" => $items[$i]["whyB"], "c" => $items[$i]["whyC"]);
                }
		        $data['why'] = json_encode($itemz);
		        
		        $where = 'about_key';
		        $column = 'about_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
		    
		    if($this->request->getVar("section") == "home"){
		         
		        $file = $this->request->getFile("slider1");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('slider1', 'Slider 1 Image', 'uploaded[slider1]|max_size[slider1,5024]|is_image[slider1]|mime_in[slider1,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('slider1','slider1',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("slider1");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/slider1.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/1.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("people1");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('people1', 'People 1 Image', 'uploaded[people1]|max_size[people1,5024]|is_image[people1]|mime_in[people1,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('people1','people1',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("people1");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/people1.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/people1.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("slider2");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('slider2', 'Slider 2 Image', 'uploaded[slider2]|max_size[slider2,5024]|is_image[slider2]|mime_in[slider2,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('slider2','slider2',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("slider2");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/slider2.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/2.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("people2");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('people2', 'People 2 Image', 'uploaded[people2]|max_size[people2,5024]|is_image[people2]|mime_in[people2,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('people2','people2',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("people2");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/people2.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/people2.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("slider3");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('slider3', 'Slider 3 Image', 'uploaded[slider3]|max_size[slider3,5024]|is_image[slider3]|mime_in[slider3,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('slider3','slider3',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("slider3");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/slider3.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/3.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("people3");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('people3', 'People 3 Image', 'uploaded[people3]|max_size[people3,5024]|is_image[people3]|mime_in[people3,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('people3','people3',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("people3");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/people3.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Slider/home3/people3.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,1920,745)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("home_about");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('home_about', 'Home About Image', 'uploaded[home_about]|max_size[home_about,5024]|is_image[home_about]|mime_in[home_about,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('home_about','home_about',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("home_about");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/home_about.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/Content/home-about.png';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_PNG,571,680)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("about_description1");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('about_description1', 'About Description Image 1', 'uploaded[about_description1]|max_size[about_description1,5024]|is_image[about_description1]|mime_in[about_description1,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('about_description1','about_description1',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("about_description1");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/about_description1.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/home_about_description1.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,973,397)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
		         
		        $file = $this->request->getFile("about_description2");
		        if($file != null && $file->isValid()){
		            
		            $this->validation->setRule('about_description2', 'About Description Image 2', 'uploaded[about_description2]|max_size[about_description2,5024]|is_image[about_description2]|mime_in[about_description2,image/jpg,image/jpeg,image/gif,image/png]');
			
        			if ($this->validation->withRequest($this->request)->run()){
        			    
            			$change = $this->imageUpload('about_description2','about_description2',ROOTPATH.'public/temp',false);
            
            			if ($change){
            				//if the picture was successfully uploaded
                                    //edit the image
                                    $profileImg = $this->request->getFile("about_description2");
                                    $ext = $profileImg->getClientExtension();
                                    $from = ROOTPATH.'public/temp/about_description2.'.$ext;
                                    $to = ROOTPATH.'public/common/assets/images/bg-content/home_about_description2.jpg';
        			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                                    if($this->imageEdit($from,$to,IMAGETYPE_JPEG,956,638)){
                                        unlink($from);
                    		            session()->setFlashdata("error", view('messages/single',['message' => "Image Uploaded Successfully"]) );
                                    }else{
                        				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Image Conversion Failed"]]) );
                        			}
                                    
            			}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => ["Image Upload Failed"]]) );
            			}
            			
        			}else{
            				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
            		}
    		    }
    		    
		    }
		    
		    if($this->request->getVar("section") == "home"){
		        $data = array();
		        $data['page_title'] = $this->request->getVar("page_title");
		        $data['topic1'] = $this->request->getVar("topic1");
		        $data['topic1a'] = $this->request->getVar("topic1a");
		        $data['topic1b'] = $this->request->getVar("topic1b");
		        $data['topic1c'] = $this->request->getVar("topic1c");
		        $data['topic2'] = $this->request->getVar("topic2");
		        $data['topic2a'] = $this->request->getVar("topic2a");
		        $data['topic2b'] = $this->request->getVar("topic2b");
		        $data['topic2c'] = $this->request->getVar("topic2c");
		        $data['topic3'] = $this->request->getVar("topic3");
		        $data['topic3a'] = $this->request->getVar("topic3a");
		        $data['topic3b'] = $this->request->getVar("topic3b");
		        $data['topic3c'] = $this->request->getVar("topic3c");
		        
		        $items = $this->request->getVar("section2a");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section2aA"], "b" => $items[$i]["section2aB"], "c" => $items[$i]["section2aC"]);
                }
		        $data['section2a'] = json_encode($itemz);
		        
		        $items = $this->request->getVar("section2b");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section2bA"], "b" => $items[$i]["section2bB"], "c" => $items[$i]["section2bC"]);
                }
		        $data['section2b'] = json_encode($itemz);
		        
		        $items = $this->request->getVar("section2c");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section2cA"], "b" => $items[$i]["section2cB"], "c" => $items[$i]["section2cC"]);
                }
		        $data['section2c'] = json_encode($itemz);
                
		        $data['section3_topic'] = $this->request->getVar("section3_topic");
		        $data['section3_sub_topic'] = $this->request->getVar("section3_sub_topic");
		        $data['section3_body'] = $this->request->getVar("section3_body");
		        $data['section3_point1_topic'] = $this->request->getVar("section3_point1_topic");
		        $data['section3_point1_body'] = $this->request->getVar("section3_point1_body");
		        $data['section3_point2_topic'] = $this->request->getVar("section3_point2_topic");
		        $data['section3_point2_body'] = $this->request->getVar("section3_point2_body");
		        $data['section3_point3_topic'] = $this->request->getVar("section3_point3_topic");
		        $data['section3_point3_body'] = $this->request->getVar("section3_point3_body");
		        $data['about_video_title'] = $this->request->getVar("about_video_title");
		        $data['about_video_link'] = $this->request->getVar("about_video_link");
		        
		        $items = $this->request->getVar("about_points");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["about_pointsA"], "b" => $items[$i]["about_pointsB"], "c" => $items[$i]["about_pointsC"]);
                }
		        $data['about_points'] = json_encode($itemz);
		        
		        $data['section4_topic'] = $this->request->getVar("section4_topic");
		        $data['section4_sub_topic'] = $this->request->getVar("section4_sub_topic");
		        
		        $items = $this->request->getVar("section4a");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section4aA"], "b" => $items[$i]["section4aB"], "c" => $items[$i]["section4aC"]);
                }
		        $data['section4a'] = json_encode($itemz);
		        
		        $items = $this->request->getVar("section4b");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section4bA"], "b" => $items[$i]["section4bB"], "c" => $items[$i]["section4bC"]);
                }
		        $data['section4b'] = json_encode($itemz);
		        
		        $items = $this->request->getVar("section4c");
                $itemz = array();
                for ($i = 0; $i < count($items); $i++){
                    $itemz[] = array("a" => $items[$i]["section4cA"], "b" => $items[$i]["section4cB"], "c" => $items[$i]["section4cC"]);
                }
		        $data['section4c'] = json_encode($itemz);
		        
		        $data['section5_topic'] = $this->request->getVar("section5_topic");
		        $data['section5_sub_topic'] = $this->request->getVar("section5_sub_topic");
		        $data['section6a'] = $this->request->getVar("section6a");
		        $data['section6b'] = $this->request->getVar("section6b");
		        $data['section6_btn'] = $this->request->getVar("section6_btn");
		        
		        $where = 'home_key';
		        $column = 'home_value';
		        
		        if($this->model->replacer('pages', $data, $where,$column)) session()->setFlashdata("toast", true);
                else session()->setFlashdata("toast", false);
		    }
        }
        return redirect()->to('pages');
    }
    
    ///=================================================================================================================
}