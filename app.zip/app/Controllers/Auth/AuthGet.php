<?php
namespace App\Controllers\Auth;

use App\Controllers\BaseController;

class AuthGet extends BaseController{
    
    protected $ionAuth;

	public function __construct() {
	}

	public function index(){
		return view(APPPATH.'/Views/Common/404');
    }

	protected function notFound($page){
        if(!is_file(APPPATH.'/Views/Auth/'.$page.'.php')){
            //Whoops, we don't have a page for that!
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }else return true;
	}

    public function Login(){
		if($this->notFound('login')){
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
    
            $data['page'] = 'login';
            
            $data['page_title'] = 'Login to your Account';

			$data['info'] = session()->getFlashdata("error");
			
			return $this->view('login',$data);
        }

    }

    public function Register(){
		if($this->notFound('register')){
		    
		    helper('cookie');
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
    
            $data['page'] = 'register';
    
            $data['cookie'] = get_cookie($this->site['site_name'].'-referral',true);
            
            $data['page_title'] = 'Register With Us';

			$data['info'] = session()->getFlashdata("error");
			
			return $this->view('register',$data);
        }

    }

    public function Forgot(){
		if($this->notFound('forgot')){
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
    
            $data['page'] = 'forgot';
            
            $data['page_title'] = 'Reset your Password';

			$data['info'] = session()->getFlashdata("error");
			
			return $this->view('forgot',$data);
        }

    }

    public function Reset($code){
		if($this->notFound('reset')){
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
			$data['code'] = $code;
    
            $data['page'] = 'forgot';
            
            $data['page_title'] = 'Reset your Password';

			$data['info'] = session()->getFlashdata("error");
			
			return $this->view('reset',$data);
        }

    }

    public function Activate($id,$code){
		if($this->notFound('activate')){
            
			$data['csrf_token'] = csrf_token();
			$data['csrf_hash'] = csrf_hash();
			$data['code'] = $code;
			$data['id'] = $id;
    
            $data['page'] = 'activate';
            
            $data['page_title'] = 'Activate your Account';

			$data['info'] = session()->getFlashdata("error");
			
			return $this->view('activate',$data);
        }

    }
    
    protected function view($page,$data){

        $data = array_merge($data,$this->contact);
		$data = array_merge($data,$this->site);
        $data['datez'] = now();
        $data['base_url'] = base_url();
        
		//exit('<pre>'.print_r($data,true).'</pre>');

		echo $this->parser->setData($data)->render('/Auth/templates/header');
		echo $this->parser->setData($data)->render('/Auth/templates/loader');
		echo $this->parser->setData($data)->render('/Auth/'.$page);
		echo $this->parser->setData($data)->render('/Auth/templates/footer');

    }
}