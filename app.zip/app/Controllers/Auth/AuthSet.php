<?php

namespace App\Controllers\Auth;
use App\Controllers\BaseController;

class AuthSet extends BaseController{

	public $data = [];

	protected $configIonAuth;

	protected $ionAuth;
	
	protected $validationListTemplate = 'c_list';
	
	protected $errorListTemplate = 'list';
	
	protected $messageListTemplate = 'list';

	protected $viewsFolder = 'Auth';
	
    protected $validation;
    

	public function __construct(){

		$this->ionAuth    = new \App\Libraries\IonAuth();
		
		//validation
        $this->validation = \Config\Services::validation();
        

		helper(['form', 'url']);

		$this->configIonAuth = config('IonAuth');
		

		if (! empty($this->configIonAuth->templates['errors']['list'])){
			$this->errorListTemplate = $this->configIonAuth->templates['errors']['list'];
		}

		if (! empty($this->configIonAuth->templates['messages']['list'])){
			$this->messageListTemplate = $this->configIonAuth->templates['messages']['list'];
		}
		
		$this->validation->reset();
	}
	
	public function index(){
		if (! $this->ionAuth->loggedIn()){
			return redirect()->to('login');
		}else if (! $this->ionAuth->isAdmin()){ 
			throw new \Exception('You must be an administrator to view this page.');
		}else redirect()->to('user/dashboard');
	}

	public function Login(){
	    if(!$this->site['allow_login']) return redirect()->to(base_url);
	    //captcha
	    if(!$this->reCaptcha($this->request->getVar('g-recaptcha-response'))){
			session()->setFlashdata("error", view('errors/form/single', ['error' => 'Captcha Authentication Failed']) );
			return redirect()->back();
	    }

		// validate form input
		$this->validation->setRule('email', str_replace(':', '', lang('Auth.login_identity_label')), 'required');
		$this->validation->setRule('password', str_replace(':', '', lang('Auth.login_password_label')), 'required');

		if ($this->request->getPost()){
		    
		    if($this->validation->withRequest($this->request)->run()){
		        
    			// check to see if the user is logging in
    			// check for "remember me"
    			$remember = (bool)$this->request->getVar('remember');
    
    			if ($this->ionAuth->login($this->request->getVar('email'), $this->request->getVar('password'), $remember)){
    			    $this->ionAuth->informLogin($this->ionAuth->user()->row()->email);
    				//$this->session->setFlashdata('message', $this->ionAuth->messages());
    				return redirect()->to('user/dashboard');//->withCookies();
    			}else{
    				session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
    				// use redirects back
    				return redirect()->back();
    			}
    			
		    }else{
    				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}

	public function Logout(){
		$this->ionAuth->logout();
		return redirect()->to('/');
	}

	public function Cpassword(){
	    
		if (! $this->ionAuth->loggedIn()) return redirect()->to(base_url('login'));
		
		$this->validation->setRule('old', lang('Auth.change_password_validation_old_password_label'), 'required');
		$this->validation->setRule('password', lang('Auth.change_password_validation_new_password_label'), 'required|min_length[' . $this->configIonAuth->minPasswordLength . ']|matches[cpassword]');
		$this->validation->setRule('cpassword', lang('Auth.change_password_validation_new_password_confirm_label'), 'required');

		$user = $this->ionAuth->user()->row();

		if ($this->request->getPost()){
			
			if ($this->validation->withRequest($this->request)->run()){
			    
    			$identity = $this->session->get('identity');
    
    			$change = $this->ionAuth->changePassword($identity, $this->request->getVar('old'), $this->request->getVar('password'));
    
    			if ($change){
    				//if the password was successfully changed
            		session()->setFlashdata("error", $this->ionAuth->messages() );
    				return redirect()->to(base_url('user/profile'));
    			}else{
    				session()->setFlashdata("errorPass", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
    				return redirect()->back();
    			}
    			
			}else{
    				session()->setFlashdata("errorPass", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}

	public function Forgot(){
	    //captcha
	    if(!$this->reCaptcha($this->request->getVar('g-recaptcha-response'))){
			session()->setFlashdata("error", view('errors/form/single', ['error' => 'Captcha Authentication Failed']) );
			return redirect()->back();
	    }

		// setting validation rules by checking whether identity is username or email
		if ($this->configIonAuth->identity !== 'email'){
			$this->validation->setRule('identity', lang('Auth.forgot_password_identity_label'), 'required');
		}else{
			$this->validation->setRule('email', lang('Auth.forgot_password_validation_email_label'), 'required|valid_email');
		}
		
		if ($this->request->getPost()){
		    
		    if($this->validation->withRequest($this->request)->run()){
		        
    			$identityColumn = $this->configIonAuth->identity;
    			$identity = $this->ionAuth->where($identityColumn, $this->request->getVar('email'))->users()->row();
    			if (empty($identity)){
    				if ($this->configIonAuth->identity !== 'email'){
    					$this->ionAuth->setError('Auth.forgot_password_identity_not_found');
    				}else{
    					$this->ionAuth->setError('Auth.forgot_password_email_not_found');
    				}
    				
    				session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
    				return redirect()->back();
    			}
    
    			// run the forgotten password method to email an activation code to the user
    			$forgotten = $this->ionAuth->forgottenPassword($identity->{$this->configIonAuth->identity});
    
    			if ($forgotten){
    				// if there were no errors
    				session()->setFlashdata("error", $this->ionAuth->messages() );
    				return redirect()->to('login');
    			}else{
    				session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
    				return redirect()->back();
    			}
    			
			}else{
    				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}

	public function Reset(){
	    //captcha
	    if(!$this->reCaptcha($this->request->getVar('g-recaptcha-response'))){
			session()->setFlashdata("error", view('errors/form/single', ['error' => 'Captcha Authentication Failed']) );
			return redirect()->back();
	    }
	    
	    $code = $this->request->getVar('code');
		if (! $code){
			throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
		}

		$user = $this->ionAuth->forgottenPasswordCheck($code);

		if ($user){
			// if the code is valid then display the password reset form

			$this->validation->setRule('cpassword', lang('Auth.reset_password_validation_new_password_confirm_label'), 'required');
			$this->validation->setRule('password', lang('Auth.reset_password_validation_new_password_label'), 'required|min_length[' . $this->configIonAuth->minPasswordLength . ']|matches[cpassword]');

			if ($this->request->getPost()){
		    
    		    if($this->validation->withRequest($this->request)->run()){
    			    
    				$identity = $user->{$this->configIonAuth->identity};
    
    				// do we have a valid request?
    				if (1==2){//($user->id != $this->request->getVar('user_id')){
    					// something fishy might be up
    					$this->ionAuth->clearForgottenPasswordCode($identity);
    
    					throw new \Exception(lang('Auth.error_security'));
    					
    				}else{
    				    
    					// finally change the password
    					$change = $this->ionAuth->resetPassword($identity, $this->request->getPost('password'));
    
    					if ($change){
    						// if the password was successfully changed
            				session()->setFlashdata("error", $this->ionAuth->messages() );
            				return redirect()->to('login');
    					}else{
            				session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
            				return redirect()->to('reset/'.$code);
    					}
    				}
    				
    			}else{
    				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		    }
    		    
			}else redirect()->back();
			
		}else{
			// if the code is invalid then send them back to the forgot password page
    		session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
			return redirect()->to('forgot');
		}
	}

	public function Activate(){
		$activation = false;
	    $code = $this->request->getVar('code');
	    $id = $this->request->getVar('id');

		if ($code){
			$activation = $this->ionAuth->activate($id, $code);
		}else if ($this->ionAuth->isAdmin()){
			$activation = $this->ionAuth->activate($id);
		}else return redirect()->to(base_url('forgot'));

		if ($activation){
			// redirect them to the auth page
			session()->setFlashdata("error", $this->ionAuth->messages() );
			return redirect()->to(base_url('login'));
		}else{
			// redirect them to the forgot password page
    		session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
			return redirect()->to(base_url('forgot'));
		}
	}

	public function Deactivate(int $id = 0){
		if (! $this->ionAuth->loggedIn() || ! $this->ionAuth->isAdmin()){
			// redirect them to the home page because they must be an administrator to view this
			throw new \Exception('You must be an administrator to view this page.');
			// TODO : I think it could be nice to have a dedicated exception like '\IonAuth\Exception\NotAllowed
		}

		$this->validation->setRule('confirm', lang('Auth.deactivate_validation_confirm_label'), 'required');
		$this->validation->setRule('id', lang('Auth.deactivate_validation_user_id_label'), 'required|integer');

		if (! $this->validation->withRequest($this->request)->run()){
			session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
			return redirect()->back();
		}else{
			// do we really want to deactivate?
			if ($this->request->getVar('confirm') === 'yes'){
				// do we have a valid request?
				if ($id !== $this->request->getPost('id', FILTER_VALIDATE_INT)){
					throw new \Exception(lang('Auth.error_security'));
				}

				// do we have the right userlevel?
				if ($this->ionAuth->loggedIn() && $this->ionAuth->isAdmin()){
            		if($this->ionAuth->deactivate($id))session()->setFlashdata("error", view('messages/list',['message' => $this->ionAuth->messages()]) );
            		redirect()->back();
				}
			}

			// redirect them back to the auth page
			return redirect()->back();
		}
	}

	public function Register(){
	    if(!$this->site['allow_signup']) return redirect()->to(base_url);
	    //captcha
	    if(!$this->reCaptcha($this->request->getVar('g-recaptcha-response'))){
			session()->setFlashdata("error", view('errors/form/single', ['error' => 'Captcha Authentication Failed']) );
			return redirect()->back();
	    }

		$tables                        = $this->configIonAuth->tables;
		$identityColumn                = $this->configIonAuth->identity;
		$this->data['identity_column'] = $identityColumn;

		// validate form input
		$this->validation->setRule('username', lang('Auth.create_user_validation_fname_label'), 'trim|required');
		$this->validation->setRule('fname', lang('Auth.create_user_validation_fname_label'), 'trim|required');
		$this->validation->setRule('lname', lang('Auth.create_user_validation_lname_label'), 'trim|required');
		if ($identityColumn !== 'email'){
			$this->validation->setRule('identity', lang('Auth.create_user_validation_identity_label'), 'trim|required|is_unique[' . $tables['users'] . '.' . $identityColumn . ']');
			$this->validation->setRule('email', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email');
		}else{
			$this->validation->setRule('email', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email|is_unique[' . $tables['users'] . '.email]');
		}
		$this->validation->setRule('phone', lang('Auth.create_user_validation_phone_label'), 'trim|required');
		//$this->validation->setRule('company', lang('Auth.create_user_validation_company_label'), 'trim');
		$this->validation->setRule('cpassword', lang('Auth.create_user_validation_password_confirm_label'), 'required');
		$this->validation->setRule('password', lang('Auth.create_user_validation_password_label'), 'required|min_length[' . $this->configIonAuth->minPasswordLength . ']|matches[cpassword]');

		if ($this->request->getPost()){
		    
    	    if($this->validation->withRequest($this->request)->run()){
		    
    			$email    = strtolower($this->request->getPost('email'));
    			$identity = ($identityColumn === 'email') ? $email : $this->request->getPost('identity');
    			$password = $this->request->getVar('password');
    
    			$additionalData = [
    			    'username' => $this->request->getVar('username'),
    				'first_name' => $this->request->getVar('fname'),
    				'last_name'  => $this->request->getVar('lname'),
    				//'company'    => $this->request->getPost('company'),
    				'phone'      => $this->request->getVar('phone'),
    				'referred_by'      => $this->request->getVar('refcode'),
    				'address'      => "",
    				'bio'      => "",
    				'dob'      => "",
    				'kyc_doc'      => "",
    				'kyc_status'      => "0",
    				'wallet'      => "",
    			];
    			
    		}else{
    				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    	   }
			
		}else redirect()->back();
		
		$regId = $this->ionAuth->register($identity, $password, $email, $additionalData);
		
		if($regId){
		    
            //set default profile image
            $ext = 'jpg';
            $from = ROOTPATH.'public/profile-pics/default.jpg';
            $to = ROOTPATH.'public/profile-pics/'.strtolower($this->request->getVar('username')).'.'.$ext;
            $this->imageEdit($from,$to,IMAGETYPE_JPEG,90,90); 
            
            //set referral
					  if(!empty($this->request->getVar('refcode')) && $this->request->getVar('refcode') != null){
						  $data = array(
						  	'user_id' => $regId,
						  	'referer' => $this->request->getVar('refcode'),
						  	'time_i' => now(),
						  	'time_o' => "",
						  	'valid' => 0,
						  	'status' => 0,
						  	'commission' => 0,
						  );
						  $this->ionAuth->recordReferral($data);
					  }
            
			session()->setFlashdata("error", $this->ionAuth->messages() );
			return redirect()->to('login');
		}else{
		    session()->setFlashdata("error", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
			return redirect()->to('register');
		}
	}

	public function Settings(){

		if (!$this->ionAuth->loggedIn()){
			return redirect()->to('login');

		};

		$user = $this->ionAuth->user()->row();
		$id = $user->id;
		$email = $user->email;
		$groups        = $this->ionAuth->groups()->resultArray();
		$currentGroups = $this->ionAuth->getUsersGroups($id)->getResult();
		$tables       = $this->configIonAuth->tables;
		if (!empty($_POST)){
			// validate form input
			$this->validation->setRule('fname', lang('Auth.edit_user_validation_fname_label'), 'trim|required');
			$this->validation->setRule('lname', lang('Auth.edit_user_validation_lname_label'), 'trim|required');
			$this->validation->setRule('phone', lang('Auth.edit_user_validation_phone_label'), 'trim|required');
			$this->validation->setRule('address', 'Your Address', 'trim|required');
			$this->validation->setRule('bio', 'Your bio', 'trim|required');
			$this->validation->setRule('dobY', 'Your Birth Year', 'trim|integer|required');
			$this->validation->setRule('dobM', 'Your Birth Month', 'trim|integer|required');
			$this->validation->setRule('dobD', 'Your Birth Day', 'trim|integer|required');
			$this->validation->setRule('email', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email|is_unique[' . $tables['users'] . '.email,'.$tables['users'] . '.email,'.$email.']');
			//$this->validation->setRule('company', lang('Auth.edit_user_validation_company_label'), 'trim|required');

			if ($this->request->getPost()){
		    
    		    if($this->validation->withRequest($this->request)->run()){
    		        
                        $dob = strtotime($this->request->getVar('dobY')."-".$this->request->getVar('dobM')."-".$this->request->getVar('dobD'));
        				$data = [
        					'first_name' => $this->request->getVar('fname'),
        					'last_name'  => $this->request->getVar('lname'),
        					//'company'    => $this->request->getPost('company'),
        					'phone'      => $this->request->getVar('phone'),
        					'bio'      => $this->request->getVar('bio'),
        					'email'      => $this->request->getVar('email'),
        					'address'      => $this->request->getVar('address'),
        					'dob' => $dob
        				];
        
        				// check to see if we are updating the user
        				if ($this->ionAuth->update($user->id, $data)){
        					session()->setFlashdata("error", $this->ionAuth->messages() );
            				return redirect()->to(base_url('user/profile'));
        				}else{
        					session()->setFlashdata("errorSettings", view('errors/form/list',['errors' => $this->ionAuth->errorsArray()]) );
                			return redirect()->back();
        				}
        				// redirect them back to the admin page if admin, or to the base url if non admin
        				return redirect()->to(base_url(user/profile));
        				
        		}else{
    				session()->setFlashdata("errorSettings", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    		    }
			} redirect()->back();
			
		} redirect()->back();
	}
	
	public function Picture(){
	    
		if (! $this->ionAuth->loggedIn()) return redirect()->to('login');
		
		$this->validation->setRule('profile_image', 'Profile Image', 'uploaded[profile_image]|max_size[profile_image,5024]|is_image[profile_image]|mime_in[profile_image,image/jpg,image/jpeg,image/gif,image/png]');

		$user = $this->ionAuth->user()->row();

		if ($this->request->getPost()){
			
			if ($this->validation->withRequest($this->request)->run()){
			    
    			$identity = $this->session->get('identity');
    
    			$change = $this->imageUpload('profile_image',strtolower($user->username),ROOTPATH.'public/temp',false);
    
    			if ($change){
    				//if the picture was successfully uploaded
                            //edit the image
                            $profileImg = $this->request->getFile("profile_image");
                            $ext = $profileImg->getClientExtension();
                            $from = ROOTPATH.'public/temp/'.strtolower($user->username).'.'.$ext;
                            $to = ROOTPATH.'public/profile-pics/'.strtolower($user->username).'.jpg';
			                //IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
                            if($this->imageEdit($from,$to,IMAGETYPE_JPEG,90,90)){
                                unlink($from);
            		            session()->setFlashdata("error", view('messages/single',['message' => "Profile Image Uploaded Successfully"]) );
				                return redirect()->to(base_url('user/profile'));
                            }else{
                				session()->setFlashdata("errorUpload", view('errors/form/list',['errors' => ["Profile Image Conversion Failed"]]) );
                				return redirect()->back();
                			}
                            
    			}else{
    				session()->setFlashdata("errorUpload", view('errors/form/list',['errors' => ["Profile Image Upload Failed"]]) );
    				return redirect()->back();
    			}
    			
			}else{
    				session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => [$this->validation->getErrors()]]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}
	
	public function KYC(){
	    
		if (! $this->ionAuth->loggedIn()) return redirect()->to('login');
		
		$this->validation->setRule('kyc_front', 'Front Image', 'uploaded[kyc_front]|max_size[kyc_front,5024]|is_image[kyc_front]|mime_in[kyc_front,image/jpg,image/jpeg,image/gif,image/png]');
		
		$this->validation->setRule('kyc_back', 'Front Image', 'uploaded[kyc_back]|max_size[kyc_back,5024]|is_image[kyc_back]|mime_in[kyc_back,image/jpg,image/jpeg,image/gif,image/png]');
		
		$this->validation->setRule('kyc_selfie', 'Front Image', 'uploaded[kyc_selfie]|max_size[kyc_selfie,5024]|is_image[kyc_selfie]|mime_in[kyc_selfie,image/jpg,image/jpeg,image/gif,image/png]');
		
		$this->validation->setRule('kyc_doc', 'Kyc Document Type','required');

		$user = $this->ionAuth->user()->row();

		if ($this->request->getPost()){
			
			if ($this->validation->withRequest($this->request)->run()){
			    
    			$identity = $this->session->get('identity');
    			
                $file1 = $this->request->getFile("kyc_front");
                $file2 = $this->request->getFile("kyc_back");
                $file3 = $this->request->getFile("kyc_selfie");
                
                $errorData = array();
                $successData = array();
                
                if($file1->isValid()){
        			    
                        $Img = $this->request->getFile("kyc_front");
                        $imgName = $this->request->getVar(id);
                        $to = ROOTPATH.'public/kyc/front/';
                        $ext = $Img->getClientExtension();
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change1 = $this->imageUpload('kyc_front',$imgName,$to,false);
                        
            			if ($change1) array_push($successData,"Front Image Uploaded Successfully");
            			else  array_push($errorData,"Front Image Upload Failed");
                    
                }
                
                if($file2->isValid()){
        			    
                        $Img = $this->request->getFile("kyc_back");
                        $imgName = $this->request->getVar(id);
                        $to = ROOTPATH.'public/kyc/back/';
                        $ext = $Img->getClientExtension();
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change2 = $this->imageUpload('kyc_back',$imgName,$to,false);
                        
            			if ($change2) array_push($successData,"Back Image Uploaded Successfully");
            			else  array_push($errorData,"Back Image Upload Failed");
                    
                }
                
                if($file3->isValid()){
        			    
                        $Img = $this->request->getFile("kyc_selfie");
                        $imgName = $this->request->getVar(id);
                        $to = ROOTPATH.'public/kyc/selfie/';
                        $ext = $Img->getClientExtension();
                        if(file_exists($to.$imgName.'.'.$ext)) unlink($to.$imgName.'.'.$ext);
                        $change3 = $this->imageUpload('kyc_selfie',$imgName,$to,false);
                        
            			if ($change3) array_push($successData,"Selfie Image Uploaded Successfully");
            			else  array_push($errorData,"Selfie Image Upload Failed");
                    
                }
                
                $finalmsg = view('messages/list',['messages' => $successData]).view('messages/list',['messages' => $successData]);
                
                if(!empty($successData)) session()->setFlashdata("error", $finalmsg );
                
                if(!empty($errorData)) session()->setFlashdata("errorKyc", $finalmsg );
                
                
	            $data = array('kyc_status'=>2, 'kyc_doc'=>$this->request->getVar('kyc_doc'));
	            
	            $this->ionAuth->update($user->id, $data);
	            
	            return redirect()->back();
    			
			}else{
    				session()->setFlashdata("errorUpload", view('errors/form/list', ['errors' => [$this->validation->getErrors()]]) );
    				return redirect()->back();
    		}
    		
		}else redirect()->back();
	}
}
