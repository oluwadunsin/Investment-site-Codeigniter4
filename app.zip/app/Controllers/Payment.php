<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\PaymentModel;

class Payment extends BaseController{

	public function __construct() {
		$this->model = new PaymentModel();
	}
	

	public function index(){
		return view(APPPATH.'/Views/User/404',$this->site);
    }
    
	public function Paystack($ref="", $id=""){ 
	    
	    if(empty($ref)){
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "The Paystack Token was not generated correctly"]) );
    		return redirect()->to(previous_url()."#payModal");
	    } if(empty($id)){
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "The User Id was not set correctly"]) );
    		return redirect()->to(previous_url()."#payModal");
	    }
	    
        $do_txn = false;
          
          $curl = curl_init();
          
          curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.paystack.co/transaction/verify/".rawurlencode($ref),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
              "Authorization: Bearer ".$this->site['paystack_secret'],
              "Cache-Control: no-cache",
            ),
          ));
          
          $response = curl_exec($curl);
          $err = curl_error($curl);
          curl_close($curl);
          
          if ($err) {
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "cURL Error #:" . $err]) );
    		return redirect()->to(previous_url()."#payModal");
          }

          $tranx = json_decode($response);

          if(!$tranx->status){
            // there was an error from the API
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => 'API returned error: ' . $tranx->message]) );
    		return redirect()->to(previous_url()."#payModal");
          }

          if('success' == $tranx->data->status){
                if('Successful' == $tranx->data->gateway_response){
                        $do_txn = true;
                }else{
        	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => $tranx->data->gateway_response]) );
            		return redirect()->to(previous_url()."#payModal");
                }
          }else{
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => $tranx->data->message]) );
    		return redirect()->to(previous_url()."#payModal");
          }
          
          
            if($do_txn){
                //check if its unique
                $unique =  $this->model->getCount($tranx->data->reference);
                if($unique < 1){
                    
                    $data = [
                        'user_id' => $tranx->data->metadata->custom_fields[0]->user_id,
                        'ref_id' => $tranx->data->reference,
                        'reference' => 'Paystack',
                        'amount' => $tranx->data->amount / 100,
                        'init_amount' => $tranx->data->metadata->custom_fields[0]->amount /100,
                        'time' => now(),
                        'status' => 1,
                        'currency' => $tranx->data->currency,
                        'description' => ''
                    ];
                    
                    if($this->model->inserter($data)){ 
                    
                        //update user balance
                        $User = $this->model->retrieve($tranx->data->metadata->custom_fields[0]->user_id); //new \App\Libraries\IonAuth();
                        //$User = $ionAuth->user()->row();
                        
                        $data = [
                            'wallet' => ($tranx->data->amount / 100) + $User->wallet,
                        ];
                        
                        if($this->model->updater($tranx->data->metadata->custom_fields[0]->user_id, $data)){
                            session()->setFlashdata("errorPayment", view('messages/single',['message' => "Funding was Successful"]) );
                    		return redirect()->to(previous_url()."#payModal");
                        }else{
                	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "There was an error while updating your wallet"]) );
                    		return redirect()->to(previous_url()."#payModal");
                        }
                        
                    }else{
            	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "There was an error while updating your deposit"]) );
                		return redirect()->to(previous_url()."#payModal");
                    }
                    
                }else{
        	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "Transaction is not unique"]) );
            		return redirect()->to(previous_url()."#payModal");
                }
                
            }
	}
    
    public function errorAndDie($error_msg) {
        
        $cp_debug_email = $this->contact['from_email'];
        $this->email = \Config\Services::email();
		$this->email->initialize($this->emailParameters);
		
        if (!empty($cp_debug_email)) {
            $report = 'Error: '.$error_msg."\n\n";
            $report .= "POST Data\n\n";
            foreach ($_POST as $k => $v) {
                $report .= "|$k| = |$v|\n";
            }
				$message = $report;
				$this->email->clear();
				$this->email->setFrom($cp_debug_email, "Coinpayments ERROR");
				$this->email->setTo($cp_debug_email);
				$this->email->setSubject('CoinPayments IPN Error');
				$this->email->setMessage($message);
				$this->email->send();
				//mail($cp_debug_email, 'CoinPayments IPN Error', $report);
        }
        $cError = 'IPN Error: '.$error_msg;
        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => $cError]) );
		return redirect()->to(previous_url()."#payModal");
    }
    
	public function Coinpayment($id=""){ 
	    
        //$this->errorAndDie('Called <pre>'.print_r($_SERVER, true).'</pre><br><pre>'.print_r($_POST, true).'</pre>');
	    if(empty($id)){
	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "The User Id was not set correctly"]) );
    		return redirect()->to(previous_url()."#payModal");
	    }
	    
        // Fill these in with the information from your CoinPayments.net account.
        $cp_merchant_id = $this->site['coinpayments_merchant'];
        $cp_ipn_secret = $this->site['coinpayments_ipn'];
        $do_txn = true;

        if (!isset($_POST['ipn_mode']) || $_POST['ipn_mode'] != 'hmac') {
            $do_txn = false;
            $this->errorAndDie('IPN Mode is not HMAC');
        }
        
        $hmac = $_SERVER['HTTP_HMAC'];
        if (!isset($hmac) || empty($hmac)) {
            $do_txn = false;
            $this->errorAndDie('No HMAC signature sent.');
        }

        $request = file_get_contents('php://input');
        if ($request === FALSE || empty($request)) {
            $do_txn = false;
            $this->errorAndDie('Error reading POST data');
        }
    
        if (!isset($_POST['merchant']) || $_POST['merchant'] != trim($cp_merchant_id)) {
            $do_txn = false;
            $this->errorAndDie('No or incorrect Merchant ID passed');
        }

        $hmac2 = hash_hmac("sha512", $request, trim($cp_ipn_secret));
        if (!hash_equals($hmac2, $hmac)) {
        //if ($hmac != $_SERVER['HTTP_HMAC']) { //<-- Use this if you are running a version of PHP below 5.6.0 without the hash_equals function
            $do_txn = false;
            $this->errorAndDie('HMAC signature does not match');
        }
    

        // HMAC Signature verified at this point, load some variables.
        $ipn_type = $_POST['ipn_type'];
        //$txn_id = $_POST['txn_id'];
        $item_name = $_POST['item_name']; //plan name
        $amount1 = floatval($_POST['amount1']); //amount in admin set currency
        $amount2 = floatval($_POST['amount2']); //amount in currency user chose
        $invoice = $_POST['invoice']; //reference id
        $user_id = $_POST['custom'];
        $currency1 = $_POST['currency1']; //usd
        $currency2 = $_POST['currency2']; //currency user chose
        $status = intval($_POST['status']);
        $status_text = $_POST['status_text'];
        
        if ($ipn_type != 'simple') { // Advanced Button payment
            $do_txn = false;
            errorAndDie("IPN OK: Not a button payment");
        }

        // Check the original currency to make sure the buyer didn't change it.
        if(($currency1 != strtoupper($this->site['site_currency']))){
                $do_txn = false;
                $this->errorAndDie('Original currency mismatch!');
        }
        
        if($do_txn){
                //check if its unique
                $unique =  $this->model->getCount($invoice);
                    
                  if($status >= 100 || $status == 2) $lstatus = 1;
    	          else if ($status < 0) $lstatus = 4;
    	          else if ($status > 0 && $status < 100) $lstatus = 2;
    	          else $lstatus = 0;
		          
                if($unique < 1 && $lstatus==1){
		          
                    $data = [
                        'user_id' => $user_id,
                        'ref_id' => $invoice,
                        'reference' => 'Coinpayment',
                        'amount' => $amount1,
                        'init_amount' => $amount2,
                        'time' => now(),
                        'status' => 1,
                        'currency' => $currency2,
                        'description' => ''
                    ];
                    
                    if($this->model->inserter($data)){ 
                    
                        //update user balance
                        $User = $this->model->retrieve($user_id); //new \App\Libraries\IonAuth();
                        //$User = $ionAuth->user()->row();
                        
                        $data = [
                            'wallet' => ($amount1) + $User->wallet,
                        ];
                        
                        if($this->model->updater($user_id, $data)){
                            session()->setFlashdata("errorPayment", view('messages/single',['message' => "Funding is Processing"]) );
                    		return redirect()->to(previous_url()."#payModal");
                        }else{
                	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "There was an error while updating your wallet"]) );
                    		return redirect()->to(previous_url()."#payModal");
                        }
                        
                    }else{
            	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "There was an error while updating your deposit"]) );
                		return redirect()->to(previous_url()."#payModal");
                    }
                    
                }else{
        	        session()->setFlashdata("errorPayment", view('errors/form/single',['error' => "Transaction is not unique or Awaiting Confirmation on Blockchain"]) );
            		return redirect()->to(previous_url()."#payModal");
                }
                
        }
	}
}