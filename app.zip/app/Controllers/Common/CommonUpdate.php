<?php

namespace App\Controllers\Common;

use App\Controllers\BaseController;
use App\Models\Common\CommonUpdateModel;

class CommonUpdate extends BaseController{
	protected $model;
	private $email;

	public function __construct() {
		$this->model = new CommonUpdateModel();
		
		$this->email = \Config\Services::email();
	}

	public function index(){
		return view('welcome_message');
    }
    
    public function Newsletter(){
        
        $this->validation->setRule('newsletter', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email');
        
        if($this->request->getPost()){
		    
		    if($this->validation->withRequest($this->request)->run()){
                $data = [
                    'email' => $this->request->getVar('newsletter'), 
                    'date' => now(),
                    'status' => 1
                ];
                
            if ($this->model->inserter('newsletter', $data)) {
                session()->setFlashdata("error", view('messages/single',['message' => 'You have subscribed successfully']) );
            } else {
    			session()->setFlashdata("error", view('errors/form/single',['error' => 'An error occure while updating your request']) );
            }
            return redirect()->back();
            
        }else{
    				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
    				return redirect()->back();
    	}
    		
        }return redirect()->back();
        
    }
    
    public function Inquiry(){
	    //captcha
	    if(!$this->reCaptcha($this->request->getVar('g-recaptcha-response'))){
			session()->setFlashdata("error", view('errors/form/single', ['error' => 'Captcha Authentication Failed']) );
			return redirect()->back();
	    }
	    
		$this->email = \Config\Services::email();
        
        $this->validation->setRule('email', lang('Auth.create_user_validation_email_label'), 'trim|required|valid_email');
		$this->validation->setRule('name', 'Name', 'trim|required');
		$this->validation->setRule('subject', 'Subject', 'trim|required');
		$this->validation->setRule('text', 'Description', 'trim|required');
        
        if($this->request->getPost()){
		    
    		if($this->validation->withRequest($this->request)->run()){
    		       
    		            $this->email->initialize($this->emailParameters);
    		        
    					$this->email->clear();
    					$this->email->setFrom($this->request->getVar('email'), ucfirst($this->request->getVar('name')));
    					$this->email->setTo($this->contact['email']);
    					$this->email->setSubject(strtoupper('Contact Form Enquiry : ').$this->request->getVar('subject'));
    					$this->email->setMessage($this->request->getVar('text'));
                    
                if ($this->email->send()) {
                    session()->setFlashdata("error", view('messages/single',['message' => 'You enquiry sent successfully']) );
                } else {
        			session()->setFlashdata("error", view('errors/form/single',['error' => 'An error occure while updating your request']) );
                }
                return redirect()->back();
                
            }else{
        				session()->setFlashdata("error", view('errors/form/list', ['errors' => $this->validation->getErrors()]) );
        				return redirect()->back();
        	}
    		
        }return redirect()->back();
        
    }
}