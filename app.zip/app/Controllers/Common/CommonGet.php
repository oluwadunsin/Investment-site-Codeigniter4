<?php

namespace App\Controllers\Common;

use App\Controllers\BaseController;
use App\Models\Common\CommonGetModel;

class CommonGet extends BaseController{
	protected $model;

	public function __construct() {
		$this->model = new CommonGetModel();
	}

	public function index(){
		return view('404');
    }

	public function Sitemap(){
           $xml_file = file_get_contents(ROOTPATH. "sitemap.xml");
           $this->response->setXML($xml_file);
           $this->response->setHeader('content-type', 'application/xml');
           echo $xml_file;
		   //return view('/Common/sitemap.xml');
    }

	protected function notFound($page){
        if(!is_file(APPPATH.'/Views/Common/'.$page.'.php')){
            //Whoops, we don't have a page for that!
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }else return true;
	}

    public function Home(){
		if($this->notFound('home')){
            $data = $this->model->getPage('home_key','home_value');

            $data['section2a'] = json_decode($data['section2a']);
            $data['section2b'] = json_decode($data['section2b']);
            $data['section2c'] = json_decode($data['section2c']);
            $data['section4a'] = json_decode($data['section4a']);
            $data['section4b'] = json_decode($data['section4b']);
            $data['section4c'] = json_decode($data['section4c']);
            $data['about_points'] = json_decode($data['about_points']);
            
            $data['products'] =  $this->model->getPlansActive();

			for($i = 0; $i < count($data['products']); $i++){
				$data['products'][$i]['minimum'] = number_to_currency(floatval($data['products'][$i]['minimum']), $this->site['site_currency'],null,2);
				$data['products'][$i]['maximum'] = number_to_currency(floatval($data['products'][$i]['maximum']), $this->site['site_currency'],null,2);
			}
			
            $data['page'] = 'home';

			return $this->view('home',$data,false);
        }

    }

    public function About(){
		if($this->notFound('about')){
            $data = $this->model->getPage('about_key','about_value');
            
            $data['stats'] = json_decode($data['stats']);
            $data['why'] = json_decode($data['why']);
    
            $data['page'] = 'about';

			return $this->view('about',$data,true);
        }

    }

    public function History(){
		if($this->notFound('history')){
            $data = $this->model->getPage('history_key','history_value');
            
            $data['history'] = json_decode($data['history']);
    
            $data['page'] = 'history';

			return $this->view('history',$data,true);
        }

    }

    public function Services(){
		if($this->notFound('services')){
            $data = $this->model->getPage('inv_key','inv_value');
            
            $data['packages'] = json_decode($data['packages']);
    
            $data['page'] = 'services';

			return $this->view('services',$data,true);
        }

    }

    public function Faq(){
		if($this->notFound('faq')){
            $data = $this->model->getPage('faq_key','faq_value');
            $data['faq'] = $this->model->getFaq();
    
            $data['page'] = 'faq';

			return $this->view('faq',$data,true);
        }

    }

    public function Testimonials(){
		if($this->notFound('testimonials')){
            $data = $this->model->getPage('review_key','review_value');
            $data['testimonial'] = $this->model->getTestimonials();
    
            $data['page'] = 'testimonials';

			return $this->view('testimonials',$data,true);
        }

    }

    public function Contact(){
		if($this->notFound('contact')){
            return $this->view('contact',['page_title' => $this->contact['contact_heading'], 'page' => 'contact'],true);
        }

    }

    public function Media(){
		if($this->notFound('media')){
            $data = $this->model->getPage('media_key','media_value');
            
            $data['media'] = $this->model->getGallery();
    
            $data['page'] = 'media';

			return $this->view('media',$data,true);
        }

    }

    public function Terms(){
		if($this->notFound('terms')){
            $data = $this->model->getPage('terms_key','terms_value');
            
            $data['page'] = 'terms';

			return $this->view('terms',$data,true);
        }

    }

    public function Privacy(){
		if($this->notFound('privacy')){
            $data = $this->model->getPage('privacy_key','privacy_value');
            
            $data['page'] = 'privacy';

			return $this->view('privacy',$data,true);
        }

    }

    public function Covid(){
		if($this->notFound('covid')){
            $data = $this->model->getPage('covid_key','covid_value');
            
            $data['page'] = 'covid';

			return $this->view('covid',$data,true);
        }

    }    
    
    public function Affiliate(){
		if($this->notFound('affiliate')){
            $data = $this->model->getPage('aff_key','aff_value');
            
            $data['page'] = 'affiliate';

			return $this->view('affiliate',$data,true);
        }

    }

    
    protected function view($page,$data,$top){
        
        $data = array_merge($data,$this->contact);
		$data = array_merge($data,$this->site);
        $status = new \App\Libraries\IonAuth();
        $data['loggedU'] = $status->loggedIn();
        $data['loggedA'] = $status->isAdmin();
        $data['datez'] = now();
        $data['base_url'] = base_url();
        $data['info'] = session()->getFlashdata("error");
        
		//exit('<pre>'.print_r($data,true).'</pre>');

		echo $this->parser->setData($data)->render('/Common/templates/header');
		if($top) echo $this->parser->setData($data)->render('/Common/templates/top');
		echo $this->parser->setData($data)->render('/Common/'.$page);
		if($page == 'history' || $page == 'affiliate' || $page == 'testimonials') echo $this->parser->setData($data)->render('/Common/templates/sidebar');
		echo $this->parser->setData($data)->render('/Common/templates/newsletter');
	    echo $this->parser->setData($data)->render('/Common/templates/base');
		echo $this->parser->setData($data)->render('/Common/templates/footer');

    }
}