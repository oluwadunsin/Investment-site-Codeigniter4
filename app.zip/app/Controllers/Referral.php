<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Referral extends BaseController
{
	public function index($ref){
        
		helper('cookie');
		
		if(get_cookie($this->site['site_name'].'-referral',true)){
		    set_cookie($this->site['site_name'].'-referral',$ref,now()+2592000);
        }
		    
            return redirect()->to(base_url('register'));

    }
}