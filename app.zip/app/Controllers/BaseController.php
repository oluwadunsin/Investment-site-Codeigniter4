<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use CodeIgniter\I18n\Time;
use App\Models\SiteModel;
use App\Models\ContactModel;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */

class BaseController extends Controller{
	protected $parser;
	protected $contactModel;
	protected $contact;
	protected $siteModel;
	protected $site;
    protected $validation;
	protected $browser;
	protected $ip;
	protected $location;
	protected $locationCode;
	protected $time;
	protected $session;
	protected $emailParameters = [];
	
	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	

	/**
	 * Constructor.
	 *
	 * @param RequestInterface  $request
	 * @param ResponseInterface $response
	 * @param LoggerInterface   $logger
	 */
	
	public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger){
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);
		
		//--------------------------------------------------------------------
		// Preload any models, libraries, etc, here.
		//--------------------------------------------------------------------
		// E.g.: $this->session = \Config\Services::session();

		//helpers
		helper(['date','url','number','filesystem']);
		
		//session
		$this->session = \Config\Services::session();
		//validation
        $this->validation = \Config\Services::validation();
        //parser
		$this->parser = \Config\Services::parser();
		
		//globals
		$this->siteModel = new SiteModel();
		$this->contactModel = new ContactModel();

		$this->site = $this->siteModel->getSite();
		$this->contact = $this->contactModel->getContact();
		
		//timezone
		date_default_timezone_set($this->site['time_zone']);

		//Time
		$this->time = new Time('now',$this->site['time_zone'],'en_us');

		//get Browser
		$browser = new \App\Libraries\BrowserDetection();
		$this->browser = $browser->getName().' '.$browser->getVersion();
		
		//get ip
		$this->ip = $this->request->getIPAddress();
		$this->emailParameters['SMTPHost'] = $this->contact['smtp_host'];
		$this->emailParameters['SMTPUser'] = $this->contact['smtp_username'];
		$this->emailParameters['SMTPPass'] = $this->contact['smtp_password'];
		$this->emailParameters['SMTPPort'] = $this->contact['smtp_port'];
		$this->emailParameters['SMTPTimeout'] = $this->contact['smtp_timeout'];
		$this->emailParameters['SMTPKeepAlive'] = $this->contact['smtp_keepAlive'];
		$this->emailParameters['SMTPCrypto'] = strtolower($this->contact['smtp_encryption']);
	}
		
	//--------------------------------------------------------------------
	// Google recaptcha
	//--------------------------------------------------------------------
	protected function reCaptcha($response){
		if($this->site['captcha_enabled']){
		  $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$this->site['captcha_private_key'].'&response='.$response);
		  $responseData = json_decode($verifyResponse);
		  if($responseData->success) return true;
		  else return false;
	  }else return true;

	}
		
	//--------------------------------------------------------------------
	// Get Location
	//--------------------------------------------------------------------
	protected function getLocation(){
		$location = json_decode(file_get_contents('http://ip-api.com/json/'.$this->ip.'?fields=status,country,city,countryCode'));
		$this->location = $location->city.', '.$location->country;
		$this->locationCode = $location->countryCode;

	}
		
	//--------------------------------------------------------------------
	// image Upload
	//--------------------------------------------------------------------

    protected function imageUpload($formName,$name,$path,$arr=false){
        try {

			$valid_file_types = array("image/png", "image/jpeg", "image/jpg");

				$valid_file_types = array("image/png", "image/jpeg", "image/jpg");

                if($imagefile = $this->request->getFiles() && $arr){
                    $cnt = 0;
                    foreach($imagefile[$formName] as $img){
                        if ($img->isValid() && ! $img->hasMoved() && in_array($img->getClientMimeType(), $valid_file_types)){
                            $ext = $img->getClientExtension();
                            $img->move($path[$cnt], $name[$cnt].'.'.$ext);
                        }else return false;
                        $cnt++;
                    }
					return true;
                }else if($imagefile = $this->request->getFile($formName)){
                    if ($imagefile->isValid() && !$imagefile->hasMoved() && in_array($imagefile->getClientMimeType(), $valid_file_types)){
                        $ext = $imagefile->getClientExtension();
                        $imagefile->move($path, $name.'.'.$ext);
						return true;
                    }else return false;
                }else return false;

        }catch (\CodeIgniter\UnknownFileException $e){
            return  ($e->getErrorString().'('.$e->getError().')');
        }
    }
		
	//--------------------------------------------------------------------
	// image edit
	//--------------------------------------------------------------------

    protected function imageEdit($from,$to,$convert,$width,$height){
        try {
            $image = \Config\Services::image();
			//IMAGETYPE_GIF //IMAGETYPE_JPEG //IMAGETYPE_PNG //IMAGETYPE_BMP
			//exit($image->withFile($from)->fit($width, $height, 'center')->convert($convert)->save($to));
			if($image->withFile($from)->fit($width, $height, 'center')->convert($convert)->save($to)) return true;
			else return false;
        }catch (CodeIgniter\Images\ImageException $e){
                return  $e->getMessage();
        }
    }
}
