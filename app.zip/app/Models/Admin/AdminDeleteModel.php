<?php

namespace App\Models\Admin;

use App\Models\BaseModel;

class AdminDeleteModel extends BaseModel{
    
    public function Deposits($id) {
      $builder = $this->db->table('deposit');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Withdrawals($id) {
      $builder = $this->db->table('withdrawal');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Referrals($id) {
      $builder = $this->db->table('referral');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Settings($id) {
      $builder = $this->db->table('site');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Newsletter($id) {
      $builder = $this->db->table('newsletter');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function wiper($id) {
      
      $builder = $this->db->table('deposit');
      $builder->where(['user_id' => $id])->delete();
      
      $builder = $this->db->table('withdrawal');
      $builder->where(['user_id' => $id])->delete();
      
      $builder = $this->db->table('login_history');
      $builder->where(['user_id' => $id])->delete();
      
      $builder = $this->db->table('mail');
      $builder->where(['_to' => $id])->delete();
      
      $builder = $this->db->table('mail');
      $builder->where(['_from' => $id])->delete();
      
      $builder = $this->db->table('my_investments');
      $builder->where(['user_id' => $id])->delete();
      
      $builder = $this->db->table('referral');
      $builder->where(['user_id' => $id])->delete();
      
      $builder = $this->db->table('referral');
      $builder->where(['referer' => $id])->delete();
      
      return;
    }
    
    public function Plan($id){
      $builder = $this->db->table('plans');
      $img = $builder->where(['id' => $id])->get()->getRowArray()['image'];
      if($img != null && file_exists(ROOTPATH.'public/products/'.$img)) unlink(ROOTPATH.'public/products/'.$img);
      $builder->where(['id' => $id])->delete();
      
      $builder = $this->db->table('my_investments');
      return $builder->where(['plan' => $id])->delete();
    }
    
    public function Investment($id) {
      $builder = $this->db->table('my_investments');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Faq($id) {
      $builder = $this->db->table('faq');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Testimonials($id) {
      $builder = $this->db->table('faq');
      return $builder->where(['id' => $id])->delete();
    }
    
    public function Gallery($id){
      $builder = $this->db->table('gallery');
      $img = $builder->where(['id' => $id])->get()->getRowArray()['img'];
      if($img != null && file_exists(ROOTPATH.'public/common/assets/images/gallery/'.$img)) unlink(ROOTPATH.'public/common/assets/images/gallery/'.$img);
      return $builder->where(['id' => $id])->delete();
    }
}