<?php

namespace App\Models\Admin;

use App\Models\BaseModel;

class AdminGetModel extends BaseModel{
    
    public function getAllLogin() {
      $builder = $this->db->table('login_history');

          $last_hour = strtotime("last hour");
          $today = strtotime("today");
          $yesterday = strtotime("yesterday");
          $week = strtotime("this week");
          $month = strtotime("first day of this month");
          $year = strtotime("first day of january this year");
          
          $temp = Array();
          
          $temp['hour'] = $builder->where(['time >=' =>  $last_hour])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['today'] = $builder->where(['time >=' => $today])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['yesterday'] = $builder->where(['time >=' => $yesterday, 'time <=' => $today])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['week'] = $builder->where(['time >=' =>  $week])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['month'] = $builder->where(['time >=' =>  $month])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['year'] = $builder->where(['time >=' =>  $year])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['all'] = $builder->orderBy('id', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllDeposit() {
      $builder = $this->db->table('deposit');

          $temp = Array();
          
          $temp['waiting'] = $builder->where(['status' =>  0])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['processed'] = $builder->where(['status' =>  1])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['pending'] = $builder->where(['status' =>  2])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['insufficient'] = $builder->where(['status' =>  3])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['cancelled'] = $builder->where(['status' =>  4])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['all'] = $builder->orderBy('time', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllWithdrawal() {
      $builder = $this->db->table('withdrawal');

          $temp = Array();
          
          $temp['waiting'] = $builder->where(['status' =>  0])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['processed'] = $builder->where(['status' =>  1])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['pending'] = $builder->where(['status' =>  2])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['insufficient'] = $builder->where(['status' =>  3])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['cancelled'] = $builder->where(['status' =>  4])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['all'] = $builder->orderBy('id', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllReferral() {
      $builder = $this->db->table('referral');
        // order by time referre invested

          $temp = Array();
          
          $temp['waiting'] = $builder->where(['status' =>  0])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['paid'] = $builder->where(['status' =>  1])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['pending'] = $builder->where(['status' =>  2])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['cancelled'] = $builder->where(['status' =>  3])->orderBy('id', 'DESC')->get()->getResultArray();
          
          $temp['vwaiting'] = $builder->where(['valid' =>  0])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['vinvested'] = $builder->where(['valid' =>  1])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['vpending'] = $builder->where(['valid' =>  2])->orderBy('id', 'DESC')->get()->getResultArray();
          $temp['vcancelled'] = $builder->where(['valid' =>  3])->orderBy('id', 'DESC')->get()->getResultArray();
          
          $temp['all'] = $builder->orderBy('id', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllWithdrawMethods() {
      $builder = $this->db->table('withdrawal_method');
        return $builder->get()->getResultArray();
    }
    
    public function getAllPages($d_key, $d_value){
        
        $builder = $this->db->table('pages');
        $row = $builder->select($d_key.",". $d_value)->get()->getResult();
        $temp = array();
        foreach($row as $key){
          $temp[$key->{$d_key}] = $key->$d_value;
        }
        return array($temp);

    }
    
    public function getAllFaqs(){
        
        $builder = $this->db->table('faq');
        return $builder->get()->getResultArray();
    }
    
    public function getAllTestimonials(){
        
        $builder = $this->db->table('testimonials');
        return $builder->get()->getResultArray();
    }
    
    public function getAllNewsletter(){
        
        $builder = $this->db->table('newsletter');

          $temp = Array();
          
          $temp['active'] = $builder->where(['status' =>  0])->orderBy('date', 'DESC')->get()->getResultArray();
          $temp['inactive'] = $builder->where(['status' =>  1])->orderBy('date', 'DESC')->get()->getResultArray();
          $temp['all'] = $builder->orderBy('date', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllMailInbox() {
      $builder = $this->db->table('mail');
      return $builder->where(['_to' => 1, 'inbox' => 1])->get()->getResultArray();
    }
    
    public function getAllInboxCount() {
      $builder = $this->db->table('mail');
      $builder->selectCount('inbox');
      return $builder->where(['_to' => 1, 'read' => 0, 'inbox' => 1])->get()->getRowArray(0)['inbox'];
    }
    
    public function getAllMail($mid) {
      $builder = $this->db->table('mail');
      return $builder->where(['id' => $mid])->get()->getResultArray();
    }
    
    public function getAllMailSent() {
      $builder = $this->db->table('mail');
      return $builder->where(['_from' => 1, 'inbox' => 1])->get()->getResultArray();
    }
    
    public function getAllUserProfit($uid) {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('profit');
      return $builder->where(['user_id' => $uid])->get()->getRowArray(0)['profit'];
    }
    
    public function getAllUserInvested($uid) {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('invested');
      return $builder->where(['user_id' => $uid])->get()->getRowArray(0)['invested'];
    }
    
    public function getAllUserDeposit($uid) {
      $builder = $this->db->table('deposit');
      $builder->selectSum('amount');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getAllUserWithdraw($uid) {
      $builder = $this->db->table('withdrawal');
      $builder->selectSum('amount');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getAllUserReferral($uid) {
      $builder = $this->db->table('referral');
      $builder->selectSum('commission');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['commission'];
    }
    
    public function getAllPlansActive() { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1])->get()->getResultArray();
    }
    
    public function getAllPlansInActive() { 
      $builder = $this->db->table('plans');
        return $builder->where(['active !=' => 1])->get()->getResultArray();
    }
    
    public function getAllPlans() { 
      $builder = $this->db->table('plans');
        return $builder->get()->getResultArray();
    }
    
    public function getAllInvested() {
      $builder = $this->db->table('my_investments');

          $temp = Array();
          
          $temp['waiting'] = $builder->where(['status' =>  0])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['active'] = $builder->where(['status' =>  1])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['paused'] = $builder->where(['status' =>  2])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['completed'] = $builder->where(['status' =>  3])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['cancelled'] = $builder->where(['status' =>  4])->orderBy('time', 'DESC')->get()->getResultArray();
          $temp['all'] = $builder->orderBy('time', 'DESC')->get()->getResultArray();
          
        return $temp;
    }
    
    public function getAllGallery() {
      $builder = $this->db->table('gallery');
        return $builder->orderBy('id', 'ASC')->get()->getResultArray();
    }
    
    
    ///=================================================================================================================
    
    public function getDashboardDepositTotal() {
      $builder = $this->db->table('deposit');
      $builder->selectSum('amount');
      return $builder->where(['status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardDepositMonth() {
      $builder = $this->db->table('deposit');
      $month = strtotime("first day of this month");
      $builder->selectSum('amount');
      return $builder->where(['status' => 1,'time >=' =>  $month])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardDepositWeek() {
      $builder = $this->db->table('deposit');
      $week = strtotime("this week");
      $builder->selectSum('amount');
      return $builder->where(['status' => 1,'time >=' =>  $week])->get()->getRowArray(0)['amount'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardWithdrawalTotal() {
      $builder = $this->db->table('withdrawal');
      $builder->selectSum('amount');
      return $builder->where(['status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardWithdrawalMonth() {
      $builder = $this->db->table('withdrawal');
      $month = strtotime("first day of this month");
      $builder->selectSum('amount');
      return $builder->where(['status' => 1,'time >=' =>  $month])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardWithdrawalWeek() {
      $builder = $this->db->table('withdrawal');
      $week = strtotime("this week");
      $builder->selectSum('amount');
      return $builder->where(['status' => 1,'time >=' =>  $week])->get()->getRowArray(0)['amount'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardReferralTotal() {
      $builder = $this->db->table('referral');
      $builder->selectSum('commission');
      return $builder->get()->getRowArray(0)['commission'];
    }
    
    public function getDashboardReferralMonth() {
      $builder = $this->db->table('referral');
      $month = strtotime("first day of this month");
      $builder->selectSum('commission');
      return $builder->where(['time_o >=' =>  $month])->get()->getRowArray(0)['commission'];
    }
    
    public function getDashboardReferralWeek() {
      $builder = $this->db->table('referral');
      $week = strtotime("this week");
      $builder->selectSum('commission');
      return $builder->where(['time_o >=' =>  $week])->get()->getRowArray(0)['commission'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardInvestedTotal() {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('invested');
      return $builder->where(['status' => 1])->get()->getRowArray(0)['invested'];
    }
    
    public function getDashboardInvestedMonth() {
      $builder = $this->db->table('my_investments');
      $month = strtotime("first day of this month");
      $builder->selectSum('invested');
      return $builder->where(['status' => 1,'time >=' =>  $month])->get()->getRowArray(0)['invested'];
    }
    
    public function getDashboardInvestedWeek() {
      $builder = $this->db->table('my_investments');
      $week = strtotime("this week");
      $builder->selectSum('invested');
      return $builder->where(['status' => 1,'time >=' =>  $week])->get()->getRowArray(0)['invested'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardWithdrawableTotal() {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('withdrawable');
      return $builder->where(['status' => 1])->get()->getRowArray(0)['withdrawable'];
    }
    
    public function getDashboardWithdrawableMonth() {
      $builder = $this->db->table('my_investments');
      $month = strtotime("first day of this month");
      $builder->selectSum('withdrawable');
      return $builder->where(['status' => 1,'time >=' =>  $month])->get()->getRowArray(0)['withdrawable'];
    }
    
    public function getDashboardWithdrawableWeek() {
      $builder = $this->db->table('my_investments');
      $week = strtotime("this week");
      $builder->selectSum('withdrawable');
      return $builder->where(['status' => 1,'time >=' =>  $week])->get()->getRowArray(0)['withdrawable'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardProfitTotal() {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('profit');
      return $builder->where(['status' => 1])->get()->getRowArray(0)['profit'];
    }
    
    public function getDashboardProfitMonth() {
      $builder = $this->db->table('my_investments');
      $month = strtotime("first day of this month");
      $builder->selectSum('profit');
      return $builder->where(['status' => 1,'time >=' =>  $month])->get()->getRowArray(0)['profit'];
    }
    
    public function getDashboardProfitWeek() {
      $builder = $this->db->table('my_investments');
      $week = strtotime("this week");
      $builder->selectSum('profit');
      return $builder->where(['status' => 1,'time >=' =>  $week])->get()->getRowArray(0)['profit'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardUsersTotal() {
      $builder = $this->db->table('users');
      $builder->selectCount('id');
      return $builder->get()->getRowArray(0)['id'];
    }
    
    public function getDashboardUsersMonth() {
      $builder = $this->db->table('users');
      $month = strtotime("first day of this month");
      $builder->selectCount('id');
      return $builder->where(['created_on >=' =>  $month])->get()->getRowArray(0)['id'];
    }
    
    public function getDashboardUsersWeek() {
      $builder = $this->db->table('users');
      $week = strtotime("this week");
      $builder->selectCount('id');
      return $builder->where(['created_on >=' =>  $week])->get()->getRowArray(0)['id'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardWalletTotal() {
      $builder = $this->db->table('users');
      $builder->selectSum('wallet');
      return $builder->get()->getRowArray(0)['wallet'];
    }
    
    public function getDashboardWalletMonth() {
      $builder = $this->db->table('users');
      $month = strtotime("first day of this month");
      $builder->selectSum('wallet');
      return $builder->where(['created_on >=' =>  $month])->get()->getRowArray(0)['wallet'];
    }
    
    public function getDashboardWalletWeek() {
      $builder = $this->db->table('users');
      $week = strtotime("this week");
      $builder->selectSum('wallet');
      return $builder->where(['created_on >=' =>  $week])->get()->getRowArray(0)['wallet'];
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public function getDashboardMailTotal() {
      $builder = $this->db->table('mail');
      $builder->selectCount('id');
      return $builder->where(['time' => 1,'read' => 0, '_to' => 1])->get()->getRowArray(0)['id'];
    }
    
    public function getDashboardMailMonth() {
      $builder = $this->db->table('mail');
      $month = strtotime("first day of this month");
      $builder->selectCount('id');
      return $builder->where(['time >=' =>  $month,'read' => 0, '_to' => 1])->get()->getRowArray(0)['id'];
    }
    
    public function getDashboardMailWeek() {
      $builder = $this->db->table('mail');
      $week = strtotime("this week");
      $builder->selectCount('id');
      return $builder->where(['time >=' =>  $week,'read' => 0, '_to' => 1])->get()->getRowArray(0)['id'];
    }
    
    ///=================================================================================================================
    
    public function getDashboardCount($id) {
      $builder = $this->db->table('my_investments');
      $builder->selectCount('id');
      return $builder->where(['id' =>  $id])->get()->getRowArray(0)['id'];
    }
    
    public function getDashboardSum($pid) {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('invested');
      return $builder->where(['plan' =>  $pid])->get()->getRowArray(0)['invested'];
    }
}