<?php

namespace App\Models\Admin;

use App\Models\BaseModel;

class AdminUpdateInsertModel extends BaseModel{
    
    public function updater($table,$data,$where,$escape) {

      $builder = $this->db->table($table);

      return $builder->set($data,$escape)->where($where)->update();
    }
    
    public function inserter($table,$data,$escape) {

      $builder = $this->db->table($table);

      $builder->set($data,$escape)->insert();
      $id = $this->db->insertID();
      return (string)$id;
    }


    public function replacer($table, $data, $where, $column) {
      	  foreach ($data as $key => $val) :
    	      $q = "UPDATE " . $table . " SET ";
              $q .= $column." = " . $this->db->escape($val);
              $q .= " WHERE " . $where . " = " .$this->db->escape($key);
              $this->db->query($q);
          endforeach;
          return true;
    }
    
    public function getMailSpecific($uid,$mid) { 
      $builder = $this->db->table('mail');
        $where = "(_to = ".$uid." AND id = ".$mid.") OR (_from = ".$uid." AND id = ".$mid.")";
        return $builder->where($where)->get()->getResultArray();
    }
    
    public function getPlanSpecific($pid) { 
      $builder = $this->db->table('plans');
        return $builder->where(['id' => $pid])->get()->getResultArray();
    }
    
    public function getReferralSpecific($uid) {
      $builder = $this->db->table('referral');
        return $builder->getWhere(['user_id' => $uid])->getRowArray();
    }
    
    public function getAllPlansActive() { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1])->get()->getResultArray();
    }
}