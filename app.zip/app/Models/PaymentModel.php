<?php

namespace App\Models;

use App\Models\BaseModel;

class PaymentModel extends BaseModel{
    
    public function retrieve($userId) {

      $builder = $this->db->table('users');

      return $builder->where(['id' => $userId])->get()->getRow();
    }
    
    public function updater($userId,$data) {

      $builder = $this->db->table('users');

      return $builder->set($data)->where(['id' => $userId])->update();
    }
    
    public function inserter($data) {

      $builder = $this->db->table('deposit');

      return $builder->set($data)->insert();
    }
    
    public function getCount($ref_id) {
      $builder = $this->db->table('deposit');
        return $builder->where(['ref_id' => $ref_id])->countAllResults();
    }
}