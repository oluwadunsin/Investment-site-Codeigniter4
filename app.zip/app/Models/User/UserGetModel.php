<?php

namespace App\Models\User;

use App\Models\BaseModel;

class UserGetModel extends BaseModel{
    
    public function getMailInbox($uid) {
      $builder = $this->db->table('mail');
      return $builder->where(['_to' => $uid, 'inbox' => 1])->get()->getResultArray();
    }
    
    public function getMailSent($uid) {
      $builder = $this->db->table('mail');
      return $builder->where(['_from' => $uid, 'inbox' => 1])->get()->getResultArray();
    }
    
    public function getMail($mid) {
      $builder = $this->db->table('mail');
      return $builder->where(['id' => $mid])->get()->getResultArray();
    }
    
    public function getLogin($uid) {
      $builder = $this->db->table('login_history');
        return $builder->where(['user_id' => $uid])->orderBy('id', 'DESC')->get()->getResultArray();
    }
    
    public function getDeposit($uid) {
      $builder = $this->db->table('deposit');
        return $builder->where(['user_id' => $uid])->orderBy('id', 'DESC')->get()->getResultArray();
    }
    
    public function getWithdrawal($uid) {
      $builder = $this->db->table('withdrawal');
        return $builder->where(['user_id' => $uid])->orderBy('id', 'DESC')->get()->getResultArray();
    }
    
    public function getInvoice($uid) {
      $builder = $this->db->table('my_investments');
        return $builder->where(['user_id' => $uid])->orderBy('id', 'DESC')->get()->getResultArray();
    }
    
    public function getPlans() {
      $builder = $this->db->table('plans');
        return $builder->get()->getResultArray();
    }
    
    public function getPlansActive() { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1])->get()->getResultArray();
    }
    
    public function getPlansActiveSpecific($pid) { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1, 'id' => $pid])->get()->getResultArray();
    }
    
    public function getInvested($uid) {
      $builder = $this->db->table('my_investments');
        return $builder->where(['user_id' => $uid])->orderBy('id', 'DESC')->get()->getResultArray();
    }
    
    public function getWithdrawMethods() {
      $builder = $this->db->table('withdrawal_method');
        return $builder->getWhere(['status' => 1])->getResultArray();
    }
    
    public function getReferral($uid) {
      $builder = $this->db->table('referral');
        return $builder->where(['user_id' => $uid])->orderBy('time_o', 'DESC')->get()->getResultArray(); // order by time referre invested
    }
    
    public function getDashboard($uid) {
      $query = "SELECT status, time, amount ,'deposit' as action FROM deposit
                WHERE user_id=".$uid."
                UNION ALL
                SELECT status, time, amount, 'withdraw' as action FROM withdrawal
                WHERE user_id=".$uid."
                UNION ALL
                SELECT status, time, invested, 'invest'as action FROM my_investments
                WHERE user_id=".$uid."
                ORDER BY time DESC
                LIMIT 10";
      return $this->db->query($query)->getResultArray();
    }
    
    public function getDashboardProfit($uid) {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('profit');
      return $builder->where(['user_id' => $uid])->get()->getRowArray(0)['profit'];
    }
    
    public function getDashboardInvested($uid) {
      $builder = $this->db->table('my_investments');
      $builder->selectSum('invested');
      return $builder->where(['user_id' => $uid])->get()->getRowArray(0)['invested'];
    }
    
    public function getDashboardDeposit($uid) {
      $builder = $this->db->table('deposit');
      $builder->selectSum('amount');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardWithdraw($uid) {
      $builder = $this->db->table('withdrawal');
      $builder->selectSum('amount');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['amount'];
    }
    
    public function getDashboardReferral($uid) {
      $builder = $this->db->table('referral');
      $builder->selectSum('commission');
      return $builder->where(['user_id' => $uid, 'status' => 1])->get()->getRowArray(0)['commission'];
    }
    
    public function getInboxCount($uid) {
      $builder = $this->db->table('mail');
      $builder->selectCount('inbox');
      return $builder->where(['_to' => $uid, 'read' => 0, 'inbox' => 1])->get()->getRowArray(0)['inbox'];
    }
    
    public function getPage($d_key, $d_value){
        
        $builder = $this->db->table('pages');
        $query = $d_key.",". $d_value;
        $row = $builder->select($d_key.",". $d_value)->get()->getResult();
        $temp = array();
        foreach($row as $key){
          $temp[$key->{$d_key}] = $key->$d_value;
        }
        return $temp;

    }
    
    public function getFaq(){
        
        $builder = $this->db->table('faq');
        return $builder->get()->getResultArray();
    }
    
    public function getGallery() {
      $builder = $this->db->table('gallery');
        return $builder->orderBy('id', 'ASC')->get()->getResultArray();
    }
}