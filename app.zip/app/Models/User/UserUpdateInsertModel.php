<?php

namespace App\Models\User;

use App\Models\BaseModel;

class UserUpdateInsertModel extends BaseModel{
    
    public function updater($table,$data,$where,$escape) {

      $builder = $this->db->table($table);

      return $builder->set($data,$escape)->where($where)->update();
    }
    
    public function inserter($table,$data,$escape) {

      $builder = $this->db->table($table);

      return $builder->set($data,$escape)->insert();
    }
    
    public function getPlansActiveSpecific($pid) { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1, 'id' => $pid])->get()->getResultArray();
    }
    
    public function getMailSpecific($uid,$mid) { 
      $builder = $this->db->table('mail');
        $where = "(_to = ".$uid." AND id = ".$mid.") OR (_from = ".$uid." AND id = ".$mid.")";
        return $builder->where($where)->get()->getResultArray();
    }
}