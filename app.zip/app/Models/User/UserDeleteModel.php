<?php

namespace App\Models\User;

use App\Models\BaseModel;

class UserDeleteModel extends BaseModel{
    
    public function deleteMail($userId,$id) {
      $builder = $this->db->table('mail');
        
        return $builder->where(['_from' => $userId,'id' => $id])->delete();
    }
}