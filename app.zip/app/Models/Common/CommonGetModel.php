<?php

namespace App\Models\Common;

use App\Models\BaseModel;

class CommonGetModel extends BaseModel{
    
    public function getPage($d_key, $d_value){
        
        $builder = $this->db->table('pages');
        $query = $d_key.",". $d_value;
        $row = $builder->select($d_key.",". $d_value)->get()->getResult();
        $temp = array();
        foreach($row as $key){
          $temp[$key->{$d_key}] = $key->$d_value;
        }
        return $temp;

    }
    
    public function getFaq(){
        
        $builder = $this->db->table('faq');
        return $builder->get()->getResultArray();
    } 
    
    public function getTestimonials(){
        
        $builder = $this->db->table('testimonials');
        return $builder->get()->getResultArray();
    }
    
    public function getHomeGallery() {
      $builder = $this->db->table('gallery');
        return $builder->limit(9)->orderBy('id', 'ASC')->get()->getResultArray();
    }
    
    public function getGallery() {
      $builder = $this->db->table('gallery');
        return $builder->orderBy('id', 'ASC')->get()->getResultArray();
    }
    
    public function getPlansActive() { 
      $builder = $this->db->table('plans');
        return $builder->where(['active' => 1])->get()->getResultArray();
    }
}