<?php

namespace App\Models\Common;

use App\Models\BaseModel;

class CommonUpdateModel extends BaseModel{
    
    public function inserter($table,$data) {

      $builder = $this->db->table($table);

      return $builder->insert($data);
    }
}