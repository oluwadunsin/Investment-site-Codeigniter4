<?php

namespace App\Models;

use App\Models\BaseModel;

class SiteModel extends BaseModel{
    
    protected $table = 'site';
    
    public function getSite(){
        
        $row = $this->select('site_key, site_value')->get()->getResult();
        $temp = array();
        
        foreach($row as $key){
          $temp[$key->site_key] = $key->site_value;
        }
        return $temp;

    }
}