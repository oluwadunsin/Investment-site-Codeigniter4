<?php

namespace App\Models;

use App\Models\BaseModel;

class ContactModel extends BaseModel{
    
    protected $table = 'contact';
    
    public function getContact(){
        
        $row = $this->select('contact_key, contact_value')->get()->getResult();
        $temp = array();
        
        foreach($row as $key){
          $temp[$key->contact_key] = $key->contact_value;
        }
        return $temp;

    }
}