<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use App\Libraries\IonAuth;

/**
* Description of AuthFilter
*
* @author christian
*/
class IonAuth_Filter implements FilterInterface {

    public function before(RequestInterface $request, $arguments = null) {
        
        $this->ionAuth = new IonAuth();

        if ((!$this->ionAuth->loggedIn()) && $arguments[0] == 'user') {
            session()->set('redirect_url', current_url());
            return redirect()->to(base_url('login'));            
        }
        
        else if ((!$this->ionAuth->isAdmin()) && $arguments[0] == 'admin') {
            session()->set('redirect_url', current_url());
            return redirect()->to(base_url('login'));            
        }
        
        else if ($this->ionAuth->loggedIn() && $arguments[0] == 'other') {
            return redirect()->to(base_url('user/dashboard'));            
        }
    }

    //--------------------------------------------------------------------

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {
        // Do something here
    }

} 