<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
/**$routes->set404Override(function(){
    return view('Common/404');
});
$routes->set404Override('Commom::_404');**/
$routes->set404Override();
$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Common\CommonGet::Home');
$routes->get('', 'Common\CommonGet::Home');
//===============================================================
$routes->get('ref/(:any)', 'Referral::index/$1');
//===============================================================
$routes->get('index', 'Common\CommonGet::Home');
$routes->get('about','Common\CommonGet::About');
$routes->get('certificates','Common\CommonGet::Media');
$routes->get('contact','Common\CommonGet::Contact');
$routes->get('faq','Common\CommonGet::Faq');
$routes->get('home','Common\CommonGet::Home');
$routes->get('privacy','Common\CommonGet::Privacy');
$routes->get('terms','Common\CommonGet::Terms');
//$routes->get('history','Common\CommonGet::History');
$routes->get('services','Common\CommonGet::Services');
$routes->get('covid','Common\CommonGet::Covid');
$routes->get('affiliate','Common\CommonGet::Affiliate');
$routes->get('testimonials','Common\CommonGet::Testimonials');
$routes->get('sitemap','Common\CommonGet::Sitemap');
//===============================================================
$routes->post('newsletter','Common\CommonUpdate::Newsletter');
$routes->post('contact','Common\CommonUpdate::Inquiry');
//===============================================================
$routes->get('login', 'Auth\AuthGet::Login', ['filter' => 'UAuth:other']);
$routes->get('register', 'Auth\AuthGet::Register', ['filter' => 'UAuth:other']);
$routes->get('forgot', 'Auth\AuthGet::Forgot', ['filter' => 'UAuth:other']);
$routes->get('activate/(:num)/(:hash)', 'Auth\AuthGet::Activate/$1/$2');
$routes->get('reset/(:hash)', 'Auth\AuthGet::Reset/$1', ['filter' => 'UAuth:other']);
//===============================================================
$routes->post('login', 'Auth\AuthSet::Login', ['filter' => 'UAuth:other']);
$routes->post('register', 'Auth\AuthSet::Register', ['filter' => 'UAuth:other']);
$routes->post('forgot', 'Auth\AuthSet::Forgot', ['filter' => 'UAuth:other']);
$routes->post('activate/(:num)/(:hash)', 'Auth\AuthSet::Activate', ['filter' => 'UAuth:other']);
$routes->post('reset', 'Auth\AuthSet::Reset', ['filter' => 'UAuth:other']);
//===============================================================
$routes->group('user', ['filter' => 'UAuth:user'], function($routes){
	$routes->get('dashboard','User\UserGet::Dashboard');
	$routes->get('mail/view/(:segment)','User\UserGet::MailView/$1');
	$routes->get('mail/compose','User\UserGet::MailCompose');
	$routes->get('mail/inbox','User\UserGet::MailInbox');
	$routes->get('mail/sent','User\UserGet::MailSent');
	$routes->get('mail/update/(:segment)','User\UserCreate::MailViewed/$1');
	$routes->get('mail/delete/(:segment)','User\UserCreate::MailDelete/$1');
	$routes->get('login','User\UserGet::Login');
	$routes->get('deposit/history','User\UserGet::Deposits');
	$routes->get('withdraw/history','User\UserGet::Withdrawal');
	$routes->get('invoice','User\UserGet::Invoice');
	//$routes->get('invested','User\UserGet::Invested');
	$routes->get('invested','User\UserGet::Dashboard');
	$routes->get('withdraw','User\UserGet::Withdraw');
	$routes->get('profile','User\UserGet::Profile');
	$routes->get('settings','User\UserGet::Settings');
	$routes->get('referral','User\UserGet::Referral');
	$routes->get('plans','User\UserGet::Products');
	$routes->get('terms','User\UserGet::Terms');
	$routes->get('privacy','User\UserGet::Privacy');
	$routes->get('faq','User\UserGet::faq');
	$routes->get('gallery','User\UserGet::gallery');
	$routes->get('products/details/(:segment)','User\UserGet::Details/$1');
	$routes->get('products/cart/(:segment)','User\UserGet::Cart/$1');
	//$routes->get('products/checkout/(:segment)','User\UserCreate::Checkout/$1');
	$routes->get('products','User\UserGet::Products');
//===============================================================
	$routes->post('mail/compose','User\UserCreate::Mail');
	$routes->post('withdraw','User\UserCreate::Withdraw');
	$routes->post('profile/settings/password','Auth\AuthSet::Cpassword');
	$routes->post('profile/settings/picture','Auth\AuthSet::Picture');
	$routes->post('profile/settings/kyc','Auth\AuthSet::KYC');
	$routes->post('profile/settings','Auth\AuthSet::Settings');
	$routes->post('products/checkout','User\UserCreate::Checkout');
});
//===============================================================
$routes->get('logout', 'Auth\AuthSet::Logout');
$routes->get('user/logout', 'Auth\AuthSet::Logout');
$routes->get('admin/logout', 'Auth\AuthSet::Logout');
//===============================================================
$routes->match(['get','post'],'payment/paystack/(:segment)/(:segment)', 'Payment::Paystack/$1/$2');
$routes->match(['get','post'],'payment/coinpayment/(:segment)', 'Payment::Coinpayment/$1');
//===============================================================
$routes->group('admin', ['filter' => 'UAuth:admin'], function($routes){
	$routes->get('dashboard','Admin\AdminGet::Dashboard');
	$routes->get('logins','Admin\AdminGet::Login');
	$routes->get('deposits/delete/(:num)','Admin\AdminDelete::Deposits/$1');
	$routes->get('deposits','Admin\AdminGet::Deposits');
	$routes->get('withdrawals/delete/(:num)','Admin\AdminDelete::Withdrawals/$1');
	$routes->get('withdrawals','Admin\AdminGet::Withdrawal');
	$routes->get('referrals/delete/(:num)','Admin\AdminDelete::Referrals/$1');
	$routes->get('referrals','Admin\AdminGet::Referral');
	$routes->get('settings','Admin\AdminGet::Settings');
	$routes->get('settings/delete/(:num)','Admin\AdminDelete::Settings/$1');
	$routes->get('pages','Admin\AdminGet::Pages');
	$routes->get('pages/gallery/delete/(:num)','Admin\AdminDelete::Gallery/$1');
	$routes->get('pages/faq/delete/(:num)','Admin\AdminDelete::Faq/$1');
	$routes->get('pages/testimonials/delete/(:num)','Admin\AdminDelete::Testimonials/$1');
	$routes->get('newsletter','Admin\AdminGet::Newsletter');
	$routes->get('newsletter/delete/(:num)','Admin\AdminDelete::Newsletter/$1');
	$routes->get('mail/inbox','Admin\AdminGet::MailInbox');
	$routes->get('mail/view/(:segment)','Admin\AdminGet::MailView/$1');
	$routes->get('mail/sent','Admin\AdminGet::MailSent');
	$routes->get('mail/update/(:segment)','Admin\AdminCreate::MailViewed/$1');
	$routes->get('mail/delete/(:segment)','Admin\AdminCreate::MailDelete/$1');
	$routes->get('users','Admin\AdminGet::Users');
	$routes->get('users/delete/(:num)','Admin\AdminDelete::UserDelete/$1');
	$routes->get('users/activate/(:num)','Admin\AdminCreate::UserActivate/$1');
	$routes->get('users/deactivate/(:num)','Admin\AdminCreate::UserDeactivate/$1');
	$routes->get('users/kyc/(:segment)/(:segment)','Admin\AdminCreate::UserKyc/$1/$2');
	$routes->get('users/detail/(:num)','Admin\AdminGet::UserDetails/$1');
	$routes->get('plans','Admin\AdminGet::Plans');
	$routes->get('plans/image/delete/(:num)','Admin\AdminCreate::PlanImageDelete/$1');
	$routes->get('plans/delete/(:num)','Admin\AdminDelete::Plan/$1');
	$routes->get('investments','Admin\AdminGet::Investment');
	$routes->get('investments/delete/(:num)','Admin\AdminDelete::Investment/$1');
//===============================================================
	$routes->post('deposits/update','Admin\AdminCreate::Deposits');
	$routes->post('withdrawals/update','Admin\AdminCreate::Withdrawals');
	$routes->post('referrals/update','Admin\AdminCreate::Referrals');
	$routes->post('settings','Admin\AdminCreate::Settings');
	$routes->post('pages','Admin\AdminCreate::Pages');
	$routes->post('newsletter/update','Admin\AdminCreate::Newsletter');
	$routes->post('mail/compose','Admin\AdminCreate::Mail');
	$routes->post('user/wallet','Admin\AdminCreate::UserSettings');
	$routes->post('user/password','Admin\AdminCreate::UserPassword');
	$routes->post('user/profile','Admin\AdminCreate::UserSettings');
	$routes->post('plan','Admin\AdminCreate::Plan');
	$routes->post('investments','Admin\AdminCreate::Investment');
});

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
