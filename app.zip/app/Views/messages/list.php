<style>
    .error-notice{
     margin:5px; /* Make sure to keep some distance from all sides */
    }

    .oaerror{
        width:80%;
        background-color: #ffffff;
        padding:20px;
        border:1px solid #eee;
        border-left-width:5px;
        border-radius: 3px;
        margin:10px auto;
        font-family: 'Open Sans', sans-serif;
        font-size: 16px;
    }

    .success {
        border-left-color: #2b542c;
        background-color: rgba(43, 84, 44, 0.1);
    }

    .success strong {
        color: #2b542c;
    }
</style>

<?php if (! empty($messages)) : ?>
		<?php foreach ($messages as $message) : ?>
			<div class="error-notice">
					<div class="oaerror success">
						<strong>&#9733;</strong><span> - </span><?= esc($message) ?>
					</div>
			</div>
		<?php endforeach ?>
<?php endif ?>


