            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">{page_title|title}</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{page|capitalize}</li>
                    </ol>
                </div>
                <div class="ml-auto pageheader-btn">
                    <a href="user/plans" class="btn btn-primary btn-icon text-white mr-2">
                        <span>
                            <i class="fe fe-shopping-cart"></i>
                        </span> Add Investment
                    </a>
                    {if $allow_deposit=="true"}
                        <a  data-toggle="modal" data-target="#payModal" class="btn btn-secondary btn-icon text-white">
                            <span>
                                <i class="fe fe-plus"></i>
                            </span> Add Funds
                        </a>
                    {endif}
                </div>
            </div>
            <!-- PAGE-HEADER END -->
              <!-- ROW-1 -->
              {if $page != "dashboard" && $enable_jumbotron == "true"}
                <div class="row">
                 <div class="col-md-12">
                    <div class="card  banner">
                       <div class="card-body">
                          <div class="row">
                             <div class="col-xl-3 col-lg-2 text-center">
                                <img src="{jumbotron_img}" alt="img" class="w-95">
                             </div>
                             <div class="col-xl-9 col-lg-10 pl-lg-0">
                                <div class="row">
                                   <div class="col-xl-7 col-lg-6">
                                      <div class="text-left text-white mt-xl-4">
                                         <h3 class="font-weight-semibold">{jumbotron_heading}</h3>
                                         <h4 class="font-weight-normal">{jumbotron_body_1}</h4>
                                         <p class="mb-lg-0 text-white-50">{jumbotron_body_2}</p>
                                      </div>
                                   </div>
                                   <div class="col-xl-5 col-lg-6 text-lg-center mt-xl-4">
                                      <h5 class="font-weight-semibold mb-1 text-white">{jumbotron_sub-heading1}</h5>
                                      <h2 class="display-2 mb-3 number-font text-white">{jumbotron_sub-heading2}</h2>
                                      <div class="btn-list mb-xl-0">
                                         <a href="{jumbotron_btn1-link}" class="btn btn-dark mb-xl-0">{jumbotron_btn1}</a>
                                         <a href="{jumbotron_btn2-link}" class="btn btn-white mb-xl-0" id="skip">{jumbotron_btn2}</a>
                                      </div>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
              {endif}
              <!-- ROW-1 End-->