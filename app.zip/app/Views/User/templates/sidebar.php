
            <!--APP-SIDEBAR-->
            <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
            <aside class="app-sidebar">
			
               <div class="side-header">
                  <a class="header-brand1" href="user/dashboard">
                  <img src="common/assets/images/logo/logo.png" class="header-brand-img desktop-logo" alt="logo">
                  <img src="common/assets/images/logo/logo.png" class="header-brand-img toggle-logo" alt="logo">
                  <img src="common/assets/images/logo/logo.png" class="header-brand-img light-logo" alt="logo">
                  <img src="common/assets/images/logo/logo.png" class="header-brand-img light-logo1" alt="logo">
                  </a><!-- LOGO -->
               </div>
               <ul class="side-menu">
                  <li>
                     <h3>Main</h3>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/dashboard">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M3 4h18v10H3z" opacity=".3" />
                           <path d="M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7l-2 3v1h8v-1l-2-3h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 12H3V4h18v10z" />
                        </svg>
                        <span class="side-menu__label">Dashboard</span>
                     </a>
                  </li>
			      {if $loggedA}
                      <li class="slide">
                         <a class="side-menu__item" href="admin/dashboard">
                            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                               <path d="M0 0h24v24H0V0z" fill="none" />
                               <path d="M5 9h14V5H5v4zm2-3.5c.83 0 1.5.67 1.5 1.5S7.83 8.5 7 8.5 5.5 7.83 5.5 7 6.17 5.5 7 5.5zM5 19h14v-4H5v4zm2-3.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5z" opacity=".3" />
                               <path d="M20 13H4c-.55 0-1 .45-1 1v6c0 .55.45 1 1 1h16c.55 0 1-.45 1-1v-6c0-.55-.45-1-1-1zm-1 6H5v-4h14v4zm-12-.5c.83 0 1.5-.67 1.5-1.5s-.67-1.5-1.5-1.5-1.5.67-1.5 1.5.67 1.5 1.5 1.5zM20 3H4c-.55 0-1 .45-1 1v6c0 .55.45 1 1 1h16c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 6H5V5h14v4zM7 8.5c.83 0 1.5-.67 1.5-1.5S7.83 5.5 7 5.5 5.5 6.17 5.5 7 6.17 8.5 7 8.5z" />
                            </svg>
                            <span class="side-menu__label">Admin Area</span>
                         </a>
                      </li>
                  {endif}
                  <li class="slide">
                     <a class="side-menu__item" data-toggle="slide" href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M20 8l-8 5-8-5v10h16zm0-2H4l8 4.99z" opacity=".3" />
                           <path d="M4 20h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2zM20 6l-8 4.99L4 6h16zM4 8l8 5 8-5v10H4V8z" />
                        </svg>
                        <span class="side-menu__label">Mail</span><i class="angle fa fa-angle-right"></i>
                     </a>
                     <ul class="slide-menu">
                        <li><a href="user/mail/compose" class="slide-item">Mail-Compose</a></li>
                        <li><a href="user/mail/inbox" class="slide-item">Mail-Inbox</a></li>
                        <li><a href="user/mail/sent" class="slide-item">View-Mail</a></li>
                     </ul>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/plans">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M5 5v14h14V5H5zm4 12H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z" opacity=".3" />
                           <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z" />
                        </svg>
                        <span class="side-menu__label">Invest</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/invoice">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M7 3h14v14H7z" opacity=".3" />
                           <path d="M3 23h16v-2H3V5H1v16c0 1.1.9 2 2 2zM21 1H7c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 16H7V3h14v14z" />
                        </svg>
                        <span class="side-menu__label">Invoice</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/profile">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M6.26 9L12 13.47 17.74 9 12 4.53z" opacity=".3" />
                           <path d="M19.37 12.8l-7.38 5.74-7.37-5.73L3 14.07l9 7 9-7zM12 2L3 9l1.63 1.27L12 16l7.36-5.73L21 9l-9-7zm0 11.47L6.26 9 12 4.53 17.74 9 12 13.47z" />
                        </svg>
                        <span class="side-menu__label">Profile</span>
                     </a>
                  </li>
                   {if $allow_withdrawal=="true"} <li class="slide">
                     <a class="side-menu__item" href="user/withdraw">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M5 5v14h14V5H5zm4 12H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z" opacity=".3" />
                           <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z" />
                        </svg>
                        <span class="side-menu__label">Withdraw Funds</span>
                     </a>
                  </li>{endif}
                  <li class="slide">
                     <a class="side-menu__item" href="user/withdraw/history">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M12 4C9.24 4 7 6.24 7 9c0 2.85 2.92 7.21 5 9.88 2.11-2.69 5-7 5-9.88 0-2.76-2.24-5-5-5zm0 7.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" opacity=".3" />
                           <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.88-2.88 7.19-5 9.88C9.92 16.21 7 11.85 7 9z" />
                           <circle cx="12" cy="9" r="2.5" />
                        </svg>
                        <span class="side-menu__label">Withdrawal History</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/deposit/history">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M12 4C9.24 4 7 6.24 7 9c0 2.85 2.92 7.21 5 9.88 2.11-2.69 5-7 5-9.88 0-2.76-2.24-5-5-5zm0 7.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" opacity=".3" />
                           <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.88-2.88 7.19-5 9.88C9.92 16.21 7 11.85 7 9z" />
                           <circle cx="12" cy="9" r="2.5" />
                        </svg>
                        <span class="side-menu__label">Deposit History</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/login">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M12 4C9.24 4 7 6.24 7 9c0 2.85 2.92 7.21 5 9.88 2.11-2.69 5-7 5-9.88 0-2.76-2.24-5-5-5zm0 7.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" opacity=".3" />
                           <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.88-2.88 7.19-5 9.88C9.92 16.21 7 11.85 7 9z" />
                           <circle cx="12" cy="9" r="2.5" />
                        </svg>
                        <span class="side-menu__label">Login History</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/referral">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0z" fill="none" />
                           <path d="M12 4c-4.41 0-8 3.59-8 8s3.59 8 8 8c.28 0 .5-.22.5-.5 0-.16-.08-.28-.14-.35-.41-.46-.63-1.05-.63-1.65 0-1.38 1.12-2.5 2.5-2.5H16c2.21 0 4-1.79 4-4 0-3.86-3.59-7-8-7zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 10 6.5 10s1.5.67 1.5 1.5S7.33 13 6.5 13zm3-4C8.67 9 8 8.33 8 7.5S8.67 6 9.5 6s1.5.67 1.5 1.5S10.33 9 9.5 9zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 6 14.5 6s1.5.67 1.5 1.5S15.33 9 14.5 9zm4.5 2.5c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5.67-1.5 1.5-1.5 1.5.67 1.5 1.5z" opacity=".3" />
                           <path d="M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10c1.38 0 2.5-1.12 2.5-2.5 0-.61-.23-1.21-.64-1.67-.08-.09-.13-.21-.13-.33 0-.28.22-.5.5-.5H16c3.31 0 6-2.69 6-6 0-4.96-4.49-9-10-9zm4 13h-1.77c-1.38 0-2.5 1.12-2.5 2.5 0 .61.22 1.19.63 1.65.06.07.14.19.14.35 0 .28-.22.5-.5.5-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.14 8 7c0 2.21-1.79 4-4 4z" />
                           <circle cx="6.5" cy="11.5" r="1.5" />
                           <circle cx="9.5" cy="7.5" r="1.5" />
                           <circle cx="14.5" cy="7.5" r="1.5" />
                           <circle cx="17.5" cy="11.5" r="1.5" />
                        </svg>
                        <span class="side-menu__label">Referral History</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/gallery">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M5 5h4v4H5zm10 10h4v4h-4zM5 15h4v4H5zM16.66 4.52l-2.83 2.82 2.83 2.83 2.83-2.83z" opacity=".3" />
                           <path d="M16.66 1.69L11 7.34 16.66 13l5.66-5.66-5.66-5.65zm-2.83 5.65l2.83-2.83 2.83 2.83-2.83 2.83-2.83-2.83zM3 3v8h8V3H3zm6 6H5V5h4v4zM3 21h8v-8H3v8zm2-6h4v4H5v-4zm8-2v8h8v-8h-8zm6 6h-4v-4h4v4z" />
                        </svg>
                        <span class="side-menu__label">Gallery</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/faq">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M7 3h14v14H7z" opacity=".3" />
                           <path d="M3 23h16v-2H3V5H1v16c0 1.1.9 2 2 2zM21 1H7c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 16H7V3h14v14z" />
                        </svg>
                        <span class="side-menu__label">Faq</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/privacy">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M7 3h14v14H7z" opacity=".3" />
                           <path d="M3 23h16v-2H3V5H1v16c0 1.1.9 2 2 2zM21 1H7c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 16H7V3h14v14z" />
                        </svg>
                        <span class="side-menu__label">Privacy Policy</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/terms">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M7 3h14v14H7z" opacity=".3" />
                           <path d="M3 23h16v-2H3V5H1v16c0 1.1.9 2 2 2zM21 1H7c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 16H7V3h14v14z" />
                        </svg>
                        <span class="side-menu__label">Terms & Conditions</span>
                     </a>
                  </li>
                  <li class="slide">
                     <a class="side-menu__item" href="user/logout">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" class="side-menu__icon">
                           <path d="M0 0h24v24H0V0z" fill="none" />
                           <path d="M9.1 5L5 9.1v5.8L9.1 19h5.8l4.1-4.1V9.1L14.9 5H9.1zM12 17c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm1-3h-2V7h2v7z" opacity=".3" />
                           <path d="M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM19 14.9L14.9 19H9.1L5 14.9V9.1L9.1 5h5.8L19 9.1v5.8z" />
                           <circle cx="12" cy="16" r="1" />
                           <path d="M11 7h2v7h-2z" />
                        </svg>
                        <span class="side-menu__label">Logout</span>
                     </a>
                  </li>
               </ul>
            </aside>
            <!--/APP-SIDEBAR-->