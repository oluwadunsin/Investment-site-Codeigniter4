
		
		<!-- Start Switcher -->
		<div class="switcher-wrapper ">
			<div class="demo_changer">
				<div class="demo-icon bg_dark"><i class="fa fa-cog fa-spin  text_primary"></i></div>
				<div class="form_holder switcher-sidebar">
					<div class="row">
						<div class="predefined_styles">
							<div class="swichermainleft">
								<h4>Skin Modes</h4>
								<div class="switch_section">
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Default Mode</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch3" class="onoffswitch2-checkbox" checked>
											<label for="myonoffswitch3" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">White Mode</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch4" class="onoffswitch2-checkbox">
											<label for="myonoffswitch4" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Dark Mode</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch16" class="onoffswitch2-checkbox">
											<label for="myonoffswitch16" class="onoffswitch2-label"></label>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="swichermainleft">
								<h4>Header Styles Mode</h4>
								<div class="switch_section">
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Light Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch10" class="onoffswitch2-checkbox">
											<label for="myonoffswitch10" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Dark Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch13" class="onoffswitch2-checkbox">
											<label for="myonoffswitch13" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Color Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch11" class="onoffswitch2-checkbox">
											<label for="myonoffswitch11" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Graident Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch12" class="onoffswitch2-checkbox">
											<label for="myonoffswitch12" class="onoffswitch2-label"></label>
										</div>
									</div>
								</div>
							</div>
							<div class="swichermainleft">
								<h4>Horizontalmenu Styles Mode</h4>
								<div class="switch_section">
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Color Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch6" class="onoffswitch2-checkbox">
											<label for="myonoffswitch6" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Light Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch7" class="onoffswitch2-checkbox">
											<label for="myonoffswitch7" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Dark Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch8" class="onoffswitch2-checkbox">
											<label for="myonoffswitch8" class="onoffswitch2-label"></label>
										</div>
									</div>
									<div class="switch-toggle d-flex">
										<span class="mr-auto">Gradient-Color Menu</span>
										<div class="onoffswitch2"><input type="radio" name="onoffswitch2" id="myonoffswitch9" class="onoffswitch2-checkbox">
											<label for="myonoffswitch9" class="onoffswitch2-label"></label>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Switcher -->