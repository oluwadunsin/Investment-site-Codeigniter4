
		
		<!-- GLOBAL-LOADER -->
		<div id="global-loader">
			<img src="user/assets/images/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- /GLOBAL-LOADER -->
        <!-- PAGE -->
        <div class="page">
            <div class="page-main">