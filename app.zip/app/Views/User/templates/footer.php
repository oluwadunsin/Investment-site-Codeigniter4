			
	
					</div>
				</div>
				<!-- CONTAINER END -->
			</div>
			<!-- FOOTER -->
			<footer class="footer">
				<div class="container">
					<div class="row align-items-center flex-row-reverse">
						<div class="col-md-12 col-sm-12 text-center">
							Copyright &copy; {datez|date(Y)} <a href="#">{site_name|title}</a>. - Powered By <a href="#"> Omnix Technologies </a> All rights reserved.
						</div>
					</div>
				</div>
			</footer>
			</div><div style="height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px; width: 100%;position:fixed;bottom:0px"><div style="height:40px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=no" width="100%" height="36px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div><div style="display:inline;color: #FFFFFF; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;">
						<span class="text-center">
							Copyright &copy; {datez|date(Y)} <a href="#">{site_name|title}</a>. - Powered By <a href="#"> Omnix Technologies. </a> All rights reserved.
						</span><a href="https://coinlib.io" target="_blank" style="font-weight: 500; color: #FFFFFF; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>
			<!-- FOOTER END -->		
		</div>		
		<!-- BACK-TO-TOP -->
		<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

		<!-- JQUERY JS -->
		<script src="user/assets/js/jquery-3.4.1.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="user/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="user/assets/plugins/bootstrap/js/popper.min.js"></script>

		<!-- SPARKLINE JS-->
		<script src="user/assets/js/jquery.sparkline.min.js"></script>

		<!-- CHART-CIRCLE JS-->
		<script src="user/assets/js/circle-progress.min.js"></script>

		<!-- RATING STARJS -->
		<script src="user/assets/plugins/rating/jquery.rating-stars.js"></script>

		<!-- EVA-ICONS JS -->
		<script src="user/assets/iconfonts/eva.min.js"></script>
          
          <!-- INPUT MASK JS-->
          <script src="user/assets/plugins/input-mask/jquery.mask.min.js"></script>
          
          <!-- SIDE-MENU JS-->
          <script src="user/assets/plugins/sidemenu/sidemenu.js"></script>
          
          <!-- PERFECT SCROLL BAR js-->
          <script src="user/assets/plugins/p-scroll/perfect-scrollbar.min.js"></script>
          <script src="user/assets/plugins/sidemenu/sidemenu-scroll.js"></script>

		<!-- CUSTOM SCROLLBAR JS-->
		<script src="user/assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!-- STICKY JS -->
		<script src="user/assets/js/stiky.js"></script>

				<!-- INTERNAL  DATA TABLE JS-->
		<script src="user/assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="user/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="user/assets/plugins/datatable/datatable.js"></script>
		<script src="user/assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/jszip.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
		<script src="user/assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>

		<!-- INTERNAL  FILE UPLOADES JS -->
		<script src="user/assets/plugins/fileuploads/js/fileupload.js"></script>
		<script src="user/assets/plugins/fileuploads/js/file-upload.js"></script>

		<!-- INTERNAL SELECT2 JS -->
		<script src="user/assets/plugins/select2/select2.full.min.js"></script>

		<!--INTERNAL  INDEX JS -->
		<script src="user/assets/js/index1.js"></script>

        {if $page=='mail_compose'}
            <!-- INTERNAL   WYSIWYG Editor JS -->
    		<script src="user/assets/plugins/wysiwyag/jquery.richtext.js"></script>
    		<script src="user/assets/plugins/wysiwyag/wysiwyag.js"></script>
    		<script>
    		    document.addEventListener('input', updateValue);
                
                function updateValue(e) {
                  document.getElementById('mailbody').value = $('.richText-editor').html();
                }
            </script>
		{endif}
		
		<!-- SIDEBAR JS -->
		
		<script src="user/assets/plugins/sidebar/sidebar.js"></script>

        {if $page=='gallery'}
    		<!-- INTERNAL GALLERY JS -->
            <script src="user/assets/plugins/gallery/picturefill.js"></script>
            <script src="user/assets/plugins/gallery/lightgallery.js"></script>
            <script src="user/assets/plugins/gallery/lightgallery-1.js"></script>
            <script src="user/assets/plugins/gallery/lg-pager.js"></script>
            <script src="user/assets/plugins/gallery/lg-autoplay.js"></script>
            <script src="user/assets/plugins/gallery/lg-fullscreen.js"></script>
            <script src="user/assets/plugins/gallery/lg-zoom.js"></script>
            <script src="user/assets/plugins/gallery/lg-hash.js"></script>
            <script src="user/assets/plugins/gallery/lg-share.js"></script>
        {endif}
		
		<!-- CUSTOM JS -->
		<script src="user/assets/js/custom.js"></script>
		
		<!-- Switcher JS -->
		<script src="user/assets/switcher/js/switcher.js"></script>	
		
        <!--  BEGIN CUSTOM SCRIPTS FILE  -->
        <script src="user/assets/plugins/clipboard.min.js"></script>
        <script src="user/assets/plugins/custom-clipboard.js"></script>

        <!-- INTERNAL SWEET-ALERT JS -->
        <script src="user/assets/plugins/sweet-alert/sweetalert.min.js"></script>
        <script src="user/assets/js/sweet-alert.js"></script>
        
        {if $page=='dashboard'}
    		<!-- INTERNAL APEXCHART JS -->
    		<script src="user/assets/js/apexcharts.js"></script>
            <script>
                $(function(e) {
                	'use strict';
                
                	/*-----Chart-----*/
                	var options = {
                		chart: {
                			height: '210px',
                			type: 'bar',
                		},
                		plotOptions: {
                			bar: {
                				horizontal: true,
                				dataLabels: {
                				position: 'top',
                			},
                		}
                		},
                		dataLabels: {
                			enabled: true,
                			offsetX: -56,
                			style: {
                				fontSize: '12px',
                				colors: ['#fff']
                			}
                		},
                		series: [{
                			data: [{apex_data}]
                		}],
                		xaxis: {
                			categories: ['Wallet', 'Deposits', 'Withdrawals', 'Profit ', 'Invested','Referrals'],
                		},
                		fill: {
                          type: 'gradient',
                          gradient: {
                            shade: 'dark',
                            gradientToColors: ['#525ce5', '#765be6'],
                            shadeIntensity: 5,
                			inverseColors: true,
                            type: 'horizontal',
                            opacityFrom: .9,
                            opacityTo: .9,
                          },
                        },
                		grid: {
                			borderColor: 'rgba(112, 131, 171, .1)',
                			xaxis: {
                				lines: {
                					show: true,
                					borderColor: 'rgba(112, 131, 171, .1)',
                				}
                			},
                			yaxis: {
                				lines: {
                					show: false,
                				}
                			},
                			padding: {
                			  top: 0,
                			  right: 0,
                			  bottom: 0,
                			  left: 10
                			},
                		},
                	}
                	var chart = new ApexCharts(
                		document.querySelector("#learners"),
                		options
                	);
                	chart.render();
                	/*---- Chart8----*/
                
                });
            </script>
        {endif}
        
		<script>
		    jQuery(document).ready(function($) {
                $(".clickable-row").click(function() {
                    window.location = $(this).data("href");
                });
            });
		</script>
		
        {if $allow_deposit=="true"}
            {if $enable_paystack=="true"}
                <!-----Paystack--->
                <script src="https://js.paystack.co/v1/inline.js"></script>	 
                <script>
                    function payWithPaystack(){
                        $('#payModal').modal('hide');
                        let amount = document.getElementById("recipient-name").value * 100;
                        if(Number(amount) > 0){
                    	    var handler = PaystackPop.setup({
                    	      key: '{paystack_public}',
                    	      email: '{payEmail}',
                    	      amount: amount,
                    	      ref:'{payRef}',
                    	      metadata: {
                    	         custom_fields: [
                    	            {
                    	                site_ref: '{payRef}',
                    	                user_id: '{userID}',
                    	                amount: amount
                    	            }
                    	         ]
                    	      },
                    	      callback: function(response){
                    	      	  window.open('{base_url}/payment/paystack/'+response.reference+'/{userID}','_self');
                    	      },
                    	      onClose: function(){
                    	          alert('Transaction Cancelled');
                    	      }
                    	    });
                    	    handler.openIframe();
                        }else alert('Amount must be greater than 0');
            	    }
            	 </script>   
                <!-----/Paystack--->
            {endif}
            {if $enable_coinpayment=="true"}
                <!-----Coinpayment--->
                <script>
                    function payWithCoinpayments(){
                        $('#payModal').modal('hide');
                        let amount = document.getElementById("recipient-name").value;
                        if(Number(amount) > 0){
                            document.getElementById("damount").value = amount;
                            document.getElementById("durl").value = window.location.href;
                            document.getElementById("durl2").value = window.location.href;
                            document.getElementById("cpaymt").click();
                        }else alert('Amount must be greater than 0');
            	    }
            	 </script> 
                    <form action="https://www.coinpayments.net/index.php" method="post">
                        <input type="hidden" name="cmd" value="_pay_simple">
                        <input type="hidden" name="reset" value="1">
                        <input type="hidden" name="merchant" value="{coinpayments_merchant}">
                        <input type="hidden" name="currency" value="{site_currency|upper}">
                        <input type="hidden" name="amountf" id="damount" value="">
                        <input type="hidden" name="custom" value="{userID}">
                        <input type="hidden" name="item_name" value="Wallet Funding">    
                        <input type="hidden" name="item_desc" value="Wallet deposit using Cryptocurrency/Coinpayments"> 
                        <input type="hidden" name="invoice" value="{payRef}">
                        <input type="hidden" name="cancel_url" id="durl" value="">
                        <input type="hidden" name="success_url"  id="durl2" value="">
                        <input type="hidden" name="ipn_url" value="{base_url}/payment/coinpayment/{userID}">
                        <input type="image" id="cpaymt" src="https://www.coinpayments.net/images/pub/buynow-grey.png" alt="Buy Now with CoinPayments.net" style="display: none;">
                    </form>  
                <!-----/Coinpayment--->
            {endif}
            <!--payment modal-->
                <!-- MESSAGE MODAL -->
                <div class="modal" id="payModal" tabindex="-1" role="dialog"  aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="example-Modal3">Fund your wallet</h5>
                                            {if $infoPayment != null}
                                                {! infoPayment !}
                                            {endif}
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="form-group">
                                        <label for="recipient-name" class="form-control-label">Amount:</label>
                                        <input type="text" name="payAmount" class="form-control" id="recipient-name" placeholder="amount in {site_currency}" required>
                                    </div>
                                </form>
                                <div class="panel panel-primary">
                                    <div class="form-group">
                                        <label for="recipient-name" class="form-control-label">Payment method:</label>
                                    </div>
                                    <div class="tab-menu-heading">
                                        <div class="tabs-menu ">
                                            <!-- Tabs -->
                                            <ul class="nav panel-tabs">
                                                <li><a href="#tab0" class="active" data-toggle="tab">Select:</a></li>
                                                {if $enable_paystack=="true"}<li><a href="#tab1" data-toggle="tab">Paystack</a></li>{endif}
                                                {if $enable_coinpayment=="true"}<li><a href="#tab2" data-toggle="tab" class="">Coinpayments</a></li>{endif}
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-body tabs-menu-body">
                                        <div class="tab-content">
                                            <div class="tab-pane" id="tab0">
                                            </div>
                                            {if $enable_paystack=="true"}<div class="tab-pane" id="tab1">
                                                <p>{! paystack_description !}</p>
                                                <p><button type="button" onclick="payWithPaystack()" class="btn btn btn-success btn-block">Pay with Paystack</button></p>
                                            </div>{endif}
                                            {if $enable_coinpayment=="true"}<div class="tab-pane" id="tab2">
                                                <p>{! coinpayments_description !}</p>
                                                <p><button type="button" onclick="payWithCoinpayments()" class="btn btn btn-secondary btn-block">Pay with Coinpayments</button></p>
                                            </div>{endif}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- MESSAGE MODAL CLOSED -->
                <script>
                      if(window.location.hash) {
                        var hash = window.location.hash;
                        $(hash).modal('toggle');
                      }
                </script>
            <!-- MESSAGE MODAL -->
        {endif}
        
        <script>
            window.addEventListener('load',function(){
                let notifMessage = '{! site_notif_in !}';
                let siteName = '{site_name}'+'-In';
                let ssStorage = sessionStorage.getItem(siteName);
                if(notifMessage != "" && ssStorage == null){
                    swal({
                        title:'',
                        position: 'center',
                        type: 'warning',
                        text: notifMessage,
                        showClass: {
                            popup: 'animate__animated animate__fadeInDown'
                        },
                        hideClass: {
                            popup: 'animate__animated animate__fadeOutUp'
                        }
                    });
                    sessionStorage.setItem(siteName, true);
                }
            });
        </script>
		
        {! close_body_tag !}
	</body>
</html>