
						<div class="row">
							<div class="col-xl-3 col-sm-6">
								<div class="card">
									<div class="card-body">
										<div class="row mb-1">
											<div class="col">
												<p class="mb-1">Invested</p>
												<h3 class="mb-0 number-font">{invested}</h3>
											</div>
											<div class="col-auto mb-0">
												<div class="dash-icon text-orange">
													<i class="bx bxs-shopping-bags"></i>
												</div>
											</div>
										</div>
										<span class="fs-12 text-muted"> <strong>%</strong><i class="mdi mdi-arrow-up"></i> <span class="text-muted fs-12 ml-0 mt-1"></span>all time invested</span>
									</div>
								</div>
							</div>
							<div class="col-xl-3 col-sm-6">
								<div class="card">
									<div class="card-body">
										<div class="row mb-1">
											<div class="col">
												<p class="mb-1">Profit</p>
												<h3 class="mb-0 number-font">{profit}</h3>
											</div>
											<div class="col-auto mb-0">
												<div class="dash-icon text-secondary">
													<i class="bx bxs-badge-dollar"></i>
												</div>
											</div>
										</div>
										<span class="fs-12 text-muted"> <strong>%</strong><i class="mdi mdi-arrow-up"></i> <span class="text-muted fs-12 ml-0 mt-1"></span>all time profit</span>
									</div>
								</div>
							</div>
							<div class="col-xl-3 col-sm-6">
								<div class="card">
									<div class="card-body">
										<div class="row mb-1">
											<div class="col">
												<p class="mb-1">Referral</p>
												<h3 class="mb-0 number-font">{referral}</h3>
											</div>
											<div class="col-auto mb-0">
												<div class="dash-icon text-warning">
													<i class="bx bxs-credit-card-front"></i>
												</div>
											</div>
										</div>
										<span class="fs-12 text-muted"> <strong>%</strong><i class="mdi mdi-arrow-up"></i> <span class="text-muted fs-12 ml-0 mt-1">all time referrals</span></span>
									</div>
								</div>
							</div>
							<div class="col-xl-3 col-sm-6">
								<div class="card">
									<div class="card-body">
										<div class="row mb-1">
											<div class="col">
												<p class="mb-1">Wallet</p>
												<h3 class="mb-0 number-font">{wallet}</h3>
											</div>
											<div class="col-auto mb-0">
												<div class="dash-icon text-secondary1">
													<i class="bx bxs-wallet"></i>
												</div>
											</div>
										</div>
										<span class="fs-12 text-muted"> <strong>%</strong><i class="mdi mdi-arrow-up"></i> <span class="text-muted fs-12 ml-0 mt-1">current wallet balance</span></span>
									</div>
								</div>
							</div>
						</div>
						<!-- Row-1 End -->

						<!-- Row-2 -->
						<div class="row">
            				<div class="col-lg-8 col-md-12 col-sm-12 col-xl-8">
            					<div class="card overflow-hidden">
            						<div class="card-header">
            							<h3 class="card-title">Analysis</h3>
            						</div>
            						<div class="card-body" style="padding:0px;">
            							<div id="learners"></div>
            						</div>
            					</div>
            				</div>
							<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4">
								<div class="card" style="height:275px;">
									<div class="card-body">
										<div class="">
											<p class="mb-1">Your Current Wallet Balance</p>
											<h2 class="mb-1  number-font">{wallet}</h2>
										</div>
										<div class="mt-5">
											<p class="mb-1 d-flex">
												<span class=""><i class="fa fa-money text-muted mr-2 mt-1 fs-16"></i></span>
												<span class="fs-13 font-weight-normal text-muted mr-2">Received Amount </span> : <span class="ml-auto fs-14">+ {deposit}</span>
											</p>
											<p class="mb-1 d-flex">
												<span class=""><i class="fa fa-credit-card mr-2 mt-1 fs-16 text-muted"></i></span>
												<span class="fs-13 font-weight-normal text-muted mr-2">Sent Amount </span> : <span class="ml-auto fs-14">- {withdraw}</span>
											</p>
											<p class="d-flex">
												<span class=""><i class="fa fa-university mr-2 fs-16 text-muted"></i></span>
												<span class="fs-13 font-weight-normal text-muted mr-2">Total Amount </span> : <span class="ml-auto font-weight-bold fs-15">{expenses}</span>
											</p>
										</div>
										<div class="row mt-3">
											<div class="col-6">
												<a class="btn btn-primary btn-block btn-rounded" href="user/withdraw">Transfer</a>
											</div>
											<div class="col-6">
												<a class="btn btn-secondary btn-rounded btn-block" data-toggle="modal" data-target="#payModal">Receive</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- Row-2 End -->

            			<!-- ROW-3 OPEN -->
            			<div class="row">
            				<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <div class="card">
                                    <div class="card-header bg-transparent border-0">
                                        <h3 class="card-title">My Investments</h3>
                                    </div>
                                    <div class="">
                                        <div class="grid-margin">
                                            <div class="">
                                                <div class="table-responsive">
                                                    <table class="table card-table table-vcenter text-nowrap mb-0 table-primary align-items-center mb-0 text-center">
                                                        <thead class="bg-primary text-white">
                                                            <tr style="background: linear-gradient(to left, #2b5876 0%, #4e4376 100%);">
                                                                <th class="text-white">Purchased</th>
                                                                <th class="text-white">Plan</th>
                                                                <th class="text-white">-+-</th>
                                                                <th class="text-white">Start</th>
                                                                <th class="text-white">Invested</th>
                                                                <th class="text-white">Profit</th>
                                                                <th class="text-white">End</th>
                                                                <th class="text-white">Withdrawable</th>
                                                                <th class="text-white">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody style="color: #fff;background: linear-gradient(to right, #0f0c29, #302b63, #24243e);">
                                                            {investments}
                                                                <tr>
                                                                    <td>{time}</td>
                                                                    <td>{plan|title}</td>
                                                                    <td><a href="user/products/details/{plid}">
                                                                            <img alt="Image placeholder" class="rounded-circle" src="common/assets/images/products/{image}" width="32px" height="32px"></td>
                                                                        </a>
                                                                    <td>{time_started}</td>
                                                                    <td>{amount}</td>
                                                                    <td>{profit2}</td>
                                                                    <td>{time_ended}</td>
                                                                    <td>{withdrawable}</td>
                                                                    <td>{! status !}</td>
                                                                </tr>
                                                            {/investments}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
            				</div><!-- COL END -->
                        </div>
            			<!-- ROW-3 CLOSED -->

            			<!-- ROW-4 OPEN -->
            			<div class="row">
            				<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            					<div class="card">
            						<div class="card-header ">
            							<h3 class="card-title ">Latest Activities</h3>
            						</div>
            						<div class="card-body">
            							<div class="table-responsive mb-0">
            								<table class="table table-bordered text-nowrap mb-0 text-center table-striped">
            									<thead>
            										<tr>
            											<th>Time</th>
            											<th>Amount</th>
            											<th>Action</th>
            										</tr>
            									</thead>
            									<tbody>
            									    {table}
                										<tr>
                											<td>{time}</td>
                											<td>{amount}</td>
                											<td>{! action !}</td>
                										</tr>
            									    {/table}
            									</tbody>
            								</table>
            							</div>
            						</div>
            					</div>
            				</div><!-- COL END -->
    </div>
            			<!-- ROW-4 CLOSED -->