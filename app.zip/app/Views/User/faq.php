<!-- ROW-1 OPEN -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
                        {faq}
    						<div class="card-body">
    							<h4 class="font-weight-semibold">{question|capitalize}</h4>
    							<p>{answer}</p>
    						</div>
                        {/faq}
					</div>
				</div>
			</div>
			<!-- ROW-1 CLOSED -->