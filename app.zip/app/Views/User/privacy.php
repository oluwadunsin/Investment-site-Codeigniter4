<div class="row ">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h4><b>{privacy_heading|title}</b></h4>
                            <p>{! privacy_desc !}</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="terms">
                                <p>Was this information is Helpful?</p>
                                <a class="btn btn-primary text-white">Yes</a>
                                <a class="btn btn-secondary text-white">No</a>
                            </div>
                        </div>
                    </div>
                </div><!-- COL-END -->
            </div>
            <!-- ROW-1 CLOSE -->