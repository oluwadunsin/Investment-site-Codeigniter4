<!doctype html>
<html lang="en" dir="ltr">
<head>
    	<base href="{base_url}">
    	<!-- META DATA -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="{seo_description}">
		<meta name="author" content="Omnix Technologies">
		<meta name="keywords" content="{seo_keywords}">

		<!-- FAVICON -->
		<link rel="shortcut icon" type="image/x-icon" href="common/assets/images/x-icon/favicon.png" />

		<!-- TITLE -->
		<title>{page_title}</title>

		<!-- BOOTSTRAP CSS -->
		<link href="user/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

		<!-- STYLE CSS -->
		<link href="user/assets/css/style.css" rel="stylesheet" />
		<link href="user/assets/css/skin-modes.css" rel="stylesheet" />
		<link href="user/assets/css/dark-style.css" rel="stylesheet" />

		<!-- CUSTOM SCROLL BAR CSS-->
		<link href="user/assets/plugins/scroll-bar/jquery.mCustomScrollbar.css" rel="stylesheet" />

		<!--- FONT-ICONS CSS -->
		<link href="user/assets/css/icons.css" rel="stylesheet" />

				<!-- INTERNAL SINGLE-PAGE CSS -->
		<link href="user/assets/plugins/single-page/css/main.css" rel="stylesheet" type="text/css">
		<!-- COLOR SKIN CSS -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="user/assets/colors/color1.css" />
		
		<!-- INTERNAL TELEPHONE CSS-->
		<link rel="stylesheet" href="user/assets/plugins/telephoneinput/telephoneinput.css">
		
        <!--google captcha-->
        <script src='https://www.google.com/recaptcha/api.js' async defer></script>
        
	{! head_tag !}	
</head>

	<body class="app sidebar-mini" style="
    background: url(user/assets/images/auth/{page}.jpg); background-size: cover;">
	{! body_tag !}

	    <!-- BACKGROUND-IMAGE -->
		<div class="login-img">