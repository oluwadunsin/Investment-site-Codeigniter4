
		
		<!-- GLOBAL-LOADER -->
		<div id="global-loader">
			<img src="user/assets/images/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- /GLOBAL-LOADER -->

			<!-- PAGE -->
			<div class="page">
				<div class="">
				    <div class="col col-login mx-auto">
						<div class="text-center">
							<img src="common/assets/images/logo/logo.png" class="header-brand-img" alt="">
						</div>
					</div>
								<!-- CONTAINER OPEN -->
			<div class="container-login100">
				<div class="wrap-login100 p-6" style="background:#131632bf;">
					