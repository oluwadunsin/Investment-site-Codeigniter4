                </div>
			</div>
			<!-- CONTAINER CLOSED -->
				</div>
			</div>
			<!--END PAGE -->
		</div>
		<!-- BACKGROUND-IMAGE CLOSED -->

		<!-- JQUERY JS -->
		<script src="user/assets/js/jquery-3.4.1.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="user/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="user/assets/plugins/bootstrap/js/popper.min.js"></script>

		<!-- SPARKLINE JS-->
		<script src="user/assets/js/jquery.sparkline.min.js"></script>

		<!-- CHART-CIRCLE JS-->
		<script src="user/assets/js/circle-progress.min.js"></script>

		<!-- RATING STARJS -->
		<script src="user/assets/plugins/rating/jquery.rating-stars.js"></script>

		<!-- EVA-ICONS JS -->
		<script src="user/assets/iconfonts/eva.min.js"></script>
		
		<!--HORIZONTAL JS-->
		<script src="user/assets/plugins/horizontal-menu/horizontal-menu.js"></script>

		<!-- CUSTOM SCROLLBAR JS-->
		<script src="user/assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!-- INTERNAL TELEPHONE JS -->
		<script src="user/assets/plugins/telephoneinput/telephoneinput.js"></script>
		<script src="user/assets/plugins/telephoneinput/inttelephoneinput.js"></script>
		
		<!-- CUSTOM JS -->
		<script src="user/assets/js/custom.js"></script>
		
        {! close_body_tag !}
	</body>
</html>