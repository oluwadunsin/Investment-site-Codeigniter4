                        <form class="card" method="post" action"forgot">
							<div class="card-body p-6">
								<h3 class="text-center card-title">Forgot password</h3>
                                                {if $info != null}
                                                    {! info !}
                                                {endif}
                                <input type="hidden" name="{csrf_token}" value="{csrf_hash}" />
								<div class="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
									<input class="input100" type="email" name="email" placeholder="Email" required>
									<span class="focus-input100"></span>
									<span class="symbol-input100">
										<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
											<path d="M0 0h24v24H0V0z" fill="none" />
											<path d="M20 8l-8 5-8-5v10h16zm0-2H4l8 4.99z" opacity=".3" />
											<path d="M4 20h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2zM20 6l-8 4.99L4 6h16zM4 8l8 5 8-5v10H4V8z" /></svg>
									</span>
								</div>
        						<div class="wrap-input100 validate-input">
                                    {if $captcha_enabled == 1}
                                        <div class="form-group text-center">
                                            <div class="g-recaptcha" data-sitekey="{captcha_public_key}" style="display: inline-block;"></div>
                                        </div>
                                    {endif}
        						</div>
                                <div class="container-login100-form-btn">
                                    <button type="submit" class="login100-form-btn btn-primary">
                                        Forgot
                                    </button>
                                </div>
								<div class="text-center text-muted mt-3 ">
									Forget it, <a href="login">send me back</a> to the sign in screen.
								</div>
							</div>
						</form>