<style>
        #DataTables_Table_0_wrapper,#DataTables_Table_1_wrapper,#DataTables_Table_2_wrapper{
            width:fit-content !important;
            margin:20px;
        }
</style>
<!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Plans</h4>
                                                <div class="nk-block-des">
                                                    <p>See Plans here</p>
                                                </div>
                                            </div>
                                        </div>
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Plans</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Active</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Inactive</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem9">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist"  data-auto-responsive="false">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Image</th>
			                                                            <th class="nk-tb-col tb-col-sm">Minimum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Maximum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Percent</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period-Name</th>
			                                                            <th class="nk-tb-col tb-col-lg">Description</th>
			                                                            <th class="nk-tb-col tb-col-lg">Long Description</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 1</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 2</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 3</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 4</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 5</th>
			                                                            <th class="nk-tb-col tb-col-sm">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{all}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm"><div class="nk-reply-avatar user-avatar bg-blue"><img src="products/{image}" alt=""></div></td>
    			                                                            <td class="nk-tb-col tb-col-sm min-{id}">{minimum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm max-{id}">{maximum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pert-{id}">{percent}</td>
    			                                                            <td class="nk-tb-col tb-col-sm peri-{id}">{period}</td>
    			                                                            <td class="nk-tb-col tb-col-sm perina-{id}">{period_name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-lg des-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description}</td>
    			                                                            <td class="nk-tb-col tb-col-lg desl-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description_long}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft1-{id}">{feature1}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft2-{id}">{feature2}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft3-{id}">{feature3}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft4-{id}">{feature4}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft5-{id}">{feature5}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit Plan</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-alert tb-status text-warning"></em><span>Delete Image</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},3)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete Plan</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/all}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center" style="margin-top: 30px;">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer()">Add</button>
		                                                </div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Image</th>
			                                                            <th class="nk-tb-col tb-col-sm">Minimum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Maximum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Percent</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period-Name</th>
			                                                            <th class="nk-tb-col tb-col-lg">Description</th>
			                                                            <th class="nk-tb-col tb-col-lg">Long Description</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 1</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 2</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 3</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 4</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 5</th>
			                                                            <th class="nk-tb-col tb-col-sm">{! status !}</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{active}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm"><div class="nk-reply-avatar user-avatar bg-blue"><img src="products/{image}" alt=""></div></td>
    			                                                            <td class="nk-tb-col tb-col-sm min-{id}">{minimum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm max-{id}">{maximum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pert-{id}">{percent}</td>
    			                                                            <td class="nk-tb-col tb-col-sm peri-{id}">{period}</td>
    			                                                            <td class="nk-tb-col tb-col-sm perina-{id}">{period_name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-lg des-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description}</td>
    			                                                            <td class="nk-tb-col tb-col-lg desl-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description_long}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft1-{id}">{feature1}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft2-{id}">{feature2}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft3-{id}">{feature3}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft4-{id}">{feature4}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft5-{id}">{feature5}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit Plan</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-alert tb-status text-warning"></em><span>Delete Image</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},3)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete Plan</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/active}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Image</th>
			                                                            <th class="nk-tb-col tb-col-sm">Minimum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Maximum</th>
			                                                            <th class="nk-tb-col tb-col-sm">Percent</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period</th>
			                                                            <th class="nk-tb-col tb-col-sm">Period-Name</th>
			                                                            <th class="nk-tb-col tb-col-lg  text-break">Description</th>
			                                                            <th class="nk-tb-col tb-col-lg  text-break">Long Description</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 1</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 2</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 3</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 4</th>
			                                                            <th class="nk-tb-col tb-col-md">Feature 5</th>
			                                                            <th class="nk-tb-col tb-col-sm">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{inactive}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm"><div class="nk-reply-avatar user-avatar bg-blue"><img src="products/{image}" alt=""></div></td>
    			                                                            <td class="nk-tb-col tb-col-sm min-{id}">{minimum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm max-{id}">{maximum}{site_currency|upper}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pert-{id}">{percent}</td>
    			                                                            <td class="nk-tb-col tb-col-sm peri-{id}">{period}</td>
    			                                                            <td class="nk-tb-col tb-col-sm perina-{id}">{period_name|title}</td>
    			                                                            <td class="nk-tb-col tb-col-lg des-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description}</td>
    			                                                            <td class="nk-tb-col tb-col-lg desl-{id}" style="white-space: normal;word-wrap: break-word;word-break: normal;width:auto">{description_long}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft1-{id}">{feature1}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft2-{id}">{feature2}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft3-{id}">{feature3}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft4-{id}">{feature4}</td>
    			                                                            <td class="nk-tb-col tb-col-md ft5-{id}">{feature5}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit Plan</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-alert tb-status text-warning"></em><span>Delete Image</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},3)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete Plan</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/inactive}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
			    <!-- @@ Review Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="newsletter-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/newsletter/update" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title">Edit Subscriber</h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Status</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item1" class="form-select form-control form-control-lg select2-hidden-accessible" name="status" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="0">Inactive</option>
			                                                        <option value="1">Active</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Email</label>
			                                            <input type="text" id="item1b" name="email" class="form-control form-control-lg" placeholder="Enter email">
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary" value="Update" name="update-newsletter">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
                {noparse}<script>
                    function confirmer(did,act){
                        if(act==1){
                        		editor(did);
                        }
                        if(act==2){
                            if(confirm("Are You Sure You Want To Delete this Image?")) window.open("admin/plans/image/delete/"+did,"_self");
                        }
                        if(act==3){
                            if(confirm("Are You Sure You Want To Delete this Plan? \n All Users with this plan will have their record deleted. \n You are advised to disable it instead!"))window.open("admin/plans/delete/"+did,"_self");
                        }
                    }
                </script>{/noparse}

			    <!-- @@ Plan Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="plan-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/plan" class="form-validate"  enctype="multipart/form-data">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Name</label>
			                                            <input type="text" id="item1" name="name" class="form-control form-control-lg" placeholder="name" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Image</label>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Image</label>
                                                    	<input type="file" class="custom-file-input" id="customFile1" name="image" accept=".png,jpg,.gif">
                                                    	<label class="custom-file-label" for="customFile1">Choose file</label>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Minimum</label>
			                                            <input type="number" id="item2" name="minimum" class="form-control form-control-lg" placeholder="Enter minimum" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Maximum</label>
			                                            <input type="number" id="item3" name="maximum" class="form-control form-control-lg" placeholder="Enter maximum" value="">
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Percent</label>
			                                            <input type="text" id="item4" name="percent" class="form-control form-control-lg" placeholder="Enter percent" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Period</label>
			                                            <input type="text" id="item5" name="period" class="form-control form-control-lg" placeholder="Enter period" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name2">Period Name</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item13" class="form-select form-control form-control-lg select2-hidden-accessible" name="period_name" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="seconds">Seconds</option>
			                                                        <option value="minutes">Minutes</option>
			                                                        <option value="hour">Hour</option>
			                                                        <option value="day">Day</option>
			                                                        <option value="week">Week</option>
			                                                        <option value="month">Month</option>
			                                                        <option value="year">Year</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Short Description</label>
		                                                <textarea class="form-control form-control-sm" id="item6" name="description" placeholder="Write your description" required></textarea>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Long Description</label>
		                                                <textarea class="form-control form-control-sm" id="item7" name="description_long" placeholder="Write your description" required></textarea>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Feature 1</label>
			                                            <input type="text" name="feature1" class="form-control form-control-lg" id="item8" placeholder="Write your Feature 1" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Feature 2</label>
			                                            <input type="text" name="feature2" class="form-control form-control-lg" id="item9" placeholder="Write your Feature 2" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Feature 3</label>
			                                            <input type="text" name="feature3" class="form-control form-control-lg" id="item10" placeholder="Write your Feature 3" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Feature 4</label>
			                                            <input type="text" name="feature4" class="form-control form-control-lg" id="item11" placeholder="Write your Feature 4" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Feature 5</label>
			                                            <input type="text" name="feature5" class="form-control form-control-lg" id="item12" placeholder="Write your Feature 5" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name2">Status</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item14" class="form-select form-control form-control-lg select2-hidden-accessible" name="active" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="1">Active</option>
			                                                        <option value="0">Inactive</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="hidden" name="section" id="sectionz">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
			    
<script>
	function editor(did){
		document.querySelector('#plan-edit #rev-idz').value = did;
		
		$('#plan-edit').modal('show');
		document.querySelector('#plan-edit #item1').value = document.querySelector('.name-'+did).textContent;
		document.querySelector('#plan-edit #item2').value = document.querySelector('.min-'+did).textContent;
		document.querySelector('#plan-edit #item3').value = document.querySelector('.max-'+did).textContent;
		document.querySelector('#plan-edit #item4').value = document.querySelector('.pert-'+did).textContent;
		document.querySelector('#plan-edit #item5').value = document.querySelector('.peri-'+did).textContent;
		document.querySelector('#plan-edit #item6').value = document.querySelector('.des-'+did).textContent;
		document.querySelector('#plan-edit #item7').value = document.querySelector('.desl-'+did).textContent;
		document.querySelector('#plan-edit #item8').value = document.querySelector('.ft1-'+did).textContent;
		document.querySelector('#plan-edit #item9').value = document.querySelector('.ft2-'+did).textContent;
		document.querySelector('#plan-edit #item10').value = document.querySelector('.ft3-'+did).textContent;
		document.querySelector('#plan-edit #item11').value = document.querySelector('.ft4-'+did).textContent;
		document.querySelector('#plan-edit #item12').value = document.querySelector('.ft5-'+did).textContent;

		if(document.querySelector('.perina-'+did).textContent.includes("Minutes")) $('#item13').val('minutes').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Seconds")) $('#item13').val('seconds').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Hour")) $('#item13').val('hour').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Day")) $('#item13').val('day').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Week")) $('#item1').val('week').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Month")) $('#item13').val('month').change();
		else if(document.querySelector('.perina-'+did).textContent.includes("Year")) $('#item13').val('year').change();

		if(document.querySelector('.sta-'+did+' span').classList.contains('badge-danger')) $('#item14').val('0').change();
		else if(document.querySelector('.sta-'+did+' span').classList.contains('badge-success')) $('#item14').val('1').change();
		
		document.querySelector('#plan-edit #item2').value = Number(document.querySelector('.min-'+did).textContent.replace(/[^0-9.-]+/g,""));
		document.querySelector('#plan-edit #item3').value = Number(document.querySelector('.max-'+did).textContent.replace(/[^0-9.-]+/g,""));

		document.querySelector('#plan-edit #rev-title').textContent = 'Update Plan';
		document.querySelector('#plan-edit #submit').setAttribute('name','update-plan');
		document.querySelector('#plan-edit #sectionz').value = 'plan-edit';
		document.querySelector('#plan-edit #submit').value = 'Update';
	}

	function newer(did){
		$('#plan-edit').modal('show');
		
		document.querySelector('#plan-edit #item1').value = null;
		document.querySelector('#plan-edit #item2').value = null;
		document.querySelector('#plan-edit #item3').value = null;
		document.querySelector('#plan-edit #item4').value = null;
		document.querySelector('#plan-edit #item5').value = null;
		document.querySelector('#plan-edit #item6').value = null;
		document.querySelector('#plan-edit #item7').value = null;
		document.querySelector('#plan-edit #item8').value = null;
		document.querySelector('#plan-edit #item9').value = null;
		document.querySelector('#plan-edit #item10').value = null;
		document.querySelector('#plan-edit #item11').value = null;
		document.querySelector('#plan-edit #item12').value = null;

		document.querySelector('#plan-edit #rev-title').textContent = 'Make Plan';
		document.querySelector('#plan-edit #submit').setAttribute('name','set-new-plan');
		document.querySelector('#plan-edit #sectionz').value = 'plan-create';
		document.querySelector('#plan-edit #submit').value = 'Make';
	}
</script>