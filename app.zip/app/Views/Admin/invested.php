<style>
        #DataTables_Table_0_wrapper,#DataTables_Table_1_wrapper,#DataTables_Table_2_wrapper,#DataTables_Table_3_wrapper,#DataTables_Table_4_wrapper,#DataTables_Table_5_wrapper{
            width:fit-content !important;
            margin:20px;
        }
</style>
<!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Investments</h4>
                                                <div class="nk-block-des">
                                                    <p>Users Investments</p>
                                                </div>
                                            </div>
                                        </div>
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Investments</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Waiting</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Active</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">Paused</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem13">Completed</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem14">Cancelled</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content text-center">
                                                    <div class="tab-pane active" id="tabItem9">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist table-striped"  data-auto-responsive="false">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{all}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/all}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center" style="margin-top: 30px;">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer()">Add</button>
		                                                </div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{waiting}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/waiting}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{active}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/active}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem12">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{paused}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/paused}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem13">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{completed}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/completed}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem14">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init nowrap nk-tb-list nk-tb-ulist">
			                                                    <thead>
			                                                        <tr>
			                                                            <th class="nk-tb-col tb-col-sm">Name</th>
			                                                            <th class="nk-tb-col tb-col-sm">Plan</th>
			                                                            <th class="nk-tb-col tb-col-sm">Purchased</th>
			                                                            <th class="nk-tb-col tb-col-sm">Start</th>
			                                                            <th class="nk-tb-col tb-col-sm">End</th>
			                                                            <th class="nk-tb-col tb-col-sm">Invested</th>
			                                                            <th class="nk-tb-col tb-col-sm">Profit</th>
			                                                            <th class="nk-tb-col tb-col-sm text-center">Withdrawable</th>
			                                                            <th class="nk-tb-col tb-col-lg">Txn-id</th>
			                                                            <th class="nk-tb-col tb-col-md">Status</th>
			                                                            <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{cancelled}
				                                                        <tr>
    			                                                            <td class="nk-tb-col tb-col-sm name-{id}">{username|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pla-{id}">{plan|title}</td>
    			                                                            <td class="nk-tb-col tb-col-sm pur-{id}">{time}</td>
    			                                                            <td class="nk-tb-col tb-col-sm sta-{id}">{time_started}</td>
    			                                                            <td class="nk-tb-col tb-col-sm end-{id}">{time_ended}</td>
    			                                                            <td class="nk-tb-col tb-col-sm inv-{id}">{amount}</td>
    			                                                            <td class="nk-tb-col tb-col-md pro-{id}">{profit}</td>
    			                                                            <td class="nk-tb-col tb-col-md wit-{id} text-center">{withdraw}</td>
    			                                                            <td class="nk-tb-col tb-col-lg txn-{id}">{ref_id}</td>
    			                                                            <td class="nk-tb-col tb-col-md stat-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/cancelled}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                {noparse}<script>
                    function confirmer(did,act){
                        if(act==1){
                        		editor(did);
                        }
                        if(act==2){
                            if(confirm("Are You Sure You Want To Delete this Investment?")) window.open("admin/investments/delete/"+did,"_self");
                        }
                    }
                </script>{/noparse}

			    <!-- @@ Plan Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="plan-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/investments" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12" id="con1">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Name</label>
			                                            <input type="text" id="item1a" name="username" class="form-control form-control-lg" placeholder="name" readonly>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12" id="con2">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Name</label>
		                                                <select id="item1" class="form-select form-control form-control-lg select2-hidden-accessible" name="uid" tabindex="-1" aria-hidden="true">
		                                                        {users}
		                                                            <option value="{id}">{username|title}</option>
		                                                        {/users}
		                                                </select>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Plan</label>
		                                                <select id="item2" class="form-select form-control form-control-lg select2-hidden-accessible" name="plan" tabindex="-1" aria-hidden="true" required="">
		                                                        {plans}
		                                                            <option value="{id}">{name|title}</option>
		                                                        {/plans}
		                                                </select>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Start</label>
			                                            <div class="form-control-wrap focused">
			                                                <div class="form-icon form-icon-right">
			                                                    <em class="icon ni ni-calendar-alt"></em>
			                                                </div>
			                                                <input type="text" class="form-control form-control-xl form-control-outlined date-picker" id="outlined-date-picker" name="start">
			                                                <label class="form-label-outlined" for="outlined-date-picker">Date Picker</label></div>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">End</label>
			                                            <div class="form-control-wrap focused">
			                                                <div class="form-icon form-icon-right">
			                                                    <em class="icon ni ni-calendar-alt"></em>
			                                                </div>
			                                                <input type="text" class="form-control form-control-xl form-control-outlined date-picker" id="outlined-date-picker2" name="end">
			                                                <label class="form-label-outlined" for="outlined-date-picker">Date Picker</label></div>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Invested</label>
			                                            <input type="number" id="item4" name="invested" class="form-control form-control-lg" placeholder="Enter invested amount" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Profit</label>
			                                            <input type="number" id="item5" name="profit" class="form-control form-control-lg" placeholder="Enter profit" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Withdrawable</label>
			                                            <input type="number" id="item6" name="withdrawable" class="form-control form-control-lg" placeholder="Enter withdrawable" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name2">Status</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item13" class="form-select form-control form-control-lg select2-hidden-accessible" name="status" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="0">Waiting</option>
			                                                        <option value="1">Active</option>
			                                                        <option value="2">Paused</option>
			                                                        <option value="3">Completed</option>
			                                                        <option value="4">Cancelled</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="hidden" name="section" id="sectionz">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
			    
<script>
	function editor(did){
		document.querySelector('#plan-edit #rev-idz').value = did;
		document.querySelector('#plan-edit #con1').style.display = "initial";
		document.querySelector('#plan-edit #con2').style.display = "none";
		
		$('#plan-edit').modal('show');
		document.querySelector('#plan-edit #item1a').value = document.querySelector('.name-'+did).textContent;
		document.querySelector('#plan-edit #outlined-date-picker').value = document.querySelector('.sta-'+did).textContent;
		document.querySelector('#plan-edit #outlined-date-picker2').value = document.querySelector('.end-'+did).textContent;
		
        var initContent = document.querySelector('.pla-'+did).textContent;
		$('#item2 option:contains('+initContent+')').attr('selected', true).change();

		if(document.querySelector('.stat-'+did+' span').classList.contains('badge-outline-dark')) $('#item13').val('0').change();
		else if(document.querySelector('.stat-'+did+' span').classList.contains('badge-outline-success')) $('#item13').val('1').change();
		else if(document.querySelector('.stat-'+did+' span').classList.contains('badge-outline-warning')) $('#item13').val('2').change();
		else if(document.querySelector('.stat-'+did+' span').classList.contains('badge-outline-info')) $('#item13').val('3').change();
		else if(document.querySelector('.stat-'+did+' span').classList.contains('badge-outline-danger')) $('#item13').val('4').change();
		
		document.querySelector('#plan-edit #item4').value = Number(document.querySelector('.inv-'+did).textContent.replace(/[^0-9.-]+/g,""));
		document.querySelector('#plan-edit #item5').value = Number(document.querySelector('.pro-'+did).textContent.replace(/[^0-9.-]+/g,""));
		document.querySelector('#plan-edit #item6').value = Number(document.querySelector('.wit-'+did).textContent.replace(/[^0-9.-]+/g,""));

		document.querySelector('#plan-edit #rev-title').textContent = 'Update Investment';
		document.querySelector('#plan-edit #submit').setAttribute('name','update-Investment');
		document.querySelector('#plan-edit #sectionz').value = 'edit';
		document.querySelector('#plan-edit #submit').value = 'Update';
	}

	function newer(){
		document.querySelector('#plan-edit #con2').style.display = "initial";
		document.querySelector('#plan-edit #con1').style.display = "none";
		
		$('#plan-edit').modal('show');
		
		document.querySelector('#plan-edit #item1a').value = null;
		document.querySelector('#plan-edit #outlined-date-picker').value = null;
		document.querySelector('#plan-edit #outlined-date-picker2').value = null;
		document.querySelector('#plan-edit #item4').value = null;
		document.querySelector('#plan-edit #item5').value = null;
		document.querySelector('#plan-edit #item6').value = null;
		document.querySelector('#plan-edit #rev-title').textContent = 'Make Investment';
		document.querySelector('#plan-edit #submit').setAttribute('name','set-new-investment');
		document.querySelector('#plan-edit #sectionz').value = 'create';
		document.querySelector('#plan-edit #submit').value = 'Make';
	}
</script>