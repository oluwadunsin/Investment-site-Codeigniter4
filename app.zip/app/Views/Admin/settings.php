
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Settings</h4>
                                                <div class="nk-block-des">
                                                    <p>Edit your core settings from here</p>
                                                </div>
                                            </div>
                                        </div>
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Logo & Favicon</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Site</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">SEO</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">Contacts</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem13">Email</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem14">Captcha</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem15">Scripts</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem16">Announcement</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem17">Authentication</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem18">Rates</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem19">Payment Gateways</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem20">Withdrawals</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem9">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter" enctype="multipart/form-data">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Logo</label>
		                                                                <span class="form-note">Specify the logo of your website in PNG format.</span>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
			                                                                	<input type="file" class="custom-file-input" id="customFile1" name="logo" accept=".png">
			                                                                	<label class="custom-file-label" for="customFile1">Choose file</label>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap text-center">
		                                                                	<img src="common/assets/images/logo/logo.png" alt="" style="width: 400px;height:75px; border:2px solid #000">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Favicon</label>
		                                                                <span class="form-note">Specify the favicon of your website in PNG format.</span>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
			                                                                	<input type="file" class="custom-file-input" id="customFile2" name="favicon"  accept=".png">
			                                                                	<label class="custom-file-label" for="customFile2">Choose file</label>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap text-center">
		                                                                	<img src="common/assets/images/x-icon/favicon.png" alt="" style="width: 100px;height:100px; border:2px solid #000">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="logo">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-logo">Upload</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Site Prefix</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="site_prefix" value="{site_prefix}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Site Name</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="site_name" value="{site_name}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Site Currency</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="site_currency" value="{site_currency}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Site Description</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="site_description" placeholder="Write your description" required>{site_description}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Time Zone</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="time_zone" value="{time_zone}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="core">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-name">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Site Keywords</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="seo_keywords" placeholder="Write your keywords" required>{seo_keywords}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Site Description</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="seo_description" placeholder="Write your description" required>{seo_description}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="seo">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-seo">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem12">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Contact page heading</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="contact_heading" value="{contact_heading}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Contact page sub-heading</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="contact_sub_heading" value="{contact_sub_heading}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Newsletter page heading</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="newsletter_heading" value="{newsletter_heading}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Newsletter page sub heading A</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="nsub_heading_1" value="{nsub_heading_1}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Newsletter page sub heading B</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="nsub_heading_2" value="{nsub_heading_2}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Newsletter page sub heading C</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="nsub_heading_3" value="{nsub_heading_3}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Week begins</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="week_begin" value="{week_begin}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Week ends</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="week_end" value="{week_end}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Time work begins</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="time_begin" value="{time_begin}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Time work ends</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="time_end" value="{time_end}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label" for="site-name">Email</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="email" value="{email}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Phone</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="phone" value="{phone}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Address</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="address" placeholder="Write your address">{address}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Map</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="map" placeholder="Write your address">{map}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Facebook</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="facebook" value="{facebook}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Instagram</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="instagram" value="{instagram}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Twitter</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="twitter" value="{twitter}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Whatsapp</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="whatsapp" value="{whatsapp}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Linkedin</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="linkedin" value="{linkedin}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Google</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="google" value="{google}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Youtube</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="youtube" value="{youtube}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Telegram</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="telegram" value="{telegram}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="contact">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-contact">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem13">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Send Mail</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="email" class="form-control" name="from_email" value="{from_email}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Send Name</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="from_sender" value="{from_sender}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Reply Mail</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="email" class="form-control" name="reply_email" value="{reply_email}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Reply Name</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="reply_to" value="{reply_to}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP host</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_host" value="{smtp_host}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP username</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_username" value="{smtp_username}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP password</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_password" value="{smtp_password}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP port</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_port" value="{smtp_port}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP timeout</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_timeout" value="{smtp_timeout}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP keep alive</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="smtp_keepAlive" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="smtp_keepAlive" id="custom-switch1" {if $smtp_keepAlive=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch1">{if $smtp_keepAlive=="true"}True{else}False{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">SMTP encryption</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="smtp_encryption" value="{smtp_encryption}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="smtp">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-mail">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem14">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Enable Captcha</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="captcha_enabled" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="captcha_enabled" id="custom-switch2" {if $captcha_enabled=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch2">{if $captcha_enabled=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Captcha Public Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="captcha_public_key" value="{captcha_public_key}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Captcha Private Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="captcha_private_key" value="{captcha_private_key}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="captcha">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-captcha">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem15">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Scripts Before Closing Head Tag</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="head_tag" placeholder="Paste your script">{head_tag}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Scripts After Starting Body Tag</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="body_tag" placeholder="Paste your script">{body_tag}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Scripts Before Closing Body Tag</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="close_body_tag" placeholder="Paste your script">{close_body_tag}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
			                                                            <input type="hidden" name="section" value="scripts">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-script">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem16">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Announcement To Logged In Users</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="site_notif_in" placeholder="Paste your announcement">{site_notif_in}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Announcement To General Public</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="site_notif_out" placeholder="Paste your announcement">{site_notif_out}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <hr/>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Enable Jumbotron?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="enable_jumbotron" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="enable_jumbotron" id="custom-switch22" {if $enable_jumbotron=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch22">{if $enable_jumbotron=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Image</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_img" value="{jumbotron_img}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Heading</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_heading" value="{jumbotron_heading}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Body 1</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="jumbotron_body_1" placeholder="Paste your text" required>{jumbotron_body_1}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Body 2</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="jumbotron_body_2" placeholder="Paste your text" required>{jumbotron_body_2}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Sub-Heading 1</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_sub-heading1" value="{jumbotron_sub-heading1}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Sub-Heading 2</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_sub-heading2" value="{jumbotron_sub-heading2}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Button 1</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_btn1" value="{jumbotron_btn1}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Button Link 1</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_btn1-link" value="{jumbotron_btn1-link}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Button 2</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_btn2" value="{jumbotron_btn2}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">User Pages Jumbotron Button Link 2</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="jumbotron_btn2-link" value="{jumbotron_btn2-link}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
		                                                                <input type="hidden" name="section" value="announcement">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-announce">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem17">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Allow Registration?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="allow_signup" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="allow_signup" id="custom-switch3" {if $allow_signup=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch3">{if $allow_signup=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Allow Login?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="allow_login" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="allow_login" id="custom-switch4" {if $allow_login=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch4">{if $allow_login=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Allow Auto Verification?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="auto_activate" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="auto_activate" id="custom-switch5" {if $auto_activate=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch5">{if $auto_activate=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Activate KYC?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="is_kyc" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="is_kyc" id="custom-switch5" {if $is_kyc=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch5">{if $is_kyc=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
		                                                                <input type="hidden" name="section" value="authentication">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-captcha">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem18">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Referral Rate({site_currency})</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="referral_rate" value="{referral_rate}" required>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Referral Plan</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
                			                                            <div class="form-control-wrap">
                			                                                <select id="item1" class="form-select form-control form-control-lg select2-hidden-accessible" name="referral_plan" tabindex="-1" aria-hidden="true" required="">
                			                                                        {plans}
                			                                                            <option value="{id}">{name|title}</option>
                			                                                        {/plans}
                			                                                </select>
                			                                            </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
		                                                                <input type="hidden" name="section" value="rates">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-rates">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem19">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Allow Payment Deposit?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="allow_deposit" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="allow_deposit" id="custom-switch6" {if $allow_deposit=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch6">{if $allow_deposit=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Paystack Public Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="paystack_public" value="{paystack_public}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Paystack Private Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="paystack_secret" value="{paystack_secret}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Paystack Description</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="paystack_description" placeholder="Write your paystack description">{paystack_description}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Enable Paystack?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="enable_paystack" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="enable_paystack" id="custom-switch7" {if $enable_paystack=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch7">{if $enable_paystack=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Coinpayments Merchant Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="coinpayments_merchant" value="{coinpayments_merchant}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Coinpayments IPN Key</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                    <input type="text" class="form-control" name="coinpayments_ipn" value="{coinpayments_ipn}">
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Coinpayments Description</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                                <div class="form-control-wrap">
		                                                                	<textarea class="form-control form-control-sm" name="coinpayments_description" placeholder="Write your coinpayments description">{coinpayments_description}</textarea>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Enable Coinpayments?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="enable_coinpayment" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="enable_coinpayment" id="custom-switch8" {if $enable_coinpayment=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch8">{if $enable_coinpayment=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
		                                                                <input type="hidden" name="section" value="payment">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-cpay">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem20">
		                                                <form action="admin/settings" method="post" class="gy-3 form-validate is-alter">
		                                                    <div class="row g-3 align-center">
		                                                        <div class="col-lg-5">
		                                                            <div class="form-group">
		                                                                <label class="form-label">Allow Withdrawals?</label>
		                                                            </div>
		                                                        </div>
		                                                        <div class="col-lg-7">
		                                                            <div class="form-group">
		                                                            	<div class="custom-control custom-switch">
		                                                            		<input type="hidden" name="allow_withdrawal" value="false" />
                                                                    		<input type="checkbox" value="true" class="custom-control-input" name="allow_withdrawal" id="custom-switch7" {if $allow_withdrawal=="true"}checked{endif}>
                                                                    		<label class="custom-control-label" for="custom-switch7">{if $allow_withdrawal=="true"}Enabled{else}Disabled{endif}</label>
                                                                		</div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                    <div class="row g-3">
		                                                        <div class="col-lg-7 offset-lg-5">
		                                                            <div class="form-group mt-2">
		                                                                <input type="hidden" name="section" value="withdrawal">
		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-withdraw">Update</button>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </form>
                                                    	<hr/>
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>Method</th>
			                                                            <th>Currency</th>
			                                                            <th>Charge</th>
			                                                            <th>Minimum</th>
			                                                            <th>Maximum</th>
			                                                            <th>Delay</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
                                                                    {withdraw_method}
				                                                        <tr>
				                                                            <td id="meth-{id}">{method|capitalize}</td>
				                                                            <td id="curr-{id}">{currency|lower}</td>
				                                                            <td id="char-{id}">{charge}</td>
				                                                            <td id="min-{id}">{minimum}</td>
				                                                            <td id="max-{id}">{maximum}</td>
				                                                            <td id="del-{id}">{delay}</td>
				                                                            <td id="stat-{id}">{! istatus !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/settings/deposits/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
                                                                    {/withdraw_method}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer()" style="margin-top: 30px;">Add</button>
		                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
			    <!-- @@ payment method Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="pmethod-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/settings" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Method</label>
			                                            <input type="text" id="item1" name="method" class="form-control form-control-lg" placeholder="Enter method" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Currency</label>
			                                            <input type="text" id="item2" name="currency" class="form-control form-control-lg" placeholder="Enter currency" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Charge</label>
			                                            <input type="text" name="charge" class="form-control form-control-lg" id="item3" placeholder="Write your processing charge" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Minimum</label>
			                                            <input type="text" name="minimum" class="form-control form-control-lg" id="item4" placeholder="Enter minimum amount" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Maximum</label>
			                                            <input type="text" name="maximum" class="form-control form-control-lg" id="item5" placeholder="Enter maximmum amount" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Delay</label>
			                                            <input type="text" id="item6" name="delay" class="form-control form-control-lg" placeholder="Enter processing time" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name" style="margin-right: 10px;">Status</label>
                                                    	<div class="custom-control custom-switch">
                                                    		<input type="hidden" name="status" value="0" />
                                                    		<input type="checkbox" value="1" class="custom-control-input" name="status" id="custom-switch9">
                                                    		<label class="custom-control-label" for="custom-switch9"></label>
                                                		</div>
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="sectionz" name="section">
			                                                <input type="hidden" id="idz" name="id">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
<script>
	function editor(did){
		$('#pmethod-edit').modal('show');
		document.querySelector('#pmethod-edit #item1').value = document.querySelector('#meth-'+did).textContent;
		document.querySelector('#pmethod-edit #item2').value = document.querySelector('#curr-'+did).textContent;
		document.querySelector('#pmethod-edit #item3').value = document.querySelector('#char-'+did).textContent;
		document.querySelector('#pmethod-edit #item4').value = document.querySelector('#min-'+did).textContent;
		document.querySelector('#pmethod-edit #item5').value = document.querySelector('#max-'+did).textContent;
		document.querySelector('#pmethod-edit #item6').value = document.querySelector('#del-'+did).textContent;
		if(document.querySelector('#stat-'+did+' span').classList.contains('badge-success')) document.querySelector('#pmethod-edit #custom-switch9').setAttribute('checked','true');
		else document.querySelector('#pmethod-edit #custom-switch9').removeAttribute('checked');
		document.querySelector('#pmethod-edit #rev-title').textContent = 'Update Payment Method';
		document.querySelector('#pmethod-edit #submit').setAttribute('name','update-pmethod');
		document.querySelector('#pmethod-edit #submit').value = 'Update';
		document.querySelector('#pmethod-edit #sectionz').value = 'method-edit';
		document.querySelector('#pmethod-edit #idz').value = did;
	}

	function newer(did){
		$('#pmethod-edit').modal('show');
		document.querySelector('#pmethod-edit #item1').value = null;
		document.querySelector('#pmethod-edit #item2').value = null;
		document.querySelector('#pmethod-edit #item3').value = null;
		document.querySelector('#pmethod-edit #item4').value = null;
		document.querySelector('#pmethod-edit #item5').value = null;
		document.querySelector('#pmethod-edit #item6').value = null;
		//document.querySelector('#pmethod-edit #custom-switch9').removeAttribute('checked');

		document.querySelector('#pmethod-edit #rev-title').textContent = 'Create Method';
		document.querySelector('#pmethod-edit #submit').setAttribute('name','set-new-pmethod');
		document.querySelector('#pmethod-edit #submit').value = 'Create';
		document.querySelector('#pmethod-edit #sectionz').value = 'method-create';
	}
</script>