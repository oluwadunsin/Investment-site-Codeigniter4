
	<style>
	    .tab-pane img{
			border: 2px solid black;
		}
    </style>
<!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Pages</h4>
                                                <div class="nk-block-des">
                                                    <p>Edit your front pages from here</p>
                                                </div>
                                            </div>
                                        </div>
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem14">Home</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem9">About</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem15">Services</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem16">History</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Media</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Faq</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">Terms & Conditions</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem13">Privacy Policy</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem17">Covid</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem18">Affiliate</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem19">Testimonials</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem14">Contact</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem8">
                                                        {home}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter"  enctype="multipart/form-data">
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Page Title</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Slider 1</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile7" name="slider1">
    			                                                                	<label class="custom-file-label" for="customFile7"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/1.jpg" alt="" style="width: 960px;height:135px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">People 1</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile8" name="people1">
    			                                                                	<label class="custom-file-label" for="customFile8"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/people1.png" alt="" style="width: 570px;height:550px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Slider 2</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile7" name="slider2">
    			                                                                	<label class="custom-file-label" for="customFile7"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/2.jpg" alt="" style="width: 960px;height:135px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">People 2</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile8" name="people2">
    			                                                                	<label class="custom-file-label" for="customFile8"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/people2.png" alt="" style="width: 570px;height:550px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Slider 3</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile7" name="slider3">
    			                                                                	<label class="custom-file-label" for="customFile7"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/3.jpg" alt="" style="width: 960px;height:135px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">People 3</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile8" name="people3">
    			                                                                	<label class="custom-file-label" for="customFile8"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Slider/home3/people3.png" alt="" style="width: 570px;height:550px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Home About Image</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile9" name="home_about">
    			                                                                	<label class="custom-file-label" for="customFile9"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Content/home-about.png" alt="" style="width: 571px;height:680px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">About Description Image 1</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile9" name="about_description1">
    			                                                                	<label class="custom-file-label" for="customFile9"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/bg-content/home_about_description1.jpg" alt="" style="width: 973px;height:397px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">About Description Image 2</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile9" name="about_description2">
    			                                                                	<label class="custom-file-label" for="customFile9"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/bg-content/home_about_description2.jpg" alt="" style="width: 956px;height:638px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <hr/>
		                                                {/home}
		                                                {home}
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 1</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic1" value="{topic1}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 1 A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic1a" value="{topic1a}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        		                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label">Topic 1 B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic1b" value="{topic1b}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        		                                                    </div>
        		                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label">Topic 1 C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic1c" value="{topic1c}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        		                                                    </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 2</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic2" value="{topic2}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 2 A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic2a" value="{topic2a}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 2 B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic2b" value="{topic2b}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 2 C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic2c" value="{topic2c}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 3</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic3" value="{topic3}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 3 A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic3a" value="{topic3a}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 3 B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic3b" value="{topic3b}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Topic 3 C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topic3c" value="{topic3c}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 2A</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section2a">
        		                                                                {section2a}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2aB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2aC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section2aA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section2a}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 2B</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section2b">
        		                                                                {section2b}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2bB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2bC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section2bA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section2b}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 2C</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section2c">
        		                                                                {section2c}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2cB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section2cC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section2cA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section2c}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
                                                        {home}
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section3_topic" value="{section3_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Sub-Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section3_sub_topic" value="{section3_sub_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="section3_body" placeholder="Write your description" required>{section3_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 1 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section3_point1_topic" value="{section3_point1_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 1 Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="section3_point1_body" placeholder="Write your description" required>{section3_point1_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 2 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section3_point2_topic" value="{section3_point2_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 2 Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="section3_point2_body" placeholder="Write your description" required>{section3_point2_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 3 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section3_point3_topic" value="{section3_point3_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 3 Point 3 Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="section3_point3_body" placeholder="Write your description" required>{section3_point3_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Video Title</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="about_video_title" value="{about_video_title}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Video Link</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="about_video_link" value="{about_video_link}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>About Reasons</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Counter</label>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="about_points">
        		                                                                {about_points}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="about_pointsC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="about_pointsB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="about_pointsA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/about_points}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 4 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section4_topic" value="{section4_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section4 Sub-Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section4_sub_topic" value="{section4_sub_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 4A</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section4a">
        		                                                                {section4a}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4aB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4aC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section4aA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section4a}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 4B</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section4b">
        		                                                                {section4b}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4bB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4bC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section4bA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section4b}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Section 4C</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://linearicons.com/free)</i></label>
            		                                                            </div>{/noparse}
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="section4c">
        		                                                                {section4c}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4cB" value="{b}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="section4cC" value="{c}" required>
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="section4cA" value="{a}" required>
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/section4c}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/home}
		                                                {home}
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 5 Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section5_topic" value="{section5_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 5 Sub-Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section5_sub_topic" value="{section5_sub_topic}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 6 A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section6a" value="{section6a}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 6 A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section6a" value="{section6a}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 6 B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section6b" value="{section6b}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Section 6 Button</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="section6_btn" value="{section6_btn}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <hr/>
		                                                {/home}
                                                        {home}
    		                                                        <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="home">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-about">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/home}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem9">
                                                        {about}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter"  enctype="multipart/form-data">
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Page Title</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Banner Image</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile7" name="bannerImg">
    			                                                                	<label class="custom-file-label" for="customFile7"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/bg-content/about_slider.jpg" alt="" style="width: 960px;height:135px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">Description Image</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile8" name="descriptionImg">
    			                                                                	<label class="custom-file-label" for="customFile8"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/Content/about_description.jpg" alt="" style="width: 570px;height:550px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <label class="form-label" for="site-name">About Why Image</label>
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<input type="file" class="custom-file-input" id="customFile9" name="whyImg">
    			                                                                	<label class="custom-file-label" for="customFile9"  accept=".png,jpg">Choose file</label>
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <div class="row g-3 align-center">
    			                                                        <div class="col-lg-5">
    			                                                            <div class="form-group">
    			                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    			                                                            </div>
    			                                                        </div>
    			                                                        <div class="col-lg-7">
    			                                                            <div class="form-group">
    			                                                                <div class="form-control-wrap">
    			                                                                	<img src="common/assets/images/bg-content/about_why.jpg" alt="" style="width: 960px;height:135px;">
    			                                                                </div>
    			                                                            </div>
    			                                                        </div>
    			                                                    </div>
    			                                                    <hr/>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">About Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="about_heading" value="{about_heading}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">About Sub-Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="about_sub-heading" value="{about_sub-heading}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        		                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label">Head A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topica" value="{topica}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        		                                                    </div>
        		                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label">Head B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topicb" value="{topicb}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        		                                                    </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Head C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topicc" value="{topicc}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Head D</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="topicd" value="{topicd}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
		                                                {/about}
                                                        {about}
    			                                                    <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="body" placeholder="Write your description" required>{body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="sub_topica" value="{sub_topica}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic A Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="sub_topica_body" placeholder="Write your description" required>{sub_topica_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="sub_topicb" value="{sub_topicb}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic B Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="sub_topicb_body" placeholder="Write your description" required>{sub_topicb_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="sub_topicc" value="{sub_topicc}" required>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Sub-Topic C Body</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                	<textarea class="form-control form-control-sm" name="sub_topicc_body" placeholder="Write your description" required>{sub_topicc_body}</textarea>
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/about}
		                                                {about}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Stats</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            {noparse}<div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Icon<br><i>(https://bootsnipp.com/iconsearch?library=icomoon)</i></label>
            		                                                            </div>{/noparse}
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Count</label>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="stats">
        		                                                                {stats}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="statsA" value="{a}" >
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="statsC" value="{c}" >
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="statsB" value="{b}" >
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/stats}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/about}
		                                                {about}
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Point A</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="pointa" value="{pointa}" >
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Point B</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="pointb" value="{pointb}" >
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Point C</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="pointc" value="{pointc}" >
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Why Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="why_topic" value="{why_topic}" >
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
        			                                                <div class="row g-3 align-center">
        		                                                        <div class="col-lg-5">
        		                                                            <div class="form-group">
        		                                                                <label class="form-label" for="site-name">Why Sub-Heading</label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-7">
        		                                                            <div class="form-group">
        		                                                                <div class="form-control-wrap">
        		                                                                    <input type="text" class="form-control" name="why_sub_topic" value="{why_sub_topic}" >
        		                                                                </div>
        		                                                            </div>
        		                                                        </div>
        			                                                </div>
    			                                                    <hr/>
		                                                {/about}
		                                                {about}
        				                                            <div class="row g-3 align-center">
        		                                                        <div class="col-lg-12">
        		                                                            <div class="form-group text-center">
        		                                                                <label class="form-label" for="site-name"><u>Stats</u></label>
        		                                                            </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12">
            		                                                        <div class="row">
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Point</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                                <label class="form-label" for="site-name">Description</label>
            		                                                            </div>
            		                                                            <div class="form-group text-center col-lg-4">
            		                                                            {noparse}<label class="form-label" for="site-name">Icon<br><i>(https://bootsnipp.com/iconsearch?library=icomoon)</i></label>{/noparse}
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        		                                                        <div class="col-lg-12 repeater">
        		                                                            <div data-repeater-list="why">
        		                                                                {why}
            		                                                            <div class="row" data-repeater-item>
                		                                                            <div class="form-group col-lg-4" >
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="whyB" value="{b}" >
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="form-control-wrap">
                		                                                                    <input type="text" class="form-control" name="whyC" value="{c}" >
                		                                                                </div>
                		                                                            </div>
                		                                                            <div class="form-group col-lg-4">
                		                                                                <div class="row">
                    		                                                                <div class="form-control-wrap col-lg-8">
                    		                                                                    <input type="text" class="form-control" name="whyA" value="{a}" >
                    		                                                                </div>
                    		                                                                <div class="form-control-wrap col-lg-2">
                		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                    		                                                                </div>
                		                                                                </div>
                		                                                            </div>
            		                                                            </div>
            		                                                            {/why}
        		                                                            </div>
            		                                                        <div class="col-lg-7 offset-lg-5">
            		                                                            <div class="form-group mt-2">
            		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
            		                                                            </div>
            		                                                        </div>
        		                                                        </div>
        			                                                </div>
        			                                                <hr/>
		                                                {/about}
                                                        {about}
    		                                                        <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="about">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-about">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/about}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                        {media}
                                                            <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Media Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="media_heading" value="{media_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Media Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="media_sub_heading" value="{media_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile1" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile2"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/media_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="media">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/media}
                                                    	<hr/>
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>Image</th>
			                                                            <th>Name</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{gallery}
				                                                        <tr>
				                                                            <td id="qname-{id}">{name|capitalize}</td>
				                                                            <td id="img-{id}"><div class="nk-reply-avatar user-avatar bg-blue"><img src="common/assets/images/gallery/{img}" alt=""></div></td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/pages/gallery/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/gallery}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center" style="margin-top: 30px;">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer()">Add</button>
		                                                </div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                        {faq}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Faq Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="faq_heading" value="{faq_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Faq Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="faq_sub_heading" value="{faq_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile4" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile4"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/faq_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="faq">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/faq}
                                                    	<hr/>
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>Question</th>
			                                                            <th>Answer</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{zfaq}
				                                                        <tr>
				                                                            <td id="ques-{id}">{question}</td>
				                                                            <td id="ans-{id}">{answer}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor2('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/pages/faq/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/zfaq}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center" style="margin-top: 30px;">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer2()">Add</button>
		                                                </div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem12">
                                                        {terms}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Terms Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="terms_heading" value="{terms_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Terms Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="terms_sub_heading" value="{terms_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile3" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile3"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/terms_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Content Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile3" name="bannerImg2">
    		                                                                	<label class="custom-file-label" for="customFile3"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/News/legal_banner.jpg" alt="" style="width: 585px;height:142px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Terms Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="terms_title" value="{terms_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label">Terms</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<textarea class="form-control form-control-sm" name="terms_desc" placeholder="Write your terms" required>{terms_desc}</textarea>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="terms">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/terms}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem13">
                                                        {privacy}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Privacy Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="privacy_heading" value="{privacy_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Privacy Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="privacy_sub_heading" value="{privacy_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile1" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile2"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/privacy_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Privacy Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="privacy_title" value="{privacy_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label">Terms</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<textarea class="form-control form-control-sm" name="privacy_desc" placeholder="Write your privacy policy" required>{privacy_desc}</textarea>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="privacy">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/privacy}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem14">
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile1" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile1"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/contact_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="contact">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem15">
                                                        {services}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Services Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="investment_heading" value="{investment_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Services Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="investment_sub-heading" value="{investment_sub-heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile1" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile2"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/investment_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-12">
    		                                                            <div class="form-group text-center">
    		                                                                <label class="form-label" for="site-name"><u>Services</u></label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-12">
        		                                                        <div class="row">
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Title</label>
        		                                                            </div>
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Description</label>
        		                                                            </div>
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Image Link</label>
        		                                                            </div>
        		                                                        </div>
    		                                                        </div>
    		                                                        <div class="col-lg-12 repeater">
    		                                                            <div data-repeater-list="packages">
    		                                                                {packages}
        		                                                            <div class="row" data-repeater-item>
            		                                                            <div class="form-group col-lg-4" >
            		                                                                <div class="form-control-wrap">
            		                                                                    <input type="text" class="form-control" name="packagesA" value="{a}" required>
            		                                                                </div>
            		                                                            </div>
            		                                                            <div class="form-group col-lg-4">
            		                                                                <div class="form-control-wrap">
            		                                                                    <input type="text" class="form-control" name="packagesB" value="{b}" required>
            		                                                                </div>
            		                                                            </div>
            		                                                            <div class="form-group col-lg-4">
            		                                                                <div class="row">
                		                                                                <div class="form-control-wrap col-lg-8">
                		                                                                    <input type="text" class="form-control" name="packagesC" value="{c}" required>
                		                                                                </div>
                		                                                                <div class="form-control-wrap col-lg-2">
            		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                		                                                                </div>
            		                                                                </div>
            		                                                            </div>
        		                                                            </div>
        		                                                            {/packages}
    		                                                            </div>
        		                                                        <div class="col-lg-7 offset-lg-5">
        		                                                            <div class="form-group mt-2">
        		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
        		                                                            </div>
        		                                                        </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="services">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/services}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem16">
                                                        {history}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">History Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="history_heading" value="{history_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">History Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="history_sub-heading" value="{history_sub-heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile1" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile2"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/history_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-12">
    		                                                            <div class="form-group text-center">
    		                                                                <label class="form-label" for="site-name"><u>History</u></label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-12">
        		                                                        <div class="row">
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Title</label>
        		                                                            </div>
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Description</label>
        		                                                            </div>
        		                                                            <div class="form-group text-center col-lg-4">
        		                                                                <label class="form-label" for="site-name">Year</label>
        		                                                            </div>
        		                                                        </div>
    		                                                        </div>
    		                                                        <div class="col-lg-12 repeater">
    		                                                            <div data-repeater-list="history">
    		                                                                {history2}
        		                                                            <div class="row" data-repeater-item>
            		                                                            <div class="form-group col-lg-4" >
            		                                                                <div class="form-control-wrap">
            		                                                                    <input type="text" class="form-control" name="historyB" value="{b}" required>
            		                                                                </div>
            		                                                            </div>
            		                                                            <div class="form-group col-lg-4">
            		                                                                <div class="form-control-wrap">
            		                                                                    <input type="text" class="form-control" name="historyC" value="{c}" required>
            		                                                                </div>
            		                                                            </div>
            		                                                            <div class="form-group col-lg-4">
            		                                                                <div class="row">
                		                                                                <div class="form-control-wrap col-lg-8">
                		                                                                    <input type="text" class="form-control" name="historyA" value="{a}" required>
                		                                                                </div>
                		                                                                <div class="form-control-wrap col-lg-2">
            		                                                                        <button class="btn btn-sm btn-danger" data-repeater-delete type="button">Delete</button>
                		                                                                </div>
            		                                                                </div>
            		                                                            </div>
        		                                                            </div>
        		                                                            {/history2}
    		                                                            </div>
        		                                                        <div class="col-lg-7 offset-lg-5">
        		                                                            <div class="form-group mt-2">
        		                                                                <button class="btn btn-sm btn-warning" data-repeater-create  type="button">Add</button>
        		                                                            </div>
        		                                                        </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="history">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/history}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem17">
                                                        {covid}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Covid Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="covid_heading" value="{covid_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Covid Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="covid_sub_heading" value="{covid_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile3" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile3"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/covid_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Content Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile3" name="bannerImg2">
    		                                                                	<label class="custom-file-label" for="customFile3"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/News/covid_banner.jpg" alt="" style="width: 585px;height:142px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Covid Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="covid_title" value="{covid_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label">Covid</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<textarea class="form-control form-control-sm" name="covid_desc" placeholder="Write your covid" required>{covid_desc}</textarea>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="covid">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/covid}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem18">
                                                        {affiliate}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Affiliate Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="aff_heading" value="{aff_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Affiliate Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="aff_sub_heading" value="{aff_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile3" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile3"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/affiliate_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Affiliate Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="aff_title" value="{aff_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label">Affiliate</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<textarea class="form-control form-control-sm" name="aff_desc" placeholder="Write your affiliate" required>{aff_desc}</textarea>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="affiliate">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/affiliate}
                                                    </div>
                                                    <div class="tab-pane" id="tabItem19">
                                                        {testimonial}
    		                                                <form action="admin/pages" method="post" class="gy-3 form-validate is-alter">
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Page Title</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="page_title" value="{page_title}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Testimonial Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="review_heading" value="{review_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    				                                            <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Testimonial Sub-Heading</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                    <input type="text" class="form-control" name="review_sub_heading" value="{review_sub_heading}" required>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    			                                                </div>
    			                                                <hr/>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <label class="form-label" for="site-name">Banner Image</label>
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<input type="file" class="custom-file-input" id="customFile4" name="bannerImg">
    		                                                                	<label class="custom-file-label" for="customFile4"  accept=".png,jpg">Choose file</label>
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <div class="row g-3 align-center">
    		                                                        <div class="col-lg-5">
    		                                                            <div class="form-group">
    		                                                                <!--<label class="form-label" for="site-name">Slider Image</label>-->
    		                                                            </div>
    		                                                        </div>
    		                                                        <div class="col-lg-7">
    		                                                            <div class="form-group">
    		                                                                <div class="form-control-wrap">
    		                                                                	<img src="common/assets/images/bg-content/testimonial_slider.jpg" alt="" style="width: 960px;height:135px;">
    		                                                                </div>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                    <hr/>
    		                                                    <div class="row g-3">
    		                                                        <div class="col-lg-7 offset-lg-5">
    		                                                            <div class="form-group mt-2">
    		                                                                <input type="hidden" name="section" value="testimonial">
    		                                                                <button type="submit" class="btn btn-lg btn-primary" name="set-review">Update</button>
    		                                                            </div>
    		                                                        </div>
    		                                                    </div>
    		                                                </form>
		                                                {/testimonial}
                                                    	<hr/>
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>Name</th>
			                                                            <th>Review</th>
			                                                            <th>Image Link</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{ztestimonial}
				                                                        <tr>
				                                                            <td id="name-{id}">{name}</td>
				                                                            <td id="rev-{id}">{review}</td>
				                                                            <td id="img-{id}">{image}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor3('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/pages/testimonials/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/ztestimonial}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    	<div class="text-center" style="margin-top: 30px;">
		                                                    <button type="button" class="btn btn-sm btn-primary" onclick="newer3()">Add</button>
		                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
			    <!-- @@ Review Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="gallery-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/pages" class="form-validate"  enctype="multipart/form-data">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Name</label>
			                                            <input type="text" id="item1" name="name" class="form-control form-control-lg" placeholder="Enter Name" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Image</label>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Image</label>
                                                    	<input type="file" class="custom-file-input" id="customFile6" name="image" accept=".png,jpg,.gif">
                                                    	<label class="custom-file-label" for="customFile6">Choose file</label>
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="sectionz2" name="section">
			                                                <input type="hidden" id="idz2" name="id">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
			    <!-- @@ Faq Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="faq-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/pages" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title2"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Question</label>
			                                            <input type="text" id="item1b" name="question" class="form-control form-control-lg" placeholder="Enter question" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Answer</label>
		                                                <textarea class="form-control form-control-sm" id="item2b" name="answer" placeholder="Write your review" required></textarea>
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="sectionz" name="section">
			                                                <input type="hidden" id="idz" name="id">
			                                                <input type="submit" id="submit2" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
			    <!-- @@ Testimonials Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="review-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/pages" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title3"></h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Name</label>
			                                            <input type="text" id="item1c" name="name" class="form-control form-control-lg" placeholder="Enter name" required>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="display-name">Review</label>
		                                                <textarea class="form-control form-control-sm" id="item2c" name="review" placeholder="Write your review" required></textarea>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Image Link</label>
			                                            <input type="text" id="item3c" name="img" class="form-control form-control-lg" placeholder="Enter Image Link">
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="sectionz3" name="section">
			                                                <input type="hidden" id="idz3" name="id">
			                                                <input type="submit" id="submit3" class="btn btn-lg btn-primary">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
<script>
	function editor(did){
		$('#gallery-edit').modal('show');
		document.querySelector('#gallery-edit #item1').value = document.querySelector('#qname-'+did).textContent;
		document.querySelector('#gallery-edit #rev-title').textContent = 'Update Image';
		document.querySelector('#gallery-edit #submit').setAttribute('name','update-product');
		document.querySelector('#gallery-edit #submit').value = 'Update';
		document.querySelector('#gallery-edit #sectionz2').value = 'media-edit';
		document.querySelector('#gallery-edit #idz2').value = did;
	}

	function newer(did){
		$('#gallery-edit').modal('show');
		document.querySelector('#gallery-edit #item1').value = null;
		document.querySelector('#gallery-edit #rev-title').textContent = 'Create Image';
		document.querySelector('#gallery-edit #submit').setAttribute('name','set-new-product');
		document.querySelector('#gallery-edit #submit').value = 'Write';
		document.querySelector('#gallery-edit #sectionz2').value = 'media-create';
	}

	function editor2(did){
		$('#faq-edit').modal('show');
		document.querySelector('#faq-edit #item1b').value = document.querySelector('#ques-'+did).textContent;
		document.querySelector('#faq-edit #item2b').value = document.querySelector('#ans-'+did).textContent;
		document.querySelector('#faq-edit #rev-title2').textContent = 'Update Faq';
		document.querySelector('#faq-edit #submit2').setAttribute('name','update-faq');
		document.querySelector('#faq-edit  #submit2').value = 'Update';
		document.querySelector('#faq-edit #sectionz').value = 'faq-edit';
		document.querySelector('#faq-edit #idz').value = did;
	}

	function newer2(did){
		$('#faq-edit').modal('show');
		document.querySelector('#faq-edit #item1b').value = null;
		document.querySelector('#faq-edit #item2b').value = null;
		document.querySelector('#faq-edit #rev-title2').textContent = 'Write Faq';
		document.querySelector('#faq-edit #submit2').setAttribute('name','set-new-faq');
		document.querySelector('#faq-edit  #submit2').value = 'Write';
		document.querySelector('#faq-edit #sectionz').value = 'faq-create';
	}

	function editor3(did){
		$('#review-edit').modal('show');
		document.querySelector('#review-edit #item1c').value = document.querySelector('#name-'+did).textContent;
		document.querySelector('#review-edit #item2c').value = document.querySelector('#rev-'+did).textContent;
		document.querySelector('#review-edit #item3c').value = document.querySelector('#img-'+did).textContent;
		document.querySelector('#review-edit #rev-title3').textContent = 'Update Testimonial';
		document.querySelector('#review-edit #submit3').setAttribute('name','update-review');
		document.querySelector('#review-edit  #submit3').value = 'Update';
		document.querySelector('#review-edit #sectionz3').value = 'review-edit';
		document.querySelector('#review-edit #idz3').value = did;
	}

	function newer3(did){
		$('#review-edit').modal('show');
		document.querySelector('#review-edit #item1c').value = null;
		document.querySelector('#review-edit #item2c').value = null;
		document.querySelector('#review-edit #item3c').value = null;
		document.querySelector('#review-edit #rev-title3').textContent = 'Write Testimonial';
		document.querySelector('#review-edit #submit3').setAttribute('name','set-new-review');
		document.querySelector('#review-edit  #submit3').value = 'Write';
		document.querySelector('#review-edit #sectionz3').value = 'review-create';
	}
</script>