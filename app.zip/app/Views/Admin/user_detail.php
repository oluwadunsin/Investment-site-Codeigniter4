 <div class="nk-content " style="margin-top: 70px;">
                  <div class="container-fluid">
                     <div class="nk-content-inner">
                        <div class="nk-content-body">
                           <div class="nk-block-head nk-block-head-sm">
                              <div class="nk-block-between g-3">
                                 <div class="nk-block-head-content">
                                    <h3 class="nk-block-title page-title">KYCs / <strong class="text-primary small">{uname|title}</strong></h3>
                                    <div class="nk-block-des text-soft">
                                       <ul class="list-inline">
                                          <li>User ID: <span class="text-base">{site_prefix}-{id}</span></li>
                                          <li>Joined At: <span class="text-base">{created}</span></li>
                                       </ul>
                                    </div>
                                 </div>
                                 <div class="nk-block-head-content"><a href="admin/users" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Back</span></a><a href="kyc-list-regular.html" class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em class="icon ni ni-arrow-left"></em></a></div>
                              </div>
                           </div>
                                                {if $infoSettings != null}
                                                    {! infoSettings !}
                                                {endif}
                                                {if $infoPass != null}
                                                    {! infoPass !}
                                                {endif}
                                                {if $info != null}
                                                    {! info !}
                                                {endif}
                           <div class="nk-block">
                              <div class="row gy-5">
                                 <div class="col-lg-5">
                                    <div class="nk-block-head">
                                       <div class="nk-block-head-content">
                                          <h5 class="nk-block-title title">Application Info</h5>
                                          <p>Submission date, approve date, status etc.</p>
                                       </div>
                                    </div>
                                    <div class="card card-bordered">
                                       <ul class="data-list is-compact">
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Username</div>
                                                <div class="data-value">
                                                   <div class="user-card">
                                                      <div class="user-avatar user-avatar-xs {bg_clr}"><span>{initials|upper}</span></div>
                                                      <div class="user-name"><span class="tb-lead">{uname|title}</span></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Status</div>
                                                <div class="data-value">{! kyc_status !}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Last Login</div>
                                                <div class="data-value">{last_login}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Wallet</div>
                                                <div class="data-value"><span class="tb-amount">{wallet} <span class="currency">{site_currency|upper}</span></span></div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Profile</div>
                                                <div class="data-value"><a  data-toggle="modal" data-target="#profile-edit" class="btn btn-outline-primary">--Edit--</a></div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Password</div>
                                                <div class="data-value"><a  data-toggle="modal" data-target="#password-edit" class="btn btn-outline-warning">--Edit--</a></div>
                                             </div>
                                          </li>
                                       </ul>
                                    </div>
                                    <div class="nk-block-head">
                                       <div class="nk-block-head-content">
                                          <h5 class="nk-block-title title">Uploaded Documents</h5>
                                          <p>Here is user uploaded documents.</p>
                                       </div>
                                    </div>
                                    <div class="card card-bordered">
                                       <ul class="data-list is-compact">
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Document Type</div>
                                                <div class="data-value">{kyc_doc}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Front Side</div>
                                                <div class="data-value"><a href="kyc/front/{kyc_front}" target="_blank">View</a></div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Back Side</div>
                                                <div class="data-value text-center"><a href="kyc/back/{kyc_back}" target="_blank">View</a></div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Proof/Selfie</div>
                                                <div class="data-value text-center"><a href="kyc/selfie/{kyc_selfie}" target="_blank">View</a></div>
                                             </div>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                                 <div class="col-lg-7">
                                    <div class="nk-block-head">
                                       <div class="nk-block-head-content">
                                          <h5 class="nk-block-title title">Applicant Information</h5>
                                          <p>Basic info, like name, phone, address, country etc.</p>
                                       </div>
                                    </div>
                                    <div class="card card-bordered">
                                       <ul class="data-list is-compact">
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">First Name</div>
                                                <div class="data-value">{first_name|title}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Last Name</div>
                                                <div class="data-value">{last_name|title}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Email Address</div>
                                                <div class="data-value">{uemail|lower}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Phone Number</div>
                                                <div class="data-value text-soft"><em>{uphone}</em></div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Date of Birth</div>
                                                <div class="data-value">{dob}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Full Address</div>
                                                <div class="data-value">{uaddress}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Website</div>
                                                <div class="data-value">{site_name|title}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Language</div>
                                                <div class="data-value">English</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Referral Code</div>
                                                <div class="data-value">{ref_code|lower}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Referral Link</div>
                                                <div class="data-value text-break">{ref_link|link}</div>
                                             </div>
                                          </li>
                                          <li class="data-item">
                                             <div class="data-col">
                                                <div class="data-label">Bio</div>
                                                <div class="data-value text-break">{bio}</div>
                                             </div>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               
               

    <!-- @@ Profile Edit Modal @e -->
    <div class="modal fade" tabindex="-1" role="dialog" id="profile-edit">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <form method="post" action="admin/user/profile">
                <div class="modal-content">
                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                    <div class="modal-body modal-body-lg">
                        <h5 class="title">Update Profile</h5>
                        <ul class="nk-nav nav nav-tabs">
                            <li class="nav-item">
                                <a id="inity" class="nav-link active" data-toggle="tab" href="#personal">Personal</a>
                            </li>
                            <li class="nav-item">
                                <a id="initz" class="nav-link" data-toggle="tab" href="#address">Address</a>
                            </li>
                        </ul><!-- .nav-tabs -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="personal">
                                <div class="row gy-4">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="full-name">Username</label>
                                            <input type="text" name="uname" class="form-control form-control-lg" id="username" value="{username}" placeholder="Enter username" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="full-name">First Name</label>
                                            <input type="text" name="fname" class="form-control form-control-lg" id="full-name" value="{first_name}" placeholder="Enter First name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="display-name">Last Name</label>
                                            <input type="text" name="lname" class="form-control form-control-lg" id="display-name" value="{last_name}" placeholder="Enter Last name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="phone-no">Phone Number</label>
                                            <input type="phone" name="phone" class="form-control form-control-lg" id="phone-no" value="{uphone}" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="birth-day">Email</label>
                                            <input type="email" name="email" value="{uemail}" class="form-control form-control-lg" placeholder="Enter your email" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                            <li>
			                                    <input type="hidden" id="rev-idz" name="id" value="{id}">
			                                    <input type="hidden" name="section" value="profile">
                                                <input type="submit" name="adm-profile" id="submit" class="btn btn-lg btn-primary" value="Update">
                                            </li>
                                            <li>
                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!-- .tab-pane -->
                            <div class="tab-pane" id="address">
                                <div class="row gy-4">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="address-l1">Date Of Birth(Day)</label>
            										<select class="form-control select2" name="dobD" required>
            											<option value="0">Date</option>
            											<option value="1">01</option>
            											<option value="2">02</option>
            											<option value="3">03</option>
            											<option value="4">04</option>
            											<option value="5">05</option>
            											<option value="6">06</option>
            											<option value="7">07</option>
            											<option value="8">08</option>
            											<option value="9">09</option>
            											<option value="10">10</option>
            											<option value="11">11</option>
            											<option value="12">12</option>
            											<option value="13">13</option>
            											<option value="14">14</option>
            											<option value="15">15</option>
            											<option value="16">16</option>
            											<option value="17">17</option>
            											<option value="18">18</option>
            											<option value="19">19</option>
            											<option value="20">20</option>
            											<option value="21">21</option>
            											<option value="22">22</option>
            											<option value="23">23</option>
            											<option value="24">24</option>
            											<option value="25">25</option>
            											<option value="26">26</option>
            											<option value="27">27</option>
            											<option value="28">28</option>
            											<option value="29">29</option>
            											<option value="30">30</option>
            											<option value="31">31</option>
            										</select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="address-st">Date Of Birth(Month)</label>
            										<select class="form-control select2" name="dobM" required>
            											<option value="0">Mon</option>
            											<option value="1">Jan</option>
            											<option value="2">Feb</option>
            											<option value="3">Mar</option>
            											<option value="4">Apr</option>
            											<option value="5">May</option>
            											<option value="6">June</option>
            											<option value="7">July</option>
            											<option value="8">Aug</option>
            											<option value="9">Sep</option>
            											<option value="10">Oct</option>
            											<option value="11">Nov</option>
            											<option value="12">Dec</option>
            										</select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="address-st">Date Of Birth(Year)</label>
            										<select class="form-control select2" name="dobY" required>
            											<option>Year</option>
            											<option>2021</option>
            											<option>2020</option>
            											<option>2019</option>
            											<option>2018</option>
            											<option>2017</option>
            											<option>2016</option>
            											<option>2015</option>
            											<option>2014</option>
            											<option>2013</option>
            											<option>2102</option>
            											<option>2012</option>
            											<option>2011</option>
            											<option>2010</option>
            											<option>2009</option>
            											<option>2008</option>
            											<option>2007</option>
            											<option>2006</option>
            											<option>2005</option>
            											<option>2004</option>
            											<option>2003</option>
            											<option>2002</option>
            											<option>2001</option>
            											<option>1999</option>
            											<option>1998</option>
            											<option>1997</option>
            											<option>1996</option>
            											<option>1995</option>
            											<option>1994</option>
            											<option>1993</option>
            											<option>1992</option>
            											<option>1991</option>
            											<option>1990</option>
            											<option>1989</option>
            											<option>1987</option>
            											<option>1986</option>
            											<option>1985</option>
            											<option>1984</option>
            											<option>1986</option>
            											<option>1987</option>
            											<option>1985</option>
            										</select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="address-l2">Address</label>
                                            <input type="text" name="address" value="{uaddress}" class="form-control form-control-lg" id="address-l2" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="address-l2">About me</label>
                                            <input type="text" name="bio" value="{bio}" class="form-control form-control-lg" id="address-l3" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                            <li>
                                                <input type="hidden" name="uid" value="<?php echo $_SESSION['i_user']['id']; ?>">
                                                <input type="submit" name="adm-profile" id="submit" class="btn btn-lg btn-primary" value="Update">
                                            </li>
                                            <li>
                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!-- .tab-pane -->
                        </div><!-- .tab-content -->
                    </div><!-- .modal-body -->
                </div><!-- .modal-content -->
            </form>
        </div><!-- .modal-dialog -->
    </div><!-- .modal -->




    <!-- @@ Password Edit Modal @e -->
    <div class="modal fade zoom" tabindex="-1" role="dialog" id="password-edit">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <form method="post" action="admin/user/password">
                <div class="modal-content">
                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                    <div class="modal-body modal-body-sm">
                        <div class="modal-header">
                            <h6 class="modal-title">Update Password</h6>
                        </div>
                                <div class="row gy-4">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="full-name">Old Password</label>
                                            <input type="password" name="old" class="form-control form-control-lg" placeholder="old password" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="display-name">Password</label>
                                            <input type="password" name="conf_password" class="form-control form-control-lg" placeholder="password" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label" for="display-name">Confirm Password</label>
                                            <input type="password" name="conf_password" class="form-control form-control-lg" placeholder="confirm password" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                            <li>
			                                    <input type="hidden" id="rev-idz" name="id" value="{id}">
			                                    <input type="hidden" id="rev-idz2" name="email" value="{uemail}">
			                                    <input type="hidden" name="section" value="password">
                                                <input type="submit" name="adm-ch_password" id="submit" class="btn btn-lg btn-primary" value="Update">
                                            </li>
                                            <li>
                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                    </div><!-- .modal-body -->
                </div><!-- .modal-content -->
            </form>
        </div><!-- .modal-dialog -->
    </div><!-- .modal -->