<!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Subscribers</h4>
                                                <div class="nk-block-des">
                                                    <p>Get Newsletter Subscribers here</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Subscribers</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Active</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Inactive</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem9">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(subscribed)</th>
			                                                            <th>Email</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{all}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}">{time}</td>
				                                                            <td class="email-{id}">{email|lower}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/newsletter/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/all}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(subscribed)</th>
			                                                            <th>Email</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{active}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}">{time}</td>
				                                                            <td class="email-{id}">{email|lower}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/newsletter/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/active}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(subscribed)</th>
			                                                            <th>Email</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{inactive}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}">{time}</td>
				                                                            <td class="email-{id}">{email|lower}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/newsletter/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/inactive}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
			    <!-- @@ Review Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="newsletter-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/newsletter/update" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title">Edit Subscriber</h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Status</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item1" class="form-select form-control form-control-lg select2-hidden-accessible" name="status" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="0">Inactive</option>
			                                                        <option value="1">Active</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Email</label>
			                                            <input type="text" id="item1b" name="email" class="form-control form-control-lg" placeholder="Enter email">
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary" value="Update" name="update-newsletter">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
<script>
	function editor(did){
		document.querySelector('#newsletter-edit #rev-idz').value = did;
		document.querySelector('#item1b').value = document.querySelector('.email-'+did).textContent;
		
		$('#newsletter-edit').modal('show');
		if(document.querySelector('.sta-'+did+' span').classList.contains('badge-success')) $('#item1').val('1').change();
		else if(document.querySelector('.sta-'+did+' span').classList.contains('badge-danger')) $('#item1').val('02').change();

	}
</script>