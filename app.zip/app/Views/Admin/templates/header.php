<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="{base_url}">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="{seo_description}">
	<meta name="author" content="Omnix Technologies">
	<meta name="keywords" content="{seo_keywords}">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="common/assets/images/x-icon/favicon.png">
    <!-- Page Title  -->
    <title>{page_title|title}</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="admin/assets/css/dashlite8d5a.css">
    <link id="skin-default" rel="stylesheet" href="admin/assets/css/theme8d5a.css">
    <!--toastr-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script>
        window.addEventListener('load',()=>{
            toastr.options = {
              "closeButton": true,
              "debug": false,
              "newestOnTop": true,
              "progressBar": true,
              "positionClass": "toast-top-center",
              "preventDuplicates": false,
              "onclick": null,
              "showDuration": "300",
              "hideDuration": "1000",
              "timeOut": "3000",
              "extendedTimeOut": "1000",
              "showEasing": "swing",
              "hideEasing": "linear",
              "showMethod": "fadeIn",
              "hideMethod": "fadeOut",
            }
        });
    </script>
    {if $toast === true }
        <script>window.addEventListener('load',()=>{ toastr["success"]("Successful"); });</script>
    {elseif $toast === false }
        <script>window.addEventListener('load',()=>{ toastr["error"]("There was an error"); });</script>
    {endif}
</head>

<body class="nk-body bg-lighter npc-general has-sidebar dark-mode">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- sidebar @s -->
            <div class="nk-sidebar nk-sidebar-fixed is-theme " data-content="sidebarMenu">
                <div class="nk-sidebar-element nk-sidebar-head">
					<div class="nk-menu-trigger"><a href="javascript:void(0)" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a><a href="javascript:void(0)" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
					</div>
                    <div class="nk-sidebar-brand">
                        <a href="admin/dashboard" class="logo-link nk-sidebar-logo">
                            <img class="logo-light logo-img" src="common/assets/images/logo/logo.png" srcset="common/assets/images/logo/logo.png 2x" alt="logo">
                            <img class="logo-dark logo-img" src="common/assets/images/logo/logo.png" srcset="common/assets/images/logo/logo.png 2x" alt="logo-dark">
                            <!--<span class="nio-version">General</span>-->
                        </a>
                    </div>
                </div><!-- .nk-sidebar-element -->
                <div class="nk-sidebar-element  nk-sidebar-body">
                    <div class="nk-sidebar-content">
                        <div class="nk-sidebar-menu" data-simplebar>
                            <ul class="nk-menu">
                                <li class="nk-menu-item">
                                    <a href="admin/dashboard" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span>
                                        <span class="nk-menu-text">Dashboard</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/settings" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-setting-alt"></em></span>
                                        <span class="nk-menu-text">Settings</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/plans" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-sign-usdt"></em></span>
                                        <span class="nk-menu-text">Plans</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/investments" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-invest"></em></span>
                                        <span class="nk-menu-text">Investments</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/users" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-users"></em></span>
                                        <span class="nk-menu-text">Users</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/mail/inbox" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-mail"></em></span>
                                        <span class="nk-menu-text">Mail</span>
                                        {if $mail_inbox_count > 0}<span class="badge badge-pill badge-primary">{mail_inbox_count}</span>{endif}
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/deposits" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-wallet-in"></em></span>
                                        <span class="nk-menu-text">Deposits</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/withdrawals" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-wallet-out"></em></span>
                                        <span class="nk-menu-text">Withdrawal</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/referrals" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-user-add"></em></span>
                                        <span class="nk-menu-text">Referrals</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/logins" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-unlock"></em></span>
                                        <span class="nk-menu-text">Logins</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/pages" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-book-read"></em></span>
                                        <span class="nk-menu-text">Pages</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="admin/newsletter" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-wifi"></em></span>
                                        <span class="nk-menu-text">Newsletter</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item">
                                    <a href="logout" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-lock-alt"></em></span>
                                        <span class="nk-menu-text">Logout</span>
                                    </a>
                                </li><!-- .nk-menu-item -->
                            </ul><!-- .nk-menu -->
                        </div><!-- .nk-sidebar-menu -->
                    </div><!-- .nk-sidebar-content -->
                </div><!-- .nk-sidebar-element -->
            </div>
            <!-- sidebar @e -->
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <!-- main header @s -->
                <div class="nk-header nk-header-fixed is-theme">
                    <div class="container-fluid">
                        <div class="nk-header-wrap">
                            <div class="nk-menu-trigger d-xl-none ml-n1">
                                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                            </div>
                            <div class="nk-header-brand d-xl-none">
                                <a href="admin/dashboard" class="logo-link">
                            <img class="logo-light logo-img" src="common/assets/images/logo/logo.png" srcset="common/assets/images/logo/logo.png 2x" alt="logo">
                            <img class="logo-dark logo-img" src="common/assets/images/logo/logo.png" srcset="common/assets/images/logo/logo.png 2x" alt="logo-dark">
                                    <span class="nio-version">General</span>
                                </a>
                            </div><!-- .nk-header-brand -->
                            <div class="nk-header-news d-none d-xl-block">
                                <div class="nk-news-list">
                                    <a class="nk-news-item" href="#">
                                        <div class="nk-news-icon">
                                            <em class="icon ni ni-card-view"></em>
                                        </div>
                                        <div class="nk-news-text">
                                            <p>Announcement <span> {site_notif_in}</span></p>
                                            <em class="icon ni ni-external"></em>
                                        </div>
                                    </a>
                                </div>
                            </div><!-- .nk-header-news -->
                            <div class="nk-header-tools">
                                <ul class="nk-quick-nav">
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                            <div class="user-toggle">
                                                <div class="user-avatar sm">
                                                    <em class="icon ni ni-user-alt"></em>
                                                </div>
                                                <div class="user-info d-none d-md-block">
                                                    <div class="user-status">Administrator</div>
                                                    <div class="user-name dropdown-indicator">{username|capitalize}</div>
                                                </div>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-right dropdown-menu-s1">
                                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                                <div class="user-card">
                                                    <div class="user-avatar">
                                                        <span>{fname_init|upper}</span>
                                                    </div>
                                                    <div class="user-info">
                                                        <span class="lead-text">{fullname|title}</span>
                                                        <span class="sub-text">{payEmail|lower}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                <li><a href="user/profile"><em class="icon ni ni-user-alt"></em><span>View Profile</span></a></li>
                                                <li><a href="user/profile/settings"><em class="icon ni ni-setting-alt"></em><span>Account Setting</span></a></li>
                                                <li><a href="user/login"><em class="icon ni ni-activity-alt"></em><span>Login Activity</span></a></li>
                                                </ul>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                <li><a href="logout"><em class="icon ni ni-signout"></em><span>Sign out</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li><!-- .dropdown -->
                                </ul><!-- .nk-quick-nav -->
                            </div><!-- .nk-header-tools -->
                        </div><!-- .nk-header-wrap -->
                    </div><!-- .container-fliud -->
                </div>
                <!-- main header @e -->
                <style>
                      body > div.nk-app-root > div > div.nk-wrap > div.nk-content > div > div > div > div > div{
                          margin-top:50px;
                      }
            		.dataTable tr, .dataTable td {
            		     white-space: unset;
            		}
            		.editComp{
            			cursor: pointer;
            		}
                </style>
                