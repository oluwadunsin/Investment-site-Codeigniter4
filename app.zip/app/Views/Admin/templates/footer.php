
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright">Copyright &copy; {datez|date(Y)} <a href="#">{site_name|title}</a>. - Powered By <a href="#"> Omnix Technologies. </a> All rights reserved.</div>
                            <div class="nk-footer-links">
                                <ul class="nav nav-sm">
                                    <li class="nav-item"><a class="nav-link" href="admin/terms">Terms</a></li>
                                    <li class="nav-item"><a class="nav-link" href="admin/privacy">Privacy</a></li>
                                    <li class="nav-item"><a class="nav-link" href="admin/faq">Help</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    <!--<script src="admin/assets/js/bundle8d5a.js"></script>-->
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" 
    integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>-->
    <script src="admin/assets/js/bundle.js"></script>
    <script src="admin/assets/js/scripts8d5a.js"></script>
	<!--<script src="admin/assets/js/demo-settings8d5a.js"></script>-->
	<script src="admin/assets/js/charts/gd-invest8d5a.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    {if $page == "front-pages-settings"}
        {noparse}<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.repeater/1.2.1/jquery.repeater.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.repeater').repeater({
                    initEmpty: false,
                    defaultValues: {
                        'text-input': ''
                    },
                    show: function () {
                        $(this).slideDown();
                    },
                    hide: function (deleteElement) {
                        if(confirm('Are you sure you want to delete this item?')) {
                            $(this).slideUp(deleteElement);
                        }
                    },
                    ready: function (setIndexes) {
                    },
                    isFirstItemUndeletable: false
                })
            });
        </script>{/noparse}
    {endif}
</body>

</html>