<style>
        #DataTables_Table_0_wrapper{
            width:fit-content !important;
            margin:20px;
        }
</style>
                <!-- content @s -->
                <div class="nk-content " style="margin-top: -50px;>
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title" style="margin-top: 70px;">Users Lists</h3>
                                            <div class="nk-block-des text-soft">
                                                <p>You have total {total} users.</p>
                                            </div>
                                        </div><!-- .nk-block-head-content -->
                                        <!--<div class="nk-block-head-content">
                                            <div class="toggle-wrap nk-block-tools-toggle">
                                                <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                                <div class="toggle-expand-content" data-content="pageMenu">
                                                    <ul class="nk-block-tools g-3">
                                                        <li><a href="#" class="btn btn-white btn-outline-light"><em class="icon ni ni-download-cloud"></em><span>Export</span></a></li>
                                                        <li class="nk-block-tools-opt">
                                                            <div class="drodown">
                                                                <a href="#" class="dropdown-toggle btn btn-icon btn-primary" data-toggle="dropdown"><em class="icon ni ni-plus"></em></a>
                                                                <div class="dropdown-menu dropdown-menu-right">
                                                                    <ul class="link-list-opt no-bdr">
                                                                        <li><a href="#"><span>Add User</span></a></li>
                                                                        <li><a href="#"><span>Add Team</span></a></li>
                                                                        <li><a href="#"><span>Import User</span></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>-- .toggle-wrap --
                                        </div>-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                                <div class="nk-block">
                                    <div class="card card-bordered card-stretch">
                                        <div class="card-inner-group">
                                                        <div class="table-responsive text-center">
                                                            <table class="datatable-init nowrap nk-tb-list nk-tb-ulist dtr-inline" data-auto-responsive="false">
                                                                <thead>
                                                                    <tr class="nk-tb-item nk-tb-head">
                                                                        <th class="nk-tb-col tb-col-sm">Initials</th>
                                                                        <th class="nk-tb-col tb-col-lg">Name</th>
                                                                        <th class="nk-tb-col tb-col-lg">Username</th>
                                                                        <th class="nk-tb-col tb-col-lg">Joined</th>
                                                                        <th class="nk-tb-col tb-col-lg">Last-Login</th>
                                                                        <th class="nk-tb-col tb-col-sm">Email</th>
                                                                        <th class="nk-tb-col tb-col-md">Phone</th>
                                                                        <th class="nk-tb-col tb-col-mb">Profit</th>
                                                                        <th class="nk-tb-col tb-col-mb">Invested</th>
                                                                        <th class="nk-tb-col tb-col-mb">Deposited</th>
                                                                        <th class="nk-tb-col tb-col-mb">Withdrawn</th>
                                                                        <th class="nk-tb-col tb-col-mb">Referral</th>
                                                                        <th class="nk-tb-col tb-col-mb">Wallet</th>
                                                                        <th class="nk-tb-col tb-col-mb">Expenses</th>
                                                                        <th class="nk-tb-col tb-col-lg">Verified</th>
                                                                        <th class="nk-tb-col">Status</th>
                                                                        <th class="nk-tb-col nk-tb-col-tools text-right">...</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {users}
                                                                        <tr>
                                                                            <td class="nk-tb-col tb-col-sm"><div class="user-avatar xs {bg_clr}"><span>{initials}</span></div></td>
                                                                            <td class="nk-tb-col tb-col-lg user-name"><span class="tb-lead">{first_name|capitalize} {last_name|capitalize}</span></td>
                                                                            <td class="nk-tb-col tb-col-md user-name"><span class="tb-lead">{username|capitalize}</span></td>
                                                                            <td class="nk-tb-col tb-col-lg"><span>{joined}</span></td>
                                                                            <td class="nk-tb-col tb-col-lg"><span>{last_login}</span></td>
                                                                            <td class="nk-tb-col tb-col-sm"><span>{email|lower}</span></td>
                                                                            <td class="nk-tb-col tb-col-md"><span>{phone}</span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{profit} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{invested} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{deposit} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{withdraw} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{referral} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td id="wal-{id}" class="nk-tb-col tb-col-mb"><span class="tb-amount">{wallet} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-mb"><span class="tb-amount">{expenses} <span class="currency">{site_currency|upper}</span></span></td>
                                                                            <td class="nk-tb-col tb-col-lg"><ul class="list-status"><li>{! verified !}</li><li>{! kyc_status !}</li></ul></td>
                                                                            <td class="nk-tb-col">{! active !}</td>
                                                                            <td class="nk-tb-col nk-tb-col-tools">
                                                                                <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
                                                                                    <li>
                                                                                        <div class="drodow">
                                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                                <ul class="link-list-opt no-bdr"> 
                                                                                                    
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},1)" class="editComp"><em class="icon ni ni-edit-alt tb-status text-info"></em><span>Edit Wallet</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},2)" class="editComp"><em class="icon ni ni-account-setting tb-status text-warning"></em><span>Edit User</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},3)" class="editComp"><em class="icon ni ni-alert-circle tb-status text-primary"></em><span>KYC-waiting</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},4)" class="editComp"><em class="icon ni ni-alarm-alt tb-status text-warning"></em><span>KYC-pending</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},5)" class="editComp"><em class="icon ni ni-check-circle-cut tb-status text-success"></em><span>KYC-verify</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},6)" class="editComp"><em class="icon ni ni-cross-circle tb-status text-warning"></em><span>KYC-rejected</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},7)" class="editComp"><em class="icon ni ni-user-check tb-status text-success"></em><span>Activate</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},8)" class="editComp"><em class="icon ni ni-user-remove tb-status text-dark"></em><span>Deactivate</span></a></li>
                                                                                                    <li><a  onclick="confirmer({/noparse}'{id}'{noparse},9)" class="editComp"><em class="icon ni ni-user-cross tb-status text-danger"></em><span>Delete</span></a></li>
                                                                                                {/noparse}</ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                    {/users}
                                                                </tbody>
                                                            </table>
                                                        </div>
                                        </div><!-- .card-inner-group -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                {noparse}<script>
                    function confirmer(did,act){
                        if(act==1){
                        		document.querySelector('#wallet-edit #rev-idz').value = did;
                        		document.querySelector('#item1b').value = Number(document.querySelector('#wal-'+did).textContent.replace(/[^0-9.-]+/g,""));
                        		
                        		$('#wallet-edit').modal('show');
                        }
                        if(act==2){
                            window.open("admin/users/detail/"+did,"_self");
                        }
                        if(act==3 || act==4 || act==5 || act==6){
                            window.open("admin/users/kyc/"+did+"/"+act,"_self");
                        }
                        if(act==7){
                            if(confirm("Are You Sure You Want To Activate This User?")) window.open("admin/users/activate/"+did,"_self");
                        }
                        if(act==8){
                            if(confirm("Are You Sure You Want To DeActivate This User?")) window.open("admin/users/deactivate/"+did,"_self");
                        }
                        if(act==9){
                            if(confirm("Are You Sure You Want To Delete This User? \n All records including deposits,withdrawals, etc will be permanently deleted")) window.open("admin/users/delete/"+did, "_self");
                        }
                    }
                </script>{/noparse}
			    <!-- @@ Wallet Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="wallet-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/user/wallet" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title">Edit User Wallet</h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Balance</label>
			                                            <input type="number" id="item1b" name="wallet" class="form-control form-control-lg" placeholder="Enter wallet balance" step="0.01" oninput="onInput(this)">
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="hidden" name="section" value="wallet">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary" value="Update" name="update-wallet">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->