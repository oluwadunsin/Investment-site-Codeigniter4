
               <div class="nk-content ">
                  <div class="container-fluid">
                     <div class="nk-content-inner">
                        <div class="nk-content-body">
                           <div class="nk-block-head nk-block-head-sm">
                              <div class="nk-block-between">
                                 <div class="nk-block-head-content">
                                    <h3 class="nk-block-title page-title">Investment Dashboard</h3>
                                    <div class="nk-block-des text-soft">
                                       <p>Welcome to {site_name|title} Invest Dashboard</p>
                                    </div>
                                 </div>
                                 <div class="nk-block-head-content">
                                    <div class="toggle-wrap nk-block-tools-toggle">
                                       <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                                       <div class="toggle-expand-content" data-content="pageMenu">
                                          <ul class="nk-block-tools g-3">
                                             <li><a href="#" class="btn btn-white btn-dim btn-outline-primary"><em class="icon ni ni-download-cloud"></em><span>Export</span></a></li>
                                             <li><a href="#" class="btn btn-white btn-dim btn-outline-primary"><em class="icon ni ni-reports"></em><span>Reports</span></a></li>
                                             <!--<li class="nk-block-tools-opt">
                                                <div class="drodown">
                                                   <a href="#" class="dropdown-toggle btn btn-icon btn-primary" data-toggle="dropdown"><em class="icon ni ni-plus"></em></a>
                                                   <div class="dropdown-menu dropdown-menu-right">
                                                      <ul class="link-list-opt no-bdr">
                                                         <li><a href="#"><em class="icon ni ni-user-add-fill"></em><span>Add User</span></a></li>
                                                         <li><a href="#"><em class="icon ni ni-coin-alt-fill"></em><span>Add Order</span></a></li>
                                                         <li><a href="#"><em class="icon ni ni-note-add-fill-c"></em><span>Add Page</span></a></li>
                                                      </ul>
                                                   </div>
                                                </div>
                                             </li>-->
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="nk-block">
                              <div class="row g-gs">
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Deposit</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Deposited"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {DepositT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{DepositM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{DepositW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalDeposit"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Withdraw</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Withdraw"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {WithdrawalT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{WithdrawalM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{WithdrawalW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalWithdraw"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered  card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Balance in Account</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Referral Balance in Account"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {ReferralT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{ReferralM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{ReferralW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalBalance"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Invested</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Invested"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {InvestedT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{InvestedM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{InvestedW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalDeposit"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Withdrawable</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Withdrawable"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {WithdrawableT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{WithdrawableM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{WithdrawableW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalWithdraw"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered  card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Profit Balance in Account</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Profits"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {ProfitT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{ProfitM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{ProfitW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalBalance"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Users</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Users registered"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {UsersT} </div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{UsersM}</div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{UsersW}</div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalDeposit"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Total Wallet Balance</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Balancein Users Wallets"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {WalletT} <span class="currency currency-usd">USD</span></span></div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{WalletM} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{WalletW} <span class="currency currency-usd">{site_currency|upper}</span></div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalWithdraw"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="card card-bordered  card-full">
                                       <div class="card-inner">
                                          <div class="card-title-group align-start mb-0">
                                             <div class="card-title">
                                                <h6 class="subtitle">Mails</h6>
                                             </div>
                                             <div class="card-tools"><em class="card-hint icon ni ni-help-fill" data-toggle="tooltip" data-placement="left" title="Total Mails Received"></em></div>
                                          </div>
                                          <div class="card-amount"><span class="amount"> {MailT}</div>
                                          <div class="invest-data">
                                             <div class="invest-data-amount g-2">
                                                <div class="invest-data-history">
                                                   <div class="title">This Month</div>
                                                   <div class="amount">{MailM}</div>
                                                </div>
                                                <div class="invest-data-history">
                                                   <div class="title">This Week</div>
                                                   <div class="amount">{MailW}</div>
                                                </div>
                                             </div>
                                             <div class="invest-data-ck">
                                                <canvas class="iv-data-chart" id="totalBalance"></canvas>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-xl-12 col-xxl-8">
                                    <div class="card card-bordered card-full">
                                       <div class="card-inner border-bottom">
                                          <div class="card-title-group">
                                             <div class="card-title">
                                                <h6 class="title">Investment Plans Statistics</h6>
                                             </div>
                                             <div class="card-tools"><a href="admin/plans" class="link">View All</a></div>
                                          </div>
                                       </div>
                                       <div class="nk-tb-list">
                                          <div class="nk-tb-item nk-tb-head">
                                             <div class="nk-tb-col tb-col-sm"><span>Plan</span></div>
                                             <div class="nk-tb-col tb-col-lg"><span>Subscribers</span></div>
                                             <div class="nk-tb-col"><span>Invested</span></div>
                                             <div class="nk-tb-col tb-col-sm"><span>Status</span></div>
                                             <div class="nk-tb-col"><span>&nbsp;</span></div>
                                          </div>
                                          {plans}
                                              <div class="nk-tb-item">
                                                 <div class="nk-tb-col tb-col-sm">
                                                    <div class="user-card">
                                                       <div class="user-avatar user-avatar-xs {bg_clr}"><span>{initials}</span></div>
                                                       <div class="user-name"><span class="tb-lead">{name|capitalize}</span></div>
                                                    </div>
                                                 </div>
                                                 <div class="nk-tb-col tb-col-lg"><span class="tb-sub">{subscribers}</span></div>
                                                 <div class="nk-tb-col"><span class="tb-sub tb-amount">{invested} <span>{site_currency|upper}</span></span></div>
                                                 <div class="nk-tb-col tb-col-sm">{! status !}</div>
                                                 <div class="nk-tb-col nk-tb-col-action">
                                                    <div class="dropdown">
                                                       <a class="text-soft dropdown-toggle btn btn-sm btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-chevron-right"></em></a>
                                                       <div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
                                                          <ul class="link-list-plain">
                                                             <li><a href="admin/plans">View</a></li>
                                                          </ul>
                                                       </div>
                                                    </div>
                                                 </div>
                                              </div>
                                          {/plans}
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>