
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Logins</h4>
                                                <div class="nk-block-des">
                                                    <p>Get Login Stats here</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Logins</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem15">Today</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Last-Hour</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Yesterday</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">This-Week</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem13">This-Month</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem14">This-Year</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem9">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{all}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/all}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{hour}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/hour}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{yesterday}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/yesterday}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem12">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{week}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/week}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem13">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{month}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/month}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem14">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{year}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/year}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem15">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
											                            <th>Country</th>
			                                                            <th>Username</th>
			                                                            <th>Time</th>
			                                                            <th>Browser</th>
			                                                            <th>IP</th>
			                                                            <th>Location</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{today}
				                                                        <tr>
                                                                            <td><img src="user/assets/images/flags/{code|lower}.svg" class="w-5 h-5 mr-2" alt="" height="30px" width="30px"></td>
						                                                    <td>{username|lower}</td>
						                                                    <td><span class="sub-text">{time}</span></td>
						                                                    <td>{browser|capitalize}</td>
						                                                    <td><span class="sub-text">{ip}</span></td>
						                                                    <td>{location|title}</td>
				                                                        </tr>
						                                            {/today}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->