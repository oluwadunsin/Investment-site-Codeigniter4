<!-- content @s -->
                                        {if $info != null}
                                            {! info !}
                                        {endif}
<div class="nk-content " style="margin-top: 70px;">
   <div class="container-fluid">
      <div class="nk-content-inner">
         <div class="nk-content-body">
			{mail}
                <div class="nk-ibx">
               <div class="nk-ibx-aside" data-content="inbox-aside" data-toggle-overlay="true" data-toggle-screen="lg">
                 <div class="nk-ibx-head">
                     <h5 class="mb-0">Mail</h5>
                     {noparse}<a href="#" class="link link-primary" data-toggle="modal" data-target="#compose-mail">{/noparse}
                     <em class="icon ni ni-plus"></em>
                     <span>Compose</span>
                     </a>
                  </div>
                  <div class="nk-ibx-nav" data-simplebar>
                     <ul class="nk-ibx-menu">
                        <li class="{inbox_owner}">
                           <a class="nk-ibx-menu-item" href="admin/mail/inbox">
                           <em class="icon ni ni-inbox"></em>
                           <span class="nk-ibx-menu-text">Inbox</span>
                           {if $mail_inbox_count > 0}<span class="badge badge-pill badge-primary">{mail_inbox_count}</span>{endif}
                           </a>
                        </li>
                        <li class="{sent_owner}">
                           <a class="nk-ibx-menu-item" href="admin/mail/sent">
                           <em class="icon ni ni-send"></em>
                           <span class="nk-ibx-menu-text">Sent</span>
                           </a>
                        </li>
                        {noparse}<li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-edit"></em>
                           <span class="nk-ibx-menu-text">Draft</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-star"></em>
                           <span class="nk-ibx-menu-text">Favourite</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-report"></em>
                           <span class="nk-ibx-menu-text">Spam</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-trash"></em>
                           <span class="nk-ibx-menu-text">Trash</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-emails"></em>
                           <span class="nk-ibx-menu-text">All Mails</span>
                           </a>
                        </li>{/noparse}
                     </ul>
                  </div>
               </div>
               <div class="nk-ibx-body bg-white">
                  <div class="nk-ibx-view show-ibx">
                     <div class="nk-ibx-head">
                        <div class="nk-ibx-head-actions">
                           <ul class="nk-ibx-head-tools g-1">
                              <li>
                                 <a href="admin/mail/delete/{id}" class="btn btn-icon btn-trigger btn-tooltip" title="Delete">
                                 <em class="icon ni ni-trash"></em>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="nk-ibx-reply nk-reply" data-simplebar>
                        <div class="nk-ibx-reply-head">
                           <div>
                              <h4 class="title">{subject|title}</h4>
                           </div>
                        </div>
                        <div class="nk-ibx-reply-group">
                           <div class="nk-ibx-reply-item nk-reply-item">
                              <div class="nk-reply-header nk-ibx-reply-header is-opened">
                                 <div class="nk-reply-desc">
                                   {if $inbox_owner != ''}
                                        <div class="nk-reply-avatar user-avatar bg-blue">
                                           <img src="profile-pics/{username|lower}.jpg" alt="">
                                        </div>
                                        <div class="nk-reply-info">
                                           <div class="nk-reply-author lead-text">{fullname|title}
                                            <span class="date d-sm-none">{time}</span>
                                           </div>
                                           {noparse}<div class="dropdown nk-reply-msg-info">
                                              <a href="javascript:void(0)" class="dropdown-toggle sub-text dropdown-indicator">to {/noparse}{username2|lower}</a>
                                           </div>
                                        </div>
                                    {elseif $sent_owner != ''}
                                        <div class="nk-reply-avatar user-avatar bg-blue">
                                           <img src="profile-pics/{username2|lower}.jpg" alt="">
                                        </div>
                                        <div class="nk-reply-info">
                                           <div class="nk-reply-author lead-text">{fullname2|title} 
                                              <span class="date d-sm-none">{time}</span>
                                           </div>
                                           {noparse}<div class="dropdown nk-reply-msg-info">
                                              <a href="javascript:void(0)" class="dropdown-toggle sub-text dropdown-indicator">from {/noparse} {username|lower}</a>
                                           </div>
                                        </div>
                                    {endif}
                                 </div>
                                 <ul class="nk-reply-tools g-1">
                                    <li class="date-msg">
                                       <span class="date">{time}</span>
                                    </li>
                                    {noparse}<li class="replyto-msg">
                                       <a href="javascript:void(0)" class="btn btn-trigger btn-icon btn-tooltip" title="Reply">
                                       <em class="icon ni ni-curve-up-left"></em>
                                       </a>
                                    </li>
                                    <li class="more-actions">
                                       <div class="dropdown">
                                          <a href="javascript:void(0)" class="dropdown-toggle btn btn-trigger btn-icon" data-toggle="dropdown">
                                          <em class="icon ni ni-more-v"></em>
                                          </a>{/noparse}
                                          <div class="dropdown-menu dropdown-menu-right">
                                             <ul class="link-list-opt no-bdr">
                                                <li>
                                                   <a class="dropdown-item" href="admin/mail/delete/{id}">
                                                   <em class="icon ni ni-trash-fill"></em>
                                                   <span>Delete this</span>
                                                   </a>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </li>
                                 </ul>
                              </div>
                              <div class="nk-reply-body nk-ibx-reply-body">
                                 <div class="nk-reply-entry entry">
                                    <p>{! body !}</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        {noparse}<div class="nk-ibx-reply-form nk-reply-form">
			               <form method="post" action="admin/mail/compose">
                               <div class="nk-reply-form-header">
                                  <div class="nk-reply-form-group">
                                     <div class="nk-reply-form-dropdown">
                                        <div class="dropdown">
                                           <a class="btn btn-sm btn-trigger btn-icon" data-toggle="dropdown" href="Javascript:void(0)">
                                           <em class="icon ni ni-curve-up-left"></em>
                                           </a>
                                        </div>
                                     </div>{/noparse}
                                     <div class="nk-reply-form-title d-sm-none" id="replier">Reply</div>
                                     <div class="nk-reply-form-input-group">
                                        <div class="nk-reply-form-input nk-reply-form-input-to">
                                           <label class="label">To</label>
                                           {if $inbox_owner != ''}
                                               <input type="text" value="{fullname}" class="input-mail tagify" placeholder="" readonly>
                                               <input type="hidden" value="{_from}" name="recipient" class="input-mail tagify" placeholder="">
                                           {elseif $sent_owner != ''}
                                               <input type="text" value="{fullname2}" class="input-mail tagify" placeholder="" readonly>
                                               <input type="hidden" value="{_to}" name="recipient" class="input-mail tagify" placeholder="">
                                            {endif}
                                        </div>
                                     </div>
                                  </div>
                               </div>
                               <div class="nk-reply-form-editor">
                                  <div class="nk-reply-form-field">
    								 <input type="text" class="form-control" id="subject" name="subject" placeholder="Type Subject"  value="RE: {subject}" required>
                                     <textarea class="form-control form-control-simple no-resize" placeholder="Hello"  name="body"></textarea>
                                  </div>
                               </div>
                               <div class="nk-reply-form-tools">
                                  <ul class="nk-reply-form-actions g-1">
                                     <li class="mr-2">
                                        <button class="btn btn-primary" type="submit">Send</button>
                                     </li>
                                  </ul>
                               </div>
			               </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            {/mail}
         </div>
      </div>
   </div>
</div>

     <div class="modal fade" tabindex="-1" role="dialog" id="compose-mail">
         <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h6 class="modal-title">Compose Message</h6>
                  <a href="#" class="close" data-dismiss="modal">
                  <em class="icon ni ni-cross-sm"></em>
                  </a>
               </div>
			   <form method="post" action="admin/mail/compose">
                   <div class="modal-body p-0">
                      <div class="nk-reply-form-header">
                         <div class="nk-reply-form-group">
                            <div class="nk-reply-form-input-group">
                               <div class="nk-reply-form-input nk-reply-form-input-to">
                                  <label class="label">To</label>
                                        <select id="item1" class="input-mail form-select form-control form-control-lg select2-hidden-accessible" name="recipient" tabindex="-1" aria-hidden="true" required="">
                                                {recipients}
                                                    <option value="{id}">{first_name} {last_name}</option>
                                                {/recipients}
                                        </select>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="nk-reply-form-editor">
                         <div class="nk-reply-form-field">
                            <input type="text" class="form-control form-control-simple" placeholder="Subject" name="subject" required>
                         </div>
                         <div class="nk-reply-form-field">
                            <textarea class="form-control form-control-simple no-resize ex-large" placeholder="Hello" name="body" required></textarea>
                         </div>
                      </div>
                      <div class="nk-reply-form-tools">
                         <ul class="nk-reply-form-actions g-1">
                            <li class="mr-2">
                               <button class="btn btn-primary" type="submit">Send</button>
                            </li>
                         </ul>
                      </div>
                   </div>
			   </form>
            </div>
         </div>
      </div>