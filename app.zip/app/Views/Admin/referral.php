<!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block nk-block-lg contner">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Referrals</h4>
                                                <div class="nk-block-des">
                                                    <p>Get Referral Stats here</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-bordered card-preview">
                                            <div class="card-inner">
                                                <ul class="nav nav-tabs nav-tabs-s2 mt-n2">
                                                    <li class="nav-item">
                                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9">Referrals</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem10">Waiting(status)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem11">Pending(status)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">Paid(status)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem13">Cancelled(status)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem14">Waiting(validity)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem15">Pending(validity)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem16">Invested(validity)</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" data-toggle="tab" href="#tabItem17">Cancelled(validity)</a>
                                                    </li>
                                                </ul>
                                                <hr/>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tabItem9">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{all}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/all}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem10">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{waiting}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/waiting}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem11">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{pending}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/pending}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem12">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{paid}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/paid}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem13">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{cancelled}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/cancelled}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem14">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{vwaiting}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/vwaiting}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem15">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{vpending}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/vpending}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem16">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{vinvested}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/vinvested}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                    <div class="tab-pane" id="tabItem17">
                                                    	<div class="table-responsive">
			                                                <table class="datatable-init table nk-tb-list responsive">
			                                                    <thead>
			                                                        <tr>
			                                                            <th>S/N</th>
			                                                            <th>Time(joined)</th>
			                                                            <th>Time(invested)</th>
			                                                            <th>User</th>
			                                                            <th>Referrer</th>
			                                                            <th>Validity</th>
			                                                            <th>Comm ({site_currency})</th>
			                                                            <th>Status</th>
			                                                            <th>...</th>
			                                                        </tr>
			                                                    </thead>
			                                                    <tbody>
	                        										{vcancelled}
				                                                        <tr>
				                                                            <td>{index}</td>
				                                                            <td class="tim-{id}-j">{time}</td>
				                                                            <td class="tim-{id}-i">{time_invested}</td>
				                                                            <td class="user-{id}">{referred|lower}</td> 
				                                                            <td class="user-ref-{id}">{referer|lower}</td>
				                                                            <td class="val-{id}">{! valid !}</td>
				                                                            <td class="comm-{id}">{commission}</td>
				                                                            <td class="sta-{id}">{! status !}</td>
				                                                            <td class="nk-tb-col nk-tb-col-tools">
						                                                        <ul class="nk-tb-actions gx-1" style="justify-content: unset;">
				                                                                    <li>
				                                                                        <div class="drodow">
				                                                                            {noparse}<a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
				                                                                            <div class="dropdown-menu dropdown-menu-right">
				                                                                                <ul class="link-list-opt no-bdr">
				                                                                                    <li><a onclick="editor('{/noparse}{id}{noparse}')" class="editComp"><em class="icon ni ni-edit-alt tb-status text-warning"></em><span>Edit</span></a></li>
				                                                                                    <li><a href="admin/referrals/delete/{/noparse}{id}{noparse}" class="editComp"><em class="icon ni ni-trash tb-status text-danger"></em><span>Delete</span></a></li>
				                                                                                </ul>{/noparse}
				                                                                            </div>
				                                                                        </div>
				                                                                    </li>
				                                                                </ul>
		                                                                    </td>
				                                                        </tr>
						                                            {/vcancelled}
			                                                    </tbody>
			                                                </table>
		                                            	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
			    <!-- @@ Review Edit Modal @e -->
			    <div class="modal fade zoom" tabindex="-1" role="dialog" id="referral-edit">
			        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
			            <form method="post" action="admin/referrals/update" class="form-validate">
			                <div class="modal-content">
			                    <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
			                    <div class="modal-body modal-body-sm">
			                        <div class="modal-header">
			                            <h6 class="modal-title" id="rev-title">Referral Status & validity</h6>
			                        </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">validity</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item1" class="form-select form-control form-control-lg select2-hidden-accessible" name="validity" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="0">Waiting</option>
			                                                        <option value="1">Invested</option>
			                                                        <option value="2">Pending</option>
			                                                        <option value="3">Cancelled</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                </div>
			                                <div class="row gy-4">
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name2">status</label>
			                                            <div class="form-control-wrap">
			                                                <select id="item2" class="form-select form-control form-control-lg select2-hidden-accessible" name="status" tabindex="-1" aria-hidden="true" required="">
			                                                        <option value="0">Waiting</option>
			                                                        <option value="1">Paid</option>
			                                                        <option value="2">Pending</option>
			                                                        <option value="3">Cancelled</option>
			                                                </select>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="col-md-12">
			                                        <div class="form-group">
			                                            <label class="form-label" for="full-name">Commission</label>
			                                            <input type="text" id="item1b" name="commission" class="form-control form-control-lg" placeholder="Enter commission">
			                                        </div>
			                                    </div>
			                                    <div class="col-12">
			                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
			                                            <li>
			                                                <input type="hidden" id="rev-idz" name="id">
			                                                <input type="submit" id="submit" class="btn btn-lg btn-primary" value="Update" name="update-referrals">
			                                            </li>
			                                            <li>
			                                                <a href="#" data-dismiss="modal" class="link link-light">Cancel</a>
			                                            </li>
			                                        </ul>
			                                    </div>
			                                </div>
			                    </div><!-- .modal-body -->
			                </div><!-- .modal-content -->
			            </form>
			        </div><!-- .modal-dialog -->
			    </div><!-- .modal -->
<script>
	function editor(did){
		document.querySelector('#referral-edit #rev-idz').value = did;
		document.querySelector('#item1b').value = document.querySelector('.comm-'+did).textContent;
		
		$('#referral-edit').modal('show');
		if(document.querySelector('.sta-'+did+' span').classList.contains('badge-secondary')) $('#item1').val('0').change();
		else if(document.querySelector('.sta-'+did+' span').classList.contains('badge-success')) $('#item1').val('1').change();
		else if(document.querySelector('.sta-'+did+' span').classList.contains('badge-warning')) $('#item1').val('2').change();
		else if(document.querySelector('.sta-'+did+' span').classList.contains('badge-danger')) $('#item1').val('3').change();

		if(document.querySelector('.val-'+did+' span').classList.contains('badge-secondary')) $('#item2').val('0').change();
		else if(document.querySelector('.val-'+did+' span').classList.contains('badge-success')) $('#item2').val('1').change();
		else if(document.querySelector('.val-'+did+' span').classList.contains('badge-warning')) $('#item2').val('2').change();
		else if(document.querySelector('.val-'+did+' span').classList.contains('badge-danger')) $('#item2').val('3').change();

	}
</script>