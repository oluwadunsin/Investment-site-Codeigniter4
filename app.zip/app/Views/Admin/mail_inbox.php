<!-- content @s -->
                                        {if $info != null}
                                            {! info !}
                                        {endif}
<div class="nk-content " style="margin-top: 70px;">
   <div class="container-fluid">
      <div class="nk-content-inner">
         <div class="nk-content-body">
            <div class="nk-ibx">
               <div class="nk-ibx-aside" data-content="inbox-aside" data-toggle-overlay="true" data-toggle-screen="lg">
                  <div class="nk-ibx-head">
                     <h5 class="mb-0">Mail</h5>
                     <a href="#" class="link link-primary" data-toggle="modal" data-target="#compose-mail">
                     <em class="icon ni ni-plus"></em>
                     <span>Compose</span>
                     </a>
                  </div>
                  <div class="nk-ibx-nav" data-simplebar>
                     <ul class="nk-ibx-menu">
                        <li class="active">
                           <a class="nk-ibx-menu-item" href="admin/mail/inbox">
                           <em class="icon ni ni-inbox"></em>
                           <span class="nk-ibx-menu-text">Inbox</span>
                           {if $mail_inbox_count > 0}<span class="badge badge-pill badge-primary">{mail_inbox_count}</span>{endif}
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="admin/mail/sent">
                           <em class="icon ni ni-send"></em>
                           <span class="nk-ibx-menu-text">Sent</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-edit"></em>
                           <span class="nk-ibx-menu-text">Draft</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-star"></em>
                           <span class="nk-ibx-menu-text">Favourite</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-report"></em>
                           <span class="nk-ibx-menu-text">Spam</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-trash"></em>
                           <span class="nk-ibx-menu-text">Trash</span>
                           </a>
                        </li>
                        <li>
                           <a class="nk-ibx-menu-item" href="#">
                           <em class="icon ni ni-emails"></em>
                           <span class="nk-ibx-menu-text">All Mails</span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="nk-ibx-body bg-white">
                  <div class="nk-ibx-head">
                     <div class="nk-ibx-head-actions">
                        <div class="nk-ibx-head-check">
                            Inbox
                        </div>
                     </div>
                  </div>
                  <div class="nk-ibx-list" data-simplebar>
					 {mail}
                         <div class="nk-ibx-item {read}">
                            <a href="admin/mail/update/{id}" class="nk-ibx-link"></a>
                            <div class="nk-ibx-item-elem nk-ibx-item-check">
                               <div class="custom-control custom-control-sm custom-checkbox">
                                  <input type="checkbox" class="custom-control-input nk-dt-item-check" id="conversionItem01">
                                  <label class="custom-control-label" for="conversionItem01"></label>
                               </div>
                            </div>
                            {noparse}<div class="nk-ibx-item-elem nk-ibx-item-star">
                               <div class="asterisk">
                                  <a href="javascript:void(0)" class="{/noparse}{read2}{noparse}">
                                  <em class="asterisk-off icon ni ni-star"></em>
                                  <em class="asterisk-on icon ni ni-star-fill"></em>
                                  </a>
                               </div>
                            </div>{/noparse}
                            <div class="nk-ibx-item-elem nk-ibx-item-user">
                               <div class="user-card">
                                  <div class="user-avatar">
                                     <img src="profile-pics/{username|lower}.jpg" alt="">
                                  </div>
                                  <div class="user-name">
                                     <div class="lead-text">{fullname|title}</div>
                                  </div>
                               </div>
                            </div>
                            <div class="nk-ibx-item-elem nk-ibx-item-fluid">
                               <div class="nk-ibx-context-group">
                                  <div class="nk-ibx-context">
                                     <span class="nk-ibx-context-text">
                                        <span class="heading">{short_subject|title}</span>
                                     </span>
                                  </div>
                               </div>
                            </div>
                            <div class="nk-ibx-item-elem nk-ibx-item-time">
                               <div class="sub-text">{time}</div>
                            </div>
                            <div class="nk-ibx-item-elem nk-ibx-item-tools">
                               <div class="ibx-actions">
                                  <ul class="ibx-actions-hidden gx-1">
                                     <li>
                                        <a href="admin/mail/delete/{id}" class="btn btn-sm btn-icon btn-trigger" data-toggle="tooltip" data-placement="top" title="Delete">
                                        <em class="icon ni ni-trash"></em>
                                        </a>
                                     </li>
                                  </ul>
                                  {noparse}<ul class="ibx-actions-visible gx-2">
                                     <li>
                                        <div class="dropdown">
                                           <a href="javascript:void(0)" class="dropdown-toggle btn btn-sm btn-icon btn-trigger" data-toggle="dropdown">
                                            <em class="icon ni ni-more-h"></em>
                                           </a>
                                           <div class="dropdown-menu dropdown-menu-right">
                                              <ul class="link-list-opt no-bdr">
                                                 <li>
                                                    <a class="dropdown-item" href="admin/mail/update/{/noparse}{id}{noparse}">
                                                        <em class="icon ni ni-eye"></em>
                                                    <span>View</span>
                                                    </a>
                                                 </li>
                                                 <li>
                                                    <a class="dropdown-item" href="admin/mail/delete/{/noparse}{id}{noparse}">
                                                        <em class="icon ni ni-trash"></em>
                                                    <span>Delete</span>
                                                    </a>
                                                 </li>
                                              </ul>
                                           </div>
                                        </div>
                                     </li>
                                  </ul>{/noparse}
                               </div>
                            </div>
                         </div>
					 {/mail}
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

      <div class="modal fade" tabindex="-1" role="dialog" id="compose-mail">
         <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h6 class="modal-title">Compose Message</h6>
                  <a href="#" class="close" data-dismiss="modal">
                  <em class="icon ni ni-cross-sm"></em>
                  </a>
               </div>
			   <form method="post" action="admin/mail/compose">
                   <div class="modal-body p-0">
                      <div class="nk-reply-form-header">
                         <div class="nk-reply-form-group">
                            <div class="nk-reply-form-input-group">
                               <div class="nk-reply-form-input nk-reply-form-input-to">
                                  <label class="label">To</label>
                                        <select id="item1" class="input-mail form-select form-control form-control-lg select2-hidden-accessible" name="recipient" tabindex="-1" aria-hidden="true" required="">
                                                {recipients}
                                                    <option value="{id}">{first_name} {last_name}</option>
                                                {/recipients}
                                        </select>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="nk-reply-form-editor">
                         <div class="nk-reply-form-field">
                            <input type="text" class="form-control form-control-simple" placeholder="Subject" name="subject" required>
                         </div>
                         <div class="nk-reply-form-field">
                            <textarea class="form-control form-control-simple no-resize ex-large" placeholder="Hello" name="body" required></textarea>
                         </div>
                      </div>
                      <div class="nk-reply-form-tools">
                         <ul class="nk-reply-form-actions g-1">
                            <li class="mr-2">
                               <button class="btn btn-primary" type="submit">Send</button>
                            </li>
                         </ul>
                      </div>
                   </div>
			   </form>
            </div>
         </div>
      </div>