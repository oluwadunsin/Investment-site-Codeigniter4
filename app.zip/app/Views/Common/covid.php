<section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/covid_slider.jpg) no-repeat;"> 
				<div class="sub-header ">
					<span>{covid_heading|upper}</span>
					<h3>{covid_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="javascript:void(0)"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">COVID</li>
 					</ol>
				</div>
			</section>
				
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="new-detail-warp">
                                <div class="feature-img-deital">
                                    <img src="common/assets/images/News/covid_banner.jpg" class="img-responsive" alt="Image">
                                </div>
                                <div class="new-info new-info-detail">
                                    <h4>
                                        <a href="single_new.html">{covid_title|title}</a>
                                    </h4>
                                    <p><i class="fa fa-calendar" aria-hidden="true"></i>{datez|date(M d Y)}</p>
                                    <p><i class="fa fa-user" aria-hidden="true"></i> By Admin</p>
                                </div>
                                <div class="content-detail content-new-detail">{! covid_desc !}</div>
                            </div>
                            <div class="footer-post">
                                <p class="tags-post">
                                    <i class="fa fa-tags" aria-hidden="true"></i>
                                    <a href="#">Business</a>,
                                    <a href="#">Financial</a>,
                                    <a href="#">Legal</a>,
                                    <a href="#">Law</a>
                                </p>
                                <ul class="widget-footer-social-1 footer-post-share social-hover-defaul">
                                    {if $facebook !== ''}
                                        <li><a href="{facebook}" data-toggle="tooltip" data-placement="bottom" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $twitter !== ''}
                                        <li><a href="{twitter}" data-toggle="tooltip" data-placement="bottom" title="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $google !== ''}
                                        <li><a href="{google}" data-toggle="tooltip" data-placement="bottom" title="google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $youtube !== ''}
                                        <li><a href="{youtube}" data-toggle="tooltip" data-placement="bottom" title="youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $instagram !== ''}
                                        <li><a href="{instagram}" data-toggle="tooltip" data-placement="bottom" title="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $whatsapp !== ''}
                                        <li><a href="{whatsapp}" data-toggle="tooltip" data-placement="bottom" title="whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $linkedin !== ''}
                                        <li><a href="{linkedin}" data-toggle="tooltip" data-placement="bottom" title="linkeddin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $telegram !== ''}
                                        <li><a href="{telegram}" data-toggle="tooltip" data-placement="bottom" title="telegram"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                                    {endif}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /Main New Detail -->