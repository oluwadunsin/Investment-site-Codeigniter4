
						<div class="col-md-3">
							<div class="sideabar">
								<div class="widget widget-sidebar widget-list-link">
									<h4 class="title-widget-sidebar">
										Company
									</h4>
									<ul class="wd-list-link">
										<li><a href="index">Home</a></li>
                                        <li><a href="about">About Us</a></li>
                                        <li><a href="covid">Covid-19</a></li>
                                        <li><a href="services">Services</a></li>
                                        <li><a href="faq">Faq</a></li>
                                        <li><a href="contact">Contact Us</a></li>
                                        <li><a href="terms">Terms and Conditions</a></li>
                                        <li><a href="privacy">Privacy Policy</a></li>

									</ul>
								</div>
								<div class="widget widget-sidebar widget-text-block">
									<h4 class="title-widget-sidebar">
										Company in Lines
									</h4>
									<div class="wd-text-warp">
										<p>{site_description}</p>
										<a href="register" class="ot-btn btn-main-color" >
											<i class="fa fa-user-plus" aria-hidden="true"></i>
											Register
                                        </a>
									</div>
								</div>
								<!--<div class="widget-sidebar widget widget-html">
									<div class="wd-html-block">
										<a href="#">
											<img src="http://placehold.it/269x180/ccc.jpg" class="img-responsive" alt="Image">
										</a>
										<div class="content-wd-html-inner">
											<span>HIRING</span>
											<p>
												COME TO JOIN OUR TEAM !
											</p>
										</div>
										<a href="#" class="ot-btn btn-sub-color" >
											Join Now
										</a>
									</div>
								</div>-->
							</div>
						</div>
					</div>
				</div>
			</section>