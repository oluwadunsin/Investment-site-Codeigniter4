<!DOCTYPE html>
<html lang="en">
	<head>
    	<base href="{base_url}">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="{seo_description}">
		<meta name="author" content="Omnix Technologies">
		<meta name="keywords" content="{seo_keywords}">
		<title>{page_title}</title>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="common/assets/css/bootstrap.css">
		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&subset=devanagari,latin-ext" rel="stylesheet">
		<link rel="stylesheet" href="common/assets/fonts/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="common/assets/fonts/IcoMoon/icomoon.css">
		<link rel="stylesheet" href="common/assets/fonts/linearicon/style.css">
		<!-- Mobile Menu -->
		<link type="text/css" rel="stylesheet" href="common/assets/css/jquery.mmenu.all.css" />
		<!-- OWL CAROUSEL
			================================================== --> 
		<link rel="stylesheet" href="common/assets/css/owl.carousel.css">
		<!-- Magnific Popup core CSS file -->
		<link rel="stylesheet" href="common/assets/css/magnific-popup.css">
		<!-- SELECTBOX
			================================================== -->
		<link rel="stylesheet" type="text/css" href="common/assets/css/fancySelect.css" media="screen" />
		<!-- REVOLUTION STYLE SHEETS -->
		<link rel="stylesheet" type="text/css" href="common/assets/revolution/css/settings.css">
		<!-- REVOLUTION LAYERS STYLES -->
		<link rel="stylesheet" type="text/css" href="common/assets/revolution/css/layers.css">
		<!-- REVOLUTION NAVIGATION STYLES -->
		<link rel="stylesheet" type="text/css" href="common/assets/revolution/css/navigation.css">
		<!-- Main Style -->
		<link rel="stylesheet" href="common/assets/style.css">
        <!--google captcha-->
        <script src='https://www.google.com/recaptcha/api.js' async defer></script>
        <!--Sweet Alert-->
        <link href="user/assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet" />
		
		<!-- Favicons
			================================================== -->
		<link rel="shortcut icon" href="common/assets/images/x-icon/favicon.png">
		{! head_tag !}
	</head>
	<body class="royal_loader">
		{! body_tag !}