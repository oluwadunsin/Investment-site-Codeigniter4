
		<!-- royal_loader -->
		<div id="page">
			<!-- Mobile Menu -->
			<nav id="menu">
				<ul>
					<li class="active">
						<a href="index">Home</a>
					</li>
                    <li><a href="#">Company</a>
                        <ul>
                            <li>
                                <a href="about" ><span>About Us</span></a>
                            </li>
                            <li>
                                <a href="certificates" ><span>Cerificates</span></a>
                            </li>
                            <li>
                                <a href="testimonials" ><span>Testimonials</span></a>
                            </li>
                            <li>
                                <a href="login" ><span>More</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="services">Our Services</a>
                    </li>
                    <li >
                        <a  href="faq">FAQ</a>
                    </li>
                    <li ><a  href="#">Account</a>
                        <ul>
							{if !$loggedU}
                                <li ><a  href="login">Login</a></li>
                                <li ><a  href="register">Register</a></li>
							{endif}
							{if $loggedU}
                            	<li ><a  href="user/dashboard">Dashboard</a></li>
							{endif}
							{if $loggedA}
                            	<li ><a  href="admin/dashboard">Admin</a></li>
							{endif}
                        </ul>
                    </li>
                    <li><a href="#">Blog</a>
                        <ul>
                            <li>
                                <a href="covid" ><span>Covid-19 Impact</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="affiliate" ><span>Affiliate</span></a>
                    </li>
                    <li>
                        <a href="#availPlans" ><span>Plans</span></a>
                    </li>
                    <li>
                        <a href="contact">Contact</a>
                    </li>
				</ul>
				</ul>
			</nav>
			<!-- /Mobile Menu -->
			<header class="header-h2">
				<div class="topbar tb-dark tb-md">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="topbar-home2">
								<div class="tb-contact tb-iconbox">
									<ul>
										<li><a href="contact"><i class="fa fa-map-marker" aria-hidden="true"></i><span><i>Find us</i> {address}</span></a></li>
										<li><a href="mailto:{email}"><i class="fa fa-envelope" aria-hidden="true"></i><span><i>Email us</i> {email|lower}</span></a></li>
										<li><a href="tel:{phone}"><i class="fa fa-phone" aria-hidden="true"></i><span><i>Call us now</i> {phone}</span></a></li>
									</ul>
								</div>
								<div class="tb-social-lan language">
									<select class="lang">
										<option data-class="usa">English</option>
										<option data-class="italy">Italian</option>
										<option data-class="fr">French</option>
										<option data-class="gm">German</option>
									</select>
									<ul>
                                        {if $facebook !== ''}
                                            <li><a href="{facebook}" data-toggle="tooltip" data-placement="bottom" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $twitter !== ''}
                                            <li><a href="{twitter}" data-toggle="tooltip" data-placement="bottom" title="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $google !== ''}
                                            <li><a href="{google}" data-toggle="tooltip" data-placement="bottom" title="google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $youtube !== ''}
                                            <li><a href="{youtube}" data-toggle="tooltip" data-placement="bottom" title="youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $instagram !== ''}
                                            <li><a href="{instagram}" data-toggle="tooltip" data-placement="bottom" title="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $whatsapp !== ''}
                                            <li><a href="{whatsapp}" data-toggle="tooltip" data-placement="bottom" title="whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $linkedin !== ''}
                                            <li><a href="{linkedin}" data-toggle="tooltip" data-placement="bottom" title="linkeddin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        {endif}
                                        {if $telegram !== ''}
                                            <li><a href="{telegram}" data-toggle="tooltip" data-placement="bottom" title="telegram"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                                        {endif}
									</ul>
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /topbar -->
				<div class="nav-warp nav-warp-h2">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="navi-warp-home-2">
								<a href="index" class="logo"><img src="common/assets/images/logo/logo.png" class="img-responsive" alt="Image" width="80px"></a>
                                <nav>
									<ul class="navi-level-1 active-subcolor">
										<li class="active">
						                    <a href="index">Home</a>
										</li>
										<li ><a  href="#">Company</a>
											<ul class="navi-level-2">
        										<li>
                                                    <a href="about" ><span>About Us</span></a>
        										</li>
                                                <li>
                                                    <a href="certificates" ><span>Cerificates</span></a>
                                                </li>
                                                <li>
                                                    <a href="testimonials" ><span>Testimonials</span></a>
                                                </li>
                                                <li>
                                                    <a href="login" ><span>More</span></a>
                                                </li>
											</ul>
										</li>
										<li>
											<a href="services">Our Services</a>
										</li>
										<li >
                                            <a  href="faq">FAQ</a>
                                        </li>
                                        <li><a href="#">Blog</a>
											<ul class="navi-level-2">
                                                <li>
                                                    <a href="covid" ><span>Covid-19 Impact</span></a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="affiliate" ><span>Affiliate</span></a>
                                        </li>
                                        <li>
                                            <a href="#availPlans" ><span>Plans</span></a>
                                        </li>
										<li>
                                            <a href="contact">Contact</a>
                                        </li>
										<li ><a  href="#">Account</a>
											<ul class="navi-level-2">
												{if !$loggedU}
    												<li ><a  href="login">Login</a></li>
    												<li ><a  href="register">Register</a></li>
												{endif}
												{if $loggedU}
													<li ><a  href="user/dashboard">Dashboard</a></li>
												{endif}
												{if $loggedA}
													<li ><a  href="admin/dashboard">Admin</a></li>
												{endif}
											</ul>
										</li>
									</ul>
                                </nav>
								<a href="#menu" class="btn-menu-mobile"><i class="fa fa-bars" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /nav -->
			</header>
			<!-- /End Header 1 Warp -->