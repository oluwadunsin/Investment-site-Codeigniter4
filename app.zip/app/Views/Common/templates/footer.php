

		</div>
		<div style="height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px; width: 100%;position:fixed;bottom:0px"><div style="height:40px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&theme=light&pref_coin_id=1505&invert_hover=no" width="100%" height="36px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div><div style="display:inline;color: #FFFFFF; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;">
						<span class="text-center">
							Copyright &copy; {datez|date(Y)} <a href="#">{site_name|title}</a>. - Powered By <a href="#"> Omnix Technologies. </a> All rights reserved.
						</span><a href="https://coinlib.io" target="_blank" style="font-weight: 500; color: #FFFFFF; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>
		<!-- /page -->
		<a id="to-the-top" class="fixbtt bg-hover-theme"><i class="fa fa-chevron-up"></i></a> 
		<!-- Back To Top -->
		<!-- Switcher -->
		<!-- End Switcher -->
		<!-- SCRIPT -->
		<script src="common/assets/js/vendor/jquery.min.js"></script>
		<script src="common/assets/js/plugins/jquery.waypoints.min.js"></script>
		<script src="common/assets/js/vendor/bootstrap.js"></script>
		<!-- Sticky -->
		<script src="common/assets/js/plugins/jquery.sticky-kit.min.js"></script>
		<!-- <script src="js/plugins/sticky.js"></script> -->
		<!-- Mobile Menu
			================================================== -->
		<script type="text/javascript" src="common/assets/js/plugins/jquery.mmenu.all.min.js"></script>
		<script type="text/javascript" src="common/assets/js/plugins/mobilemenu.js"></script>
		<!-- REVOLUTION JS FILES -->
		<script type="text/javascript" src="common/assets/revolution/js/jquery.themepunch.tools.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
		<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="common/assets/revolution/js/extensions/revolution.extension.video.min.js"></script>
		<script src="common/assets/js/plugins/slider-home-3.js"></script>
		<!-- Initializing Owl Carousel
			================================================== -->
		<script src="common/assets/js/plugins/owl.carousel.js"></script>
		<script src="common/assets/js/plugins/owl.js"></script>
		<!-- PreLoad
			================================================== --> 
		<script type="text/javascript" src="common/assets/js/plugins/royal_preloader.js"></script>
		<!-- Parallax -->
		<script src="common/assets/js/plugins/jquery.parallax-1.1.3.js"></script>
		<!-- <script src="js/plugins/parallax.js"></script> -->
		<!-- Fancy Select -->
		<script src="common/assets/js/plugins/fancySelect.js"></script>
		<script src="common/assets/js/plugins/lang-select.js"></script>
		<script src="common/assets/js/plugins/cb-select.js"></script>
		<!-- Magnific Popup core JS file -->
		<script src="common/assets/js/plugins/jquery.magnific-popup.min.js"></script>
		<script src="common/assets/js/plugins/lightbox.js"></script>
		<!-- Initializing Counter Up
			================================================== -->
		<script src="common/assets/js/plugins/jquery.counterup.min.js"></script>
		<script src="common/assets/js/plugins/counterup.js"></script>
		{if $page_title == "Contact Us"}
			<script src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false&amp;extension=.js"></script>
			<script src="common/assets/js/plugins/contact.js"></script>
		{endif}
		<!-- Twitter -->
		<script src="common/assets/js/plugins/twitterFetcher.js"></script>
		<script src="common/assets/js/plugins/tweets-footer.js"></script>
		
		<!-- Global Js
			================================================== --> 
		<script src="common/assets/js/plugins/template.js"></script>
		<!-- Demo Switcher
			================================================== -->
		<script src="common/assets/switcher/demo.js"></script>
        <!--custom script-->
        
		<!-- Sweet Alert
			================================================== -->
        <script src="user/assets/plugins/sweet-alert/sweetalert.min.js"></script>
        <script src="user/assets/js/sweet-alert.js"></script>
        <script>
            window.addEventListener('load',function(){
                let notifMessage = '{! site_notif_out !}';
                let siteName = '{site_name}'+'-Out';
                let ssStorage = sessionStorage.getItem(siteName);
                if(notifMessage != "" && ssStorage == null){
                    swal({
                        title:'',
                        position: 'center',
                        type: 'info',
                        text: notifMessage,
                        showClass: {
                            popup: 'animate__animated animate__fadeInDown'
                        },
                        hideClass: {
                            popup: 'animate__animated animate__fadeOutUp'
                        }
                    });
                    sessionStorage.setItem(siteName, true);
                }  
                
                if(window.location.href.indexOf('#availPlans') != -1) scrollView('availPlans');
            });
            
            function scrollView(el){
                    document.getElementById(el).scrollIntoView({
                    behavior: 'smooth', // smooth scroll
                    block: 'start' // the upper border of the element will be aligned at the top of the visible part of the window of the scrollable area.
                })
            }
        </script>
        {! close_body_tag !}
	</body>
</html>