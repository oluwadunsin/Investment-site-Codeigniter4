

            <section class="bg-subcr-1">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                                        {if $info != null}
                                            {! info !}
                                        {endif}
                            <div class="subcribe-warp">
                                <p class="sub-text-subcri">{newsletter_heading|title} </p>
                                <form action="newsletter" method="post" class="form-inline form-subcri">
                                    <div class="form-group">
                                        <label for="exampleInputName2"><small>{nsub_heading_1} <span> {nsub_heading_2} </span>{nsub_heading_3} </small></label>
                                        <input type="hidden" name="{csrf_token}" value="{csrf_hash}" />
                                        <input type="text" name="newsletter" class="form-control" id="exampleInputName2" placeholder="Your E-mail Address">
                                    </div>
                                    <button type="submit" class="btn-subcrib"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /Subcribe -->