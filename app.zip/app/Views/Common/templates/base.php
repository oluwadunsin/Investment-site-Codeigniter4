

			<!-- Footer -->
			<footer class="f-bg-dark">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-6">
							<div class="widget widget-footer widget-footer-icon-link">
								<div class="title-block title-on-dark title-xs">
									<h4>{contact_sub_heading|title}</h4>
									<span class="bottom-title"></span>
								</div>
                                <ul class="icon-link-list-icon">
                                    <li><i class="fa fa-map-marker"></i> {address}</li>
                                    <li><i class="fa fa-phone"></i> <a href="tel:{phone}">{phone}</a> </li>
                                    <li><i class="fa fa-envelope"></i> {+ safe_mailto email=email title="Mail Us" +} </li>
                                    <li>
                                        <i class="fa fa-clock-o"></i> {week_begin} - {week_end}: <strong>{time_begin} - {time_end}</strong>
                                    </li>
                                </ul>
							</div>
							<div class="widget widget-footer widget-footer-text">
                            <br/>
                                <ul class="widget widget-footer widget-footer-social-1">
                                    {if $facebook !== ''}
                                        <li><a href="{facebook}" data-toggle="tooltip" data-placement="bottom" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $twitter !== ''}
                                        <li><a href="{twitter}" data-toggle="tooltip" data-placement="bottom" title="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $google !== ''}
                                        <li><a href="{google}" data-toggle="tooltip" data-placement="bottom" title="google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $youtube !== ''}
                                        <li><a href="{youtube}" data-toggle="tooltip" data-placement="bottom" title="youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $instagram !== ''}
                                        <li><a href="{instagram}" data-toggle="tooltip" data-placement="bottom" title="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $whatsapp !== ''}
                                        <li><a href="{whatsapp}" data-toggle="tooltip" data-placement="bottom" title="whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $linkedin !== ''}
                                        <li><a href="{linkedin}" data-toggle="tooltip" data-placement="bottom" title="linkeddin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                    {endif}
                                    {if $telegram !== ''}
                                        <li><a href="{telegram}" data-toggle="tooltip" data-placement="bottom" title="telegram"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                                    {endif}
                                </ul>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="widget widget-footer widget-footer-tweets">
								<div class="title-block title-on-dark title-xs">
									<h4>About</h4>
									<span class="bottom-title"></span>
								</div>
								<div>{site_description|capitalize}</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="title-block title-on-dark title-xs">
								<h4>Quick Links</h4>
								<span class="bottom-title"></span>
							</div>
							<div class="widget widget-footer widget-tags-footer">
                                <a href="index">Home</a>
                                <a href="about">About Us</a>
                                <a href="services">Services</a>
                                <a href="terms">Terms and Conditions</a>
                                <a href="privacy">Privacy Policy</a>
                                <a href="faq">Faq</a>
                                <a href="contact">Contact Us</a>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="widget widget-footer widget-footer-subcri">
								<div class="title-block title-on-dark title-xs">
									<h4>Newsletter</h4>
									<span class="bottom-title"></span>
								</div>
								<p>Subscribe to our newsletter for latest updates about our company</p>
								<form action="newsletter" method="post" class="form-subcri-footer">
								  <div class="form-group">
                                    <input type="hidden" name="{csrf_token}" value="{csrf_hash}" />
								    <input name="newsletter" type="email" class="form-control"   placeholder="Email Address">
								  </div>
								  <button type="submit" class="btn-subcri-footer">Submit</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</footer>	
			<!-- /Footer -->

			<section class="no-padding cr-h1">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="copyright-warp cr-1">
								<div class="copyright-list-link">
									<ul>
										<li><a href="index">Home   </a></li>
										<li><a href="about">About Us  </a></li>
										<li><a href="contact">Contact</a></li>
									</ul>
								</div>
								<div class="copyright-text">
									<p>&copy; {datez|date(Y)} {site_name|title} - Powered By <span>Omnix Technologies</span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /copyright -->