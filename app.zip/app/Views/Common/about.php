            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/about_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{about_heading|title}</span>
					<h3>{about_sub-heading|title}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">ABOUT US</li>
 					</ol>
				</div>
			</section>

            <section class="no-padding">
                <div class="container">
                    <div class="row">
                        <div class="whyus-warp-h2 whyus-about">
                            <div class="col-md-6">
                                <div class="left-whyus-h2">
                                    <div class="demo-style-1-warp">
                                        <img src="common/assets/images/Content/about_description.jpg" class="img-responsive" alt="Image">
                                        <div class="demo-style-1-box-text right">
                                            <p>{pointa|capitalize}</p>
                                            <p>{pointb|capitalize}</p>
                                            <p>{pointc|capitalize}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="right-whyus-h2">
                                <div class="iconbox-warp ">
                                    <h3 class="title-mix">{topica|capitalize}<strong> {topicb} </strong> {topicc} <strong> {topicd}</strong></h3>
                                    <p class="demo-sub-about-text-2">{! body !}</p>
                                    <!--<h4>{sub_topica|first}</h4>
                                    <p>{! sub_topica_body !}</p>
                                    <h4>{sub_topicb|first}</h4>
                                    <p>{! sub_topicb_body !}</p>
                                    <h4>{sub_topicc|first}</h4>
                                    <p>{! sub_topicc_body !}</p>-->
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about description -->

            <!--<section class="no-padding bg-counter-h1" style="background: url(common/assets/images/bg-content/about_why.jpg) no-repeat;">
                <div class="container">
                    <div class="row">
                        <div class="warp-counter">
                            <!-- https://bootsnipp.com/iconsearch?library=icomoon
                            {stats}
                            <div class="col-md-3 col-sm-6">
                                <div class="counter-inline">
                                    <span class="icon {a}"></span>
                                    <span class="counter">{b}</span>
                                    <p>{c|capitalize}</p>
                                </div>
                            </div>
                            {/stats}
                        </div>
                    </div>
                </div>
            </section>
            <!-- couterup

            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- https://bootsnipp.com/iconsearch?library=icomoon
                            <div class="strategy-warp-h4 whyus-about">
                                <div class="title-block text-center">
                                    <span class="top-title"></span>
                                    <h2>{why_topic|capitalize}</h2>
                                    <p class="sub-title">{why_sub_topic|capitalize}</p>
                                    <span class="bottom-title"></span>
                                </div>
                                <div class="about-icon-warp">
                                    {why}
                                        <div class="col-md-3">
                                            <div class="iconbox text-center">
                                                <span class="icon {a}"></span>
                                                <h4>{b|first}</h4>
                                                <p>{c|capitalize}</p>
                                            </div>
                                        </div>
                                    {/why}
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /why us -->
