            
            <section class="no-padding sh-company-history" style="background: url(common/assets/images/bg-content/history_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{history_heading|upper}</span>
					<h3>{history_sub-heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">HISTORY</li>
 					</ol>
				</div>
			</section>
			<!-- /Sub HEader -->
			
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-9">
							<div class="main-page">
								<div class="history-timeline-h-warp">
									<div class="timeline-centered">
                                        {history}
                                            <article class="timeline-entry">
                                                <p class="h-year">{a}</p>
                                                <div class="timeline-entry-inner">
                                                    <div class="timeline-icon">
                                                    </div>
                                                    <div class="timeline-label">
                                                        <h4>{b|Capitalize}</h4>
                                                        <p>{c}</p>
                                                    </div>
                                                </div>
                                            </article>
                                        {/history}
								    </div>
								</div>
							</div>
						</div>