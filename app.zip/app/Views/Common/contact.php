            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/contact_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{contact_heading|upper}</span>
					<h3>{contact_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">CONTACT US</li>
 					</ol>
				</div>
			</section>
            
            <section>
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="iconbox-inline">
								<span class="icon icon-location2"></span>
								<h4>Head Office</h4>
								<p>{address|capitalize}</p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="iconbox-inline">
								<span class="icon icon-phone"></span>
								<h4>Phone Numbers</h4>
								<p>{phone}</p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="iconbox-inline">
								<span class="icon icon-envelop"></span>
								<h4>E-mail Address</h4>
								<p>{email}</p>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /Iconbxo -->
			<div id="map-canvas" class="map-warp" style="height: 360px; position: relative; overflow: hidden;">{!map!}</div>
			<!-- /Map -->

			<section>
				<div class="container">	
					<div class="row">
						<div class="col-md-12">
							<div class="title-block title-contact">
								<h3>Send a Message</h3>
								<span class="bottom-title"></span>
							</div>
                                        {if $info != null}
                                            {! info !}
                                        {endif}
						</div>
						<div class="form-contact-warp">
						    <form action="contact" method="POST">
    							<div class="col-md-4">
    								<input type="text" name="name"   class="form-control" value="" required="required" title="" placeholder="Full Name">
    							</div>
    							<div class="col-md-4">
    								<input type="text" name="email"   class="form-control" value="" required="required" title="" placeholder="Email Address">
    							</div>
    							<div class="col-md-4">
    								<input type="text" name="subject"   class="form-control" value="" required="required" title="" placeholder="Subject">
    							</div>
    							<div class="col-md-12">
    								<div class="form-group">
    									<textarea   id="textarea" name="text" class="form-control" rows="5" required="required" placeholder="Comment"></textarea>
    								</div>
    							</div>
    							<div class="col-md-12">
                                    {if $captcha_enabled == true}
                                        <div class="form-group text-center">
                                            <div class="g-recaptcha" data-sitekey="{captcha_public_key}" style="display: inline-block;"></div>
                                        </div>
                                    {endif}
    							</div>
    							<div class="col-md-12">
    								<button type="submit" class="btn-main-color"><i class="fa fa-paper-plane" aria-hidden="true"></i> Submit</button>
    							</div>
							</form>
						</div>
					</div>
				</div>
			</section>
			<!-- /Form Contact -->