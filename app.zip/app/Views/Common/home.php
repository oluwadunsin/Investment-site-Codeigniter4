
		<!-- royal_loader -->
		<div id="page">
			<!-- Mobile Menu -->
			<nav id="menu">
				<ul>
					<li class="active">
						<a href="index">Home</a>
					</li>
                    <li><a href="#">Company</a>
                        <ul>
                            <li>
                                <a href="about" ><span>About Us</span></a>
                            </li>
                            <li>
                                <a href="certificates" ><span>Cerificates</span></a>
                            </li>
                            <li>
                                <a href="testimonials" ><span>Testimonials</span></a>
                            </li>
                            <li>
                                <a href="login" ><span>More</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="services">Our Services</a>
                    </li>
                    <li >
                        <a  href="faq">FAQ</a>
                    </li>
                    <li ><a  href="#">Account</a>
                        <ul>
							{if !$loggedU}
                                <li ><a  href="login">Login</a></li>
                                <li ><a  href="register">Register</a></li>
							{endif}
							{if $loggedU}
                            	<li ><a  href="user/dashboard">Dashboard</a></li>
							{endif}
							{if $loggedA}
                            	<li ><a  href="admin/dashboard">Admin</a></li>
							{endif}
                        </ul>
                    </li>
                    <li><a href="#">Blog</a>
                        <ul>
                            <li>
                                <a href="covid" ><span>Covid-19 Impact</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="affiliate" ><span>Affiliate</span></a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" onclick="scrollView('availPlans')" ><span>Plans</span></a>
                    </li>
                    <li>
                        <a href="contact">Contact</a>
                    </li>
				</ul>
			</nav>
			<!-- /Mobile Menu -->
			<header class="header-3-fix">
				<div class="nav-warp nav-warp-h3">
					<div class="navi-warp-home-3">
						<a href="index" class="logo"><img src="common/assets/images/logo/logo.png" class="img-responsive" alt="Image" width="150px"></a>
						
						<div class="tb-social-lan language">
                            {if $phone !== ''}
							    <a href="tel:{phone}"><i class="fa fa-phone" aria-hidden="true"></i> {phone}</a>
                            {endif}
							<select class="lang">
								<option data-class="usa">English</option>
								<option data-class="italy">Italian</option>
								<option data-class="fr">French</option>
								<option data-class="gm">German</option>
							</select>
							<ul>
                                {if $facebook !== ''}
                                    <li><a href="{facebook}" data-toggle="tooltip" data-placement="bottom" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $twitter !== ''}
                                    <li><a href="{twitter}" data-toggle="tooltip" data-placement="bottom" title="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $google !== ''}
                                    <li><a href="{google}" data-toggle="tooltip" data-placement="bottom" title="google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $youtube !== ''}
                                    <li><a href="{youtube}" data-toggle="tooltip" data-placement="bottom" title="youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $instagram !== ''}
                                    <li><a href="{instagram}" data-toggle="tooltip" data-placement="bottom" title="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $whatsapp !== ''}
                                    <li><a href="{whatsapp}" data-toggle="tooltip" data-placement="bottom" title="whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $linkedin !== ''}
                                    <li><a href="{linkedin}" data-toggle="tooltip" data-placement="bottom" title="linkeddin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                {endif}
                                {if $telegram !== ''}
                                    <li><a href="{telegram}" data-toggle="tooltip" data-placement="bottom" title="telegram"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                                {endif}
							</ul>
						</div>
						<nav>
									<ul class="navi-level-1 active-subcolor">
										<li class="active">
						                    <a href="index">Home</a>
										</li>
										<li ><a  href="#">Company</a>
											<ul class="navi-level-2">
        										<li>
                                                    <a href="about" ><span>About Us</span></a>
        										</li>
                                                <li>
                                                    <a href="certificates" ><span>Cerificates</span></a>
                                                </li>
                                                <li>
                                                    <a href="testimonials" ><span>Testimonials</span></a>
                                                </li>
                                                <li>
                                                    <a href="login" ><span>More</span></a>
                                                </li>
											</ul>
										</li>
										<li>
											<a href="services">Our Services</a>
										</li>
										<li >
                                            <a  href="faq">FAQ</a>
                                        </li>
                                        <li><a href="#">Blog</a>
											<ul class="navi-level-2">
                                                <li>
                                                    <a href="covid" ><span>Covid-19 Impact</span></a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="affiliate" ><span>Affiliate</span></a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)" onclick="scrollView('availPlans')" ><span>Plans</span></a>
                                        </li>
										<li>
                                            <a href="contact">Contact</a>
                                        </li>
										<li ><a  href="#">Account</a>
											<ul class="navi-level-2">
												{if !$loggedU}
    												<li ><a  href="login">Login</a></li>
    												<li ><a  href="register">Register</a></li>
												{endif}
												{if $loggedU}
													<li ><a  href="user/dashboard">Dashboard</a></li>
												{endif}
												{if $loggedA}
													<li ><a  href="admin/dashboard">Admin</a></li>
												{endif}
											</ul>
										</li>
									</ul>
						</nav>
						<a href="#menu" class="btn-menu-mobile"><i class="fa fa-bars" aria-hidden="true"></i></a>
					</div>
				</div>
				<!-- /nav -->
			</header>
			<!-- /End Header 1 Warp -->
			<!-- Slider -->
			<section id="slider" class="no-padding">
				<div id="slide_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container">
					<!-- START REVOLUTION SLIDER 5.0.7 auto mode -->
					<div id="slider_3" class="rev_slider fullwidthabanner slider-home1" style="display:none;" data-version="5.0.7">
						<ul>
							<!-- SLIDE  -->
							<li data-title="FOCUS ON">
								<!-- MAIN IMAGE -->
								<img src="common/assets/images/Slider/home3/1.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								<!-- LAYERS -->
								<!-- LAYER NR. 0 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="right" data-hoffset="" 
									 data-y="bottom" data-voffset=""
									 data-width="['580','580','580','auto']" 
									data-transform_idle="o:1;"
									data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
									data-start="1000" 

									data-responsive_offset="on" 
									><img src="common/assets/images/Slider/home3/people1.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
								</div>
								<!-- LAYER NR. 1 -->
								<div class="tp-caption tp-resizeme sl-s5" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="-45"
									 data-width="['400','400','400','300']" 
									data-transform_idle="o:1;"
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
									data-start="1700" 
									data-whitespace="normal"
									data-fontsize="['60','60','60','30']"
									data-lineheight="['70','70','70','50']"
									data-responsive_offset="on" 
									><p>{topic1a|upper} <span>{topic1b|upper}</span> {topic1c|upper}</p>
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="65" 
								 	data-width="['580','580','480','300']"
									data-transform_idle="o:1;"
									data-whitespace=normal
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="1900" 
									data-responsive_offset="on" 
									><p class="sl-s3">{topic1|capitalize}</p>
								</div>
								<!-- LAYER NR. 3 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="0" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="70" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
								</div>
							</li>
							<!-- SLIDE  -->
							<li data-title="FOCUS ON">
								<!-- MAIN IMAGE -->
								<img src="common/assets/images/Slider/home3/2.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								<!-- LAYERS -->
								<!-- LAYER NR. 0 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="right" data-hoffset="" 
									 data-y="bottom" data-voffset=""
									 data-width="['580','580','580','auto']" 
									data-transform_idle="o:1;"
									data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
									data-start="1000" 

									data-responsive_offset="on" 
									><img src="common/assets/images/Slider/home3/people2.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
								</div>
								<!-- LAYER NR. 1 -->
								<div class="tp-caption tp-resizeme sl-s5" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="-45"
									 data-width="['400','400','400','300']" 
									data-transform_idle="o:1;"
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
									data-start="1700" 
									data-whitespace="normal"
									data-fontsize="['60','60','60','30']"
									data-lineheight="['70','70','70','50']"
									data-responsive_offset="on" 
									><p>{topic2a|upper} <span>{topic2b|upper}</span> {topic2c|upper}</p>
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="65" 
								 	data-width="['580','580','480','300']"
									data-transform_idle="o:1;"
									data-whitespace=normal
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="1900" 
									data-responsive_offset="on" 
									><p class="sl-s3">{topic2|capitalize}</p>
								</div>
								<!-- LAYER NR. 3 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="0" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="70" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
								</div>
							</li>
							<!-- SLIDE  -->
							<li data-title="FOCUS ON">
								<!-- MAIN IMAGE -->
								<img src="common/assets/images/Slider/home3/3.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								<!-- LAYERS -->
								<!-- LAYER NR. 0 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="right" data-hoffset="" 
									 data-y="bottom" data-voffset=""
									 data-width="['580','580','580','auto']" 
									data-transform_idle="o:1;"
									data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
									data-start="1000" 

									data-responsive_offset="on" 
									><img src="common/assets/images/Slider/home3/people3.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
								</div>
								<!-- LAYER NR. 1 -->
								<div class="tp-caption tp-resizeme sl-s5" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="-45"
									 data-width="['400','400','400','300']" 
									data-transform_idle="o:1;"
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
									data-start="1700" 
									data-whitespace="normal"
									data-fontsize="['60','60','60','30']"
									data-lineheight="['70','70','70','50']"
									data-responsive_offset="on" 
									><p>{topic3a|upper} <span>{topic3b|upper}</span> {topic3c|upper}</p>
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption tp-resizeme" 
									 data-x="left" data-hoffset="0" 
									 data-y="center" data-voffset="65" 
								 	data-width="['580','580','480','300']"
									data-transform_idle="o:1;"
									data-whitespace=normal
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="1900" 
									data-responsive_offset="on" 
									><p class="sl-s3">{topic3|capitalize}</p>
								</div>
								<!-- LAYER NR. 3 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="0" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption" 
									 data-x="left" data-hoffset="70" 
									 data-y="bottom" data-voffset="180" 
									data-transform_idle="o:1;"
									data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
									data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
								 	data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
									data-start="2100" 
									><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</section>
			<style>
			    #slider_3 > ul > li.tp-revslider-slidesli.active-revslide > div:nth-child(4) > div > div{
			        margin-top:30px !important;
			    }
			</style>
			<!-- /Slider -->

            <!-- https://linearicons.com/free -->
			<section class="no-padding bg-iconbox-h3" >
				<div class="container">
					<div class="row">
						<div class="warp-full-width offer-h3-warp section-fix-position-h3">
							<div id="offer-h2" class="owl-offer-h3">
                                {section2a}
                                    <div class="item-offer" >
                                        <div class="iconbox-type-xs iconbox-overlay-bg text-center bg-light-grey">
                                            <span class="lnr {a}"></span>
                                            <h4>{b}</h4>
                                            <p>{c}</p>
                                            
                                        </div>
                                    </div>
                                {/section2a}
                                {section2b}
                                    <div class="item-offer" >
                                        <div class="iconbox-type-xs iconbox-overlay-bg text-center bg-light-grey">
                                            <span class="lnr {a}"></span>
                                            <h4>{b}</h4>
                                            <p>{c}</p>
                                            
                                        </div>
                                    </div>
                                {/section2b}
                                {section2c}
                                    <div class="item-offer" >
                                        <div class="iconbox-type-xs iconbox-overlay-bg text-center bg-light-grey">
                                            <span class="lnr {a}"></span>
                                            <h4>{b}</h4>
                                            <p>{c}</p>
                                            
                                        </div>
                                    </div>
                                {/section2c}
							</div>
							<div class="customNavigation">
				                <a class="btn-1 prev-offer-h2"><i class="fa fa-angle-left"></i></a>
				                <a class="btn-1 next-offer-h2"><i class="fa fa-angle-right"></i></a>
				        	</div><!-- End owl button -->
						</div>
					</div>
				</div>
			</section>
			<!-- /Iconbox -->

			<section class="no-padding">
				<div class="container">
					<div class="row">
						<div class="whyus-warp-h2 core-value-h3">
							<div class="col-md-6">
								<div class="left-whyus-h2">
									<div class="demo-style-1-warp">
										<img src="common/assets/images/Content/home-about.png" class="img-responsive" alt="Image">
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="right-whyus-h2">
									<div class="iconbox-warp ">
										<div class="title-block">
											<span class="top-title"></span>
											<h2>{section3_topic|title}</h2>
											<p class="sub-title">{section3_sub_topic}</p>
											<span class="bottom-title"></span>
										</div>
										<p class="demo-sub-about-text">{section3_body}</p>
										<h4>{section3_point1_topic|title}</h4>
										<p>{section3_point1_body}</p>
										<h4>{section3_point2_topic|title}</h4>
										<p>{section3_point2_body}</p>
										<h4>{section3_point3_topic|title}</h4>
										<p>{section3_point3_body}</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- about description -->

			<section class="no-padding">
				<div class=" side-bg">
					<div class="col-md-6 image-container">
						<div class="background-image" style="background: url(common/assets/images/bg-content/home_about_description1.jpg) ;"></div>
						
					</div>
					<div class="col-md-6 col-md-offset-6 content-bg-img-container">
						<div class="background-image" style="background: url(common/assets/images/bg-content/home_about_description2.jpg) ;"></div>
						<div class="content-bg-img-inner">
							<a class="popup-youtube btn-play" href="//{about_video_link}"><i class="fa fa-play" aria-hidden="true"></i></a>
							<h3>{about_video_title|title}</h3>
						</div>
					</div>
					
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<div class="warp-counter counter-h3">
                                    <!-- https://bootsnipp.com/iconsearch?library=icomoon -->
                                    {about_points}
                                        <div class="col-md-6">
                                            <div class="counter-inline ct-on-dark">
                                                <span class="icon {a}"></span>
                                                <span class="counter">{b}</span>
                                                <p>{c|title}</p>
                                            </div>
                                        </div>
                                    {/about_points}
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /Counter -->

			<section>
				<div class="container">
					<div class="row">
						<div class="title-block text-center">
							<span class="top-title "></span>
							<h2>{section4_topic|title}</h2>
							<p class="sub-title">{section4_sub_topic}</p>
							<span class="bottom-title"></span>
						</div>
						<div class="whyus-warp-h3">
							<div class="col-md-4">
                                {section4a}
                                    <div class="iconbox-inline">
                                            <span class="icon {a}"></span>
                                            <h4>{b|title}</h4>
                                            <p>{c}</p>
                                    </div>
                                {/section4a}
							</div>
							<div class="col-md-4">
                                {section4b}
                                    <div class="iconbox-inline">
                                            <span class="icon {a}"></span>
                                            <h4>{b|title}</h4>
                                            <p>{c}</p>
                                    </div>
                                {/section4b}
							</div>
							<div class="col-md-4">
                                {section4c}
                                    <div class="iconbox-inline">
                                            <span class="icon {a}"></span>
                                            <h4>{b|title}</h4>
                                            <p>{c}</p>
                                    </div>
                                {/section4c}
							</div>	
						</div>
					</div>
				</div>
			</section>
			<!-- /Why Choose Us -->
			
			<section class="cb-h3 no-padding">
				<div class="container">				
					<div class="row">
						<div class="callback-warp cbw-h3">
							<div class="col-md-6 col-md-offset-3">
									<div class="title-block title-on-dark text-center title-pd">
										<span class="top-title "></span>
										<h2>{section5_topic|title}</h2>
										<p class="sub-title">{section5_sub_topic|title}</p>
										<span class="bottom-title"></span>
									</div>
									<!--<div class="form-cb-warp">
										<form class="cb-form cb-form-on-dark">
											<div class="form-group">
												<input type="text" class="form-control" id="name" placeholder="Your Name*">
											</div>

											<select class="cb">
												<option value="">I would like to discuss</option>
												<option>Strategic Decision Making</option>
												<option>International Finance Resources</option>
												<option>Hedging & Risk Management</option>
												<option>International Capital Markets</option>
												<option>Foreign Exchange Markets</option>
												<option>International Finance & Global Markets</option>
												<option>International Finance Tutorial</option>
											</select>

											<div class="form-group">
												<input type="email" class="form-control"   placeholder="Your Email*">
											</div>
											<div class="form-group">
												<input type="text" class="form-control" id="phone" placeholder="Your Phone Number*">
											</div>
                                            {if $captcha_enabled == 1}
                                                <div class="form-group text-center">
                                                    <div class="g-recaptcha" data-sitekey="{captcha_public_key}" style="display: inline-block;"></div>
                                                </div>
                                            {endif}
											
											<button type="submit" class="btn-white-color"><i class="fa fa-paper-plane" aria-hidden="true"></i> Submit</button>
										</form>
									</div>-->
							</div>
							<div class="col-md-10 col-md-offset-1">
							    <div class="text-center" style="margin-bottom: 30px;">
							        <script src="https://www.cryptohopper.com/widgets/js/script"></script>
							        <div class="cryptohopper-web-widget" data-id="6" data-numcoins="1000" data-converter_type="crypto-to-fiat"></div>
							        <style>
							            #mcw-6 > div > p{
							                display:none !important;
							            }
							        </style>
							    </div>
							    <div>
                                    <!-- TradingView Widget BEGIN -->
                                    <div class="tradingview-widget-container">
                                  <div id="tradingview_1b7d7"></div>
                                  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BTCUSD/?exchange=BITBAY" rel="noopener" target="_blank"><span class="blue-text">Bitcoin</span></a> by TradingView</div>
                                  <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                                  <script type="text/javascript">
                                  new TradingView.MediumWidget(
                                  {
                                  "symbols": [
                                    [
                                      "Bitcoin",
                                      "BITBAY:BTCUSD|1M"
                                    ],
                                    [
                                      "Ethereum",
                                      "BITSTAMP:ETHUSD|1M"
                                    ],
                                    [
                                      "Ripple",
                                      "BITSTAMP:XRPUSD|1M"
                                    ],
                                    [
                                      "Doge",
                                      "BINANCEUS:DOGEUSD|1M"
                                    ],
                                    [
                                      "Bitcoin cash",
                                      "KRAKEN:BCHUSD|1M"
                                    ],
                                    [
                                      "Binance coin",
                                      "BINANCE:BNBUSD|1M"
                                    ]
                                  ],
                                  "chartOnly": false,
                                  "width": "100%",
                                  "height": 400,
                                  "locale": "en",
                                  "colorTheme": "light",
                                  "gridLineColor": "#F0F3FA",
                                  "trendLineColor": "#2196F3",
                                  "fontColor": "#787B86",
                                  "underLineColor": "#E3F2FD",
                                  "isTransparent": false,
                                  "autosize": false,
                                  "container_id": "tradingview_1b7d7"
                                }
                                  );
                                  </script>
                                </div>
                                    <!-- TradingView Widget END -->
                                </div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /call back -->
			

			<section class="bg-quote-h3" id="availPlans">
				<div class="quote-inner quote-inner-h3">
					<p>{section6a} <span> {section6b|title}</span></p>
			
			        <section>
				        <div class="container">
        					<div class="row">
        						<div class="col-md-12">
        							<div class="row">
        								<div class="pricing-home12-warp">
                                            {products}
        									    <div class="col-md-3 col-sm-6">
        										    <div class="pricing-table">
            									    	<div class="plan">
                									        <h3>{name|title}
                									        	<span class="price">
                										        	<span class="price-inner">
                										        		<span class="big-num">{percent}.</span><span class="small-num">00 %</span><br>
                										        		<span class="perm">Per {period_name|title}</span>
                										        	</span>
                										        </span> 
                									        </h3>
                
                									        <div class="body-table">
                										        
                										        <ul>
                										            <li><b>{period}</b> {period_name|title}</li>
                										            <li>{feature1}</li>
                										            <li>{feature2}</li>
                										            <li>{feature3}</li>
                										            <li>{feature4}</li>
                										            <li>{feature5}</li>
                										            <li class="h4"><b>{minimum}</b> -<b> {maximum}</b></li>
                										        </ul> 
                										        <a href="user/products/cart/{id}" class="ot-btn btn-main-color" >Get Plan</a>
                										    </div>
            									    	</div>
        										    </div>
        									    </div>
                                            {/products}
        								</div>
        							</div>
        						</div>
        					</div>
        				</div>
			        </section>
			
					<a href="login" class="ot-btn btn-border-dark-color">{section6_btn}</a>
				</div>
			</section>
			<!-- /Quote -->