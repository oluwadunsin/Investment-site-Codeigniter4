            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/media_slider.jpg) no-repeat;"> 
				<div class="sub-header ">
					<span>{media_heading|upper}</span>
					<h3>{media_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">Certificates</li>
 					</ol>
				</div>
			</section>
			
            <section>
				<div class="container">
					<div class="row">
						<div class="partner-grid">
					        {media}
    							<div class="col-md-3 col-sm-6">
    								<div><img src="common/assets/images/gallery/{img}" class="img-responsive partner-img" alt="Image" width="269px" height="160px"></div>
    								<div class="text-center" style="margin-top: -20px;margin-bottom: 20px;">{name}</div>
    							</div>
							{/media}
						</div>
						<div class="col-md-12 text-center">
							<ul class="pagination">
								<li><a href="javascript:void(0)">PREVIOUS</a></li>
								<li><a href="javascript:void(0)">NEXT</a></li>
								<li class="active"><a href="javascript:void(0)">1</a></li>
								<li><a href="javascript:void(0)">2</a></li>
								<li><a href="javascript:void(0)">3</a></li>
								<li><a href="javascript:void(0)">4</a></li>
							</ul>
						</div>
					</div>
				</div>
			</section>