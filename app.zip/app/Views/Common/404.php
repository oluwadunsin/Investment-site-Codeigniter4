<!DOCTYPE html>
<html lang="en">
<head>
    	<base href="<?= base_url(); ?>">
		<title>404</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- google fonts -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
		<link rel="shortcut icon" type="image/x-icon" href="common/assets/images/x-icon/favicon.png">

		<link rel="stylesheet" href="common/assets/css/animate.css">
		<link rel="stylesheet" href="common/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="common/assets/css/all.min.css">
		<link rel="stylesheet" href="common/assets/css/icofont.min.css">
		<link rel="stylesheet" href="common/assets/css/lightcase.css">
		<link rel="stylesheet" href="common/assets/css/swiper.min.css">
		<link rel="stylesheet" href="common/assets/css/style.css">
	</head>

	<body>
		<!-- preloader start here -->
        <div class="preloader">
            <div class="preloader-inner">
                <div class="preloader-icon">
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
		<!-- preloader ending here -->
		
		<!-- fore zero fore page start here -->
		<section class="fore-zero padding-tb">
            <div class="container">
                <div class="section-wrapper">
                    <div class="zero-item text-center">
                        <h2>Oops, sorry we can’t find that page</h2>
                        <div class="zero-thumb">
                            <img src="common/assets/images/404.png" alt="404">
                        </div>
                        <div class="zero-content">
                            <a href="index.php" class="lab-btn"><span>Back to Home</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- fore zero fore page ending here -->
        

		
		<script src="common/assets/js/jquery.js"></script>
		<script src="common/assets/js/fontawesome.min.js"></script>
		<script src="common/assets/js/waypoints.min.js"></script>
		<script src="common/assets/js/bootstrap.min.js"></script>
		<script src="common/assets/js/wow.min.js"></script>
		<script src="common/assets/js/swiper.min.js"></script>
		<script src="common/assets/js/jquery.countdown.min.js"></script>
		<script src="common/assets/js/jquery.counterup.min.js"></script>
		<script src="common/assets/js/isotope.pkgd.min.js"></script>
		<script src="common/assets/js/lightcase.js"></script>
        <script src="common/assets/js/functions.js"></script>
	</body>
</html>