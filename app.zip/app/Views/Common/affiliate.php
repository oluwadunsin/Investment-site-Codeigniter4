            
            <section class="no-padding sh-company-history" style="background: url(common/assets/images/bg-content/affiliate_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{aff_heading|upper}</span>
					<h3>{aff_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">AFFILIATES</li>
 					</ol>
				</div>
			</section>
			<!-- /Sub HEader -->
			
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-9">
							<div class="services-2-detail-warp">
								<div class="row">
									<div class="col-md-12">
										<div class="title-block title-contact">
											<h3>{aff_title|title}</h3>
											<span class="bottom-title"></span>
										</div>
											
											<p>{! aff_desc !}</p>
										

									</div>
										
								</div>
							</div>
						</div>