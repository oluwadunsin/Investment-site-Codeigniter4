            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/investment_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{investment_heading|upper}</span>
					<h3>{investment_sub-heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">OUR SERVICES</li>
 					</ol>
				</div>
			</section>
            
            <section>
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="services-list-warp">
                                {packages}
                                    <div class="item-service-list">
                                        <figure>
                                            <img src="{c}" class="img-responsive" alt="Image">
                                            <figcaption>{a|first}</figcaption>
                                        </figure>
										<div class="box-sum-service">
											<p>{! b !}</p>
											{noparse}<a href="register.php" class="ot-btn btn-sub-color" >Read More</a>{/noparse}
										</div>
									</div>
                                {/packages}
							</div>
						</div>
					</div>
				</div>
			</section>