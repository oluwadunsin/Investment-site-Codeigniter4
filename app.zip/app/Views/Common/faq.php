            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/faq_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{faq_heading|upper}</span>
					<h3>{faq_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">FAQ</li>
 					</ol>
				</div>
			</section>

			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="panel-group accordion-1" id="accordion">
								    {faq}
										<div class="panel panel-default">
												<div class="panel-heading">
												<h4 class="panel-title">
													{noparse}<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#{/noparse}{id}"> {question|capitalize} </a>
												</h4>
												</div>
												<div id="{id}" class="panel-collapse collapse">
													<div class="panel-body">{answer} </div>
												</div>
										</div>
								    {/faq}
							</div>
						</div>
					</div>
				</div>
			</section>