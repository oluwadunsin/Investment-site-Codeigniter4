            <section class="no-padding sh-about" style="background: url(common/assets/images/bg-content/testimonial_slider.jpg) no-repeat;">
				<div class="sub-header ">
					<span>{review_heading|upper}</span>
					<h3>{review_sub_heading|upper}</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">TESTIMONIALS</li>
 					</ol>
				</div>
			</section>
			<!-- /subheader -->
				
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-9">
							<div class="testimonial-list">
							    {testimonial}
									<div class="item-testimonial-h1 test-list-item" >
										{noparse}<a href="javascript:void(0)"><img src="{/noparse}{image}" class="img-responsive" alt="Image"></a>							
									
										<p>{review}</p>
										
										<span class="name">{name|title}</span>
									</div>
								{/testimonial}
							</div>
								<!--<div class="col-md-12">
									<div class="row">
            							<ul class="pagination">
            								<li><a href="javascript:void(0)">PREVIOUS</a></li>
            								<li><a href="javascript:void(0)">NEXT</a></li>
            								<li class="active"><a href="javascript:void(0)">1</a></li>
            								<li><a href="javascript:void(0)">2</a></li>
            								<li><a href="javascript:void(0)">3</a></li>
            								<li><a href="javascript:void(0)">4</a></li>
            							</ul>
    								</div>
							</div>-->
						</div>